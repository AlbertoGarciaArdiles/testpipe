import boto3
import json
import logging
import os

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
ecs = boto3.client('ecs')
CWNamespace = 'CustomMetrics/ECS'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# Returns a list of the ecs clusters (Arn) in the account
def get_ecs_clusters_by_account():
  response = ecs.list_clusters()
  results = response["clusterArns"]
  while "NextToken" in response:
      response = ecs.list_clusters(NextToken=response["NextToken"])
      results.extend(response["clusterArns"])
  return results

# Returns a list of containers instances (Arn) for a given cluster
def get_container_instances_by_cluster(cluster):
  response = ecs.list_container_instances(cluster=cluster)
  results = response["containerInstanceArns"]
  while "NextToken" in response:
      response = ecs.list_container_instances(
        cluster=cluster, 
        NextToken=response["NextToken"]
        )
      results.extend(response["containerInstanceArns"])
  return results

# Returns a list of services (Arn) for a given cluster
def get_services_by_cluster(cluster):
  response = ecs.list_services(cluster=cluster)
  results = response["serviceArns"]
  while "NextToken" in response:
      response = ecs.list_services(
        cluster=cluster, 
        NextToken=response["NextToken"]
        )
      results.extend(response["serviceArns"])
  return results

# Returns a list of tasks (Arn) for a given service of a cluster
def get_tasks_by_service(cluster, service):
  response = ecs.list_tasks(cluster=cluster, serviceName=service)
  results = response["taskArns"]
  while "NextToken" in response:
      response = ecs.list_tasks(
        cluster=cluster,
        serviceName=service,
        NextToken=response["NextToken"]
        )
      results.extend(response["taskArns"])
  return results

## Writing Metric Data to Cloudwatch

def lambda_handler(event, context):

      ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom ECS Service Quota utilization metrics in Cloudwatch ...")

    # Total number of Ecs Clusters
    metric_count = float(len(get_ecs_clusters_by_account()))
    metric_name = "ClustersPerAccount"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))
    
    # Iterate over each ecs cluster
    for cluster in get_ecs_clusters_by_account():

      # Total number of container instances per cluster
      metric_count = float(len(get_container_instances_by_cluster(cluster)))
      metric_name = "ContainerInstancesPerCluster"
      dimension = [{"Name": "Cluster", "Value": cluster.split("/")[1]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, cluster.split("/")[1]))
    
      # Total number of services per cluster
      metric_count = float(len(get_services_by_cluster(cluster)))
      metric_name = "ServicesPerCluster"
      dimension = [{"Name": "Cluster", "Value": cluster.split("/")[1]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, cluster.split("/")[1]))
    
    # Iterate over each service in the cluster
      for svc in get_services_by_cluster(cluster):
        # Total number of services per cluster
        metric_count = float(len(get_tasks_by_service(cluster, svc)))
        metric_name = "TasksPerService"
        dimension = [{"Name": "Cluster", "Value": svc.split("/")[1]}, {"Name": "Service", "Value": svc.split("/")[2]}]
        cw_data(CWNamespace, metric_name, metric_count, dimension)
        LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}:{4}.".format(metric_name, metric_count, CWNamespace, svc.split("/")[1], svc.split("/")[2]))
