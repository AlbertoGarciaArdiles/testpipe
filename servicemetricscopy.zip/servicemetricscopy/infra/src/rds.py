import boto3
import json
import logging
import os
from datetime import datetime
from datetime import timedelta

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
rdsClient = boto3.client('rds')
CWNamespace = 'CustomMetrics/RDS'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# This function gets the number of rds instances
def get_rds_db_instances(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_db_instances')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['DBInstances']:
            metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of rds db subnet groups
def get_rds_db_subnet_groups(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_db_subnet_groups')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['DBSubnetGroups']:
            metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of rds db proxies
def get_rds_db_proxies(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_db_proxies')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['DBProxies']:
            metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of rds db security groups
def get_rds_db_security_groups(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_db_security_groups')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['DBSecurityGroups']:
            metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of rds db option groups
def get_rds_db_option_groups(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_option_groups')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['OptionGroupsList']:
            metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of rds parameter groups
def get_rds_db_parameter_groups(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_db_parameter_groups')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['DBParameterGroups']:
            metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of max read replicas per master
def get_rds_max_read_replicas_per_master(rds_client):
    metric = 0
    paginator = rds_client.get_paginator('describe_db_instances')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_instance in page['DBInstances']:
            if len(db_instance['ReadReplicaDBInstanceIdentifiers']) > metric:
                metric = len(db_instance['ReadReplicaDBInstanceIdentifiers'])

    paginator = rds_client.get_paginator('describe_db_clusters')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for db_cluster in page['DBClusters']:
            if len(db_cluster['ReadReplicaIdentifiers']) > metric:
                metric = len(db_cluster['ReadReplicaIdentifiers'])

    LOGGER.info("Value {0}".format(metric))
    return metric

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom RDS utilization metrics in Cloudwatch ...")

    metric_count = get_rds_db_instances(rdsClient)
    metric_name = "NumberOfRDSDBInstances"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_rds_db_subnet_groups(rdsClient)
    metric_name = "NumberOfRDSSubnetGroups"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))
    
    metric_count = get_rds_db_proxies(rdsClient)
    metric_name = "NumberOfRDSProxies"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_rds_db_security_groups(rdsClient)
    metric_name = "NumberOfRDSSecurityGroups"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_rds_db_option_groups(rdsClient)
    metric_name = "NumberOfRDSOptionGroups"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_rds_db_parameter_groups(rdsClient)
    metric_name = "NumberOfRDSParameterGroups"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_rds_max_read_replicas_per_master(rdsClient)
    metric_name = "NumberOfMaxReadReplicasPerMaster"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))