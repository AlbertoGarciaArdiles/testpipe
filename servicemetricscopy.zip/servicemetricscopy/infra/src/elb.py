import boto3
import json
import logging
import os

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
elbv2 = boto3.client('elbv2')
CWNamespace = 'CustomMetrics/ELBV2'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response
###########################################
# Returns a list of the elbv2 groups
def get_load_balancers():
  response = elbv2.describe_load_balancers()
  results = response["LoadBalancers"]
  while "NextMarker" in response:
      response = elbv2.describe_load_balancers(NextMarker=response["NextMarker"])
      results.extend(response["LoadBalancers"])
  return results

# Returns a list of the elbv2 target groups
def get_target_groups():
  response = elbv2.describe_target_groups()
  results = response["TargetGroups"]
  while "NextMarker" in response:
      response = elbv2.describe_target_groups(NextMarker=response["NextMarker"])
      results.extend(response["TargetGroups"])
  return results

# Returns all target groups per provided elb
def get_target_groups_per_elb(elb):
  response = elbv2.describe_target_groups(LoadBalancerArn=elb['LoadBalancerArn'])
  results = response["TargetGroups"]
  while "NextMarker" in response:
      response = elbv2.describe_target_groups(LoadBalancerArn=elb['LoadBalancerArn'], NextMarker=response["NextMarker"])
      results.extend(response["TargetGroups"])
  return results

# Returns all listeners
def get_listeners():
  response = elbv2.describe_load_balancers()
  results = response["LoadBalancers"]
  while "NextMarker" in response:
      response = elbv2.describe_load_balancers(NextMarker=response["NextMarker"])
      results.extend(response["LoadBalancers"])
  return results

# Returns all application load balancers
def get_application_load_balancers():
  response = elbv2.describe_load_balancers()
  keyValList = ['application']
  results = list(filter(lambda d: d['Type'] in keyValList, response["LoadBalancers"]))
  while "NextMarker" in response:
    response = elbv2.describe_load_balancers(NextMarker=response["NextMarker"])
    results.extend(list(filter(lambda d: d['Type'] in keyValList, response["LoadBalancers"])))
  return results

# Returns all network load balancers
def get_network_load_balancers():
  response = elbv2.describe_load_balancers()
  keyValList = ['network']
  results = list(filter(lambda d: d['Type'] in keyValList, response["LoadBalancers"]))
  while "NextMarker" in response:
    response = elbv2.describe_load_balancers(NextMarker=response["NextMarker"])
    results.extend(list(filter(lambda d: d['Type'] in keyValList, response["LoadBalancers"])))
  return results

# Returns all listeners per provided elb
def get_listeners_per_elb(elb):
  response = elbv2.describe_listeners(LoadBalancerArn=elb['LoadBalancerArn'])
  results = response["Listeners"]
  while "NextMarker" in response:
      response = elbv2.describe_listeners(LoadBalancerArn=elb['LoadBalancerArn'], NextMarker=response["NextMarker"])
      results.extend(response["Listeners"])
  return results

# Returns all rules per provided application load balancers
def get_rules_per_alb(elb):
    listeners =  elbv2.describe_listeners(LoadBalancerArn=elb['LoadBalancerArn'])
    for listener in listeners['Listeners']:
        response = elbv2.describe_rules(ListenerArn=listener['ListenerArn'])
        results = response["Rules"]
        while "NextMarker" in response:
            response = elbv2.describe_listener_certificates(ListenerArn=listener['ListenerArn'], NextMarker=response["NextMarker"])
            results.extend(response["Rules"])
        return results


# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom elbv2 Service Quota utilization metrics in Cloudwatch ...")

    # Total number of application load balancers in the current region
    metric_count = float(len(get_application_load_balancers()))
    metric_name = "ApplicationLoadBalancersPerRegion"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    # Total number of network load balancers in the current region
    metric_count = float(len(get_network_load_balancers()))
    metric_name = "NetworkLoadBalancersPerRegion"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    # Total number of target groups in the current region
    metric_count = float(len(get_target_groups()))
    metric_name = "TargetGroupsPerRegion"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    for elb in get_application_load_balancers():
      # Total number of listeners per application load balancer
      metric_count = float(len(get_listeners_per_elb(elb)))
      metric_name = "ListenersPerApplicationLoadBalancer"
      dimension = [{"Name": "ELBName", "Value": elb["LoadBalancerName"]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, elb["LoadBalancerName"]))

      # Total number of target groups per application load balancer
      metric_count = float(len(get_target_groups_per_elb(elb)))
      metric_name = "TargetGroupsPerApplicationLoadBalancer"
      dimension = [{"Name": "ELBName", "Value": elb["LoadBalancerName"]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, elb["LoadBalancerName"]))

      # Total number of rules per application load balancer
      metric_count = float(len(get_rules_per_alb(elb)))
      metric_name = "RulesPerApplicationLoadBalancer"
      dimension = [{"Name": "ELBName", "Value": elb["LoadBalancerName"]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, elb["LoadBalancerName"]))

    for elb in get_network_load_balancers():
      # Total number of listeners per network load balancer
      metric_count = float(len(get_listeners_per_elb(elb)))
      metric_name = "ListenersPerNetworkLoadBalancer"
      dimension = [{"Name": "ELBName", "Value": elb["LoadBalancerName"]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, elb["LoadBalancerName"]))

      # Total number of target groups per network load balancer
      metric_count = float(len(get_target_groups_per_elb(elb)))
      metric_name = "TargetGroupsPerNetworkLoadBalancer"
      dimension = [{"Name": "ELBName", "Value": elb["LoadBalancerName"]}]
      cw_data(CWNamespace, metric_name, metric_count, dimension)
      LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, elb["LoadBalancerName"]))
