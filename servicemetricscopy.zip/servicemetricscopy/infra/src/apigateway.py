import boto3
import json
import logging
import os

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
apigateway = boto3.client('apigateway')
apigatewayv2 = boto3.client('apigatewayv2')
CWNamespace = 'CustomMetrics/ApiGateway'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

############################# V1 #############################################
# Gets all rest api keys
def get_api_keys():
  response = apigateway.get_api_keys()
  results = response["items"]
  while "position" in response:
      response = apigateway.get_api_keys(position=response["position"])
      results.extend(response["items"])
  return results

# Gets all rest apis
def get_rest_apis():
  response = apigateway.get_rest_apis()
  results = response["items"]
  while "position" in response:
      response = apigateway.get_rest_apis(position=response["position"])
      results.extend(response["items"])
  return results

# Gets rest api client certificates
def get_client_certificates():
  response = apigateway.get_client_certificates()
  results = response["items"]
  while "position" in response:
      response = apigateway.get_client_certificates(position=response["position"])
      results.extend(response["items"])
  return results

# Gets all resources for a provided rest api
def get_resources(ApiId):
  response = apigateway.get_resources(restApiId=ApiId)
  results = response["items"]
  while "position" in response:
      response = apigateway.get_resources(restApiId=ApiId, position=response["position"])
      results.extend(response["items"])
  return results

# Gets all stages for a provided rest api
def get_rest_api_stages(ApiId):
  response = apigateway.get_stages(restApiId=ApiId)
  results = response["item"]
  while "position" in response:
      response = apigateway.get_stages(restApiId=ApiId, position=response["position"])
      results.extend(response["item"])
  return results

# Gets all rest api vpc links
def get_vpc_links():
  response = apigateway.get_vpc_links()
  results = response["items"]
  while "position" in response:
      response = apigateway.get_vpc_links(position=response["position"])
      results.extend(response["items"])
  return results

# Gets all rest api usage plans
def get_usage_plans():
  response = apigateway.get_usage_plans()
  results = response["items"]
  while "position" in response:
      response = apigateway.get_usage_plans(position=response["position"])
      results.extend(response["items"])
  return results

# Gets all usage plans per api key of a provided rest api
def get_usage_plans_per_api_key(keyId):
  response = apigateway.get_usage_plans(keyId=keyId)
  results = response["items"]
  while "position" in response:
      response = apigateway.get_usage_plans(keyId=keyId, position=response["position"])
      results.extend(response["items"])
  return results

############################# V2 #############################################
# Gets all http and websocket apis
def get_apis():
  response = apigatewayv2.get_apis()
  results = response["Items"]
  while "NextToken" in response:
      response = apigatewayv2.get_apis(NextToken=response["NextToken"])
      results.extend(response["Items"])
  return results

# Gets all http apis
def get_http_apis():
  response = apigatewayv2.get_apis()
  keyValList = ['HTTP']
  results = list(filter(lambda d: d['ProtocolType'] in keyValList, response["Items"]))
  while "NextToken" in response:
    response = apigatewayv2.get_apis(NextToken=response["NextToken"])
    results.extend(list(filter(lambda d: d['ProtocolType'] in keyValList, response["Items"])))
  return results

# Gets all websocket apis
def get_websocket_apis():
  response = apigatewayv2.get_apis()
  keyValList = ['WEBSOCKET']
  results = list(filter(lambda d: d['ProtocolType'] in keyValList, response["Items"]))
  while "NextToken" in response:
    response = apigatewayv2.get_apis(NextToken=response["NextToken"])
    results.extend(list(filter(lambda d: d['ProtocolType'] in keyValList, response["Items"])))
  return results

# Gets all http and websocket api domain names
def get_domain_names():
  response = apigatewayv2.get_domain_names()
  results = response["Items"]
  while "NextToken" in response:
      response = apigatewayv2.get_domain_names(NextToken=response["NextToken"])
      results.extend(response["Items"])
  return results

# Gets all routes for a provided api
def get_routes(ApiId):
  response = apigatewayv2.get_routes(ApiId=ApiId)
  results = response["Items"]
  while "NextToken" in response:
      response = apigatewayv2.get_routes(ApiId=ApiId, NextToken=response["NextToken"])
      results.extend(response["Items"])
  return results

# Gets all stages for a provided api
def get_stages(ApiId):
  response = apigatewayv2.get_stages(ApiId=ApiId)
  results = response["Items"]
  while "NextToken" in response:
      response = apigatewayv2.get_stages(ApiId=ApiId, NextToken=response["NextToken"])
      results.extend(response["Items"])
  return results

# Gets all vpc links for http and websocket apis
def get_vpc_links_v2():
  response = apigatewayv2.get_vpc_links()
  results = response["Items"]
  while "NextToken" in response:
      response = apigatewayv2.get_vpc_links(NextToken=response["NextToken"])
      results.extend(response["Items"])
  return results

# Gets all subnets for a provided vpc link
def get_subnets_per_vpc_link_v2(VpcLinkId):
  response = apigatewayv2.get_vpc_link(VpcLinkId=VpcLinkId)
  results = response["SubnetIds"]
  while "NextToken" in response:
      response = apigatewayv2.get_vpc_links(VpcLinkId=VpcLinkId, NextToken=response["NextToken"])
      results.extend(response["SubnetIds"])
  return results

####################################################################

def lambda_handler(event, context):
  #utilization for APIKeys
  metric_count = float(len(get_api_keys()))
  metric_name = "APIKeys"
  cw_data(CWNamespace, metric_name, metric_count)
  LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

  #utilization for ClientCertificates
  metric_count = float(len(get_client_certificates()))
  metric_name = "ClientCertificates"
  cw_data(CWNamespace, metric_name, metric_count)
  LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

  #utilization for CustomDomainNames
  metric_count = float(len(get_domain_names()))
  metric_name = "CustomDomainNames"
  cw_data(CWNamespace, metric_name, metric_count)
  LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

  #utilization for VPCLinks
  metric_count = float(len(get_vpc_links()))
  metric_name = "VPCLinks"
  cw_data(CWNamespace, metric_name, metric_count)
  LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

  #utilization for VPCLinks(V2)
  metric_count = float(len(get_vpc_links_v2()))
  metric_name = "VPCLinks(V2)"
  cw_data(CWNamespace, metric_name, metric_count)
  LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

  #utilization for UsagePlans
  metric_count = float(len(get_usage_plans()))
  metric_name = "UsagePlans"
  cw_data(CWNamespace, metric_name, metric_count)
  LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

  for api in get_rest_apis():
    #utilazation of resources per rest api
    metric_count = float(len(get_resources(api['id'])))
    metric_name = "ResourcesPerRESTAPI"
    dimension = [{"Name": "ApiId", "Value": api['id']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, api['id']))

    #utilazation of stages per rest api
    metric_count = float(len(get_rest_api_stages(api['id'])))
    metric_name = "StagesPerAPI"
    dimension = [{"Name": "ApiId", "Value": api['id']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, api['id']))

  for api in get_http_apis():
    #utilazation of rouates per http api
    metric_count = float(len(get_routes(api['ApiId'])))
    metric_name = "RoutesPerHTTPAPI"
    dimension = [{"Name": "ApiId", "Value": api['ApiId']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, api['ApiId']))

    #utilazation of stages per http api
    metric_count = float(len(get_stages(api['ApiId'])))
    metric_name = "StagesPerAPI"
    dimension = [{"Name": "ApiId", "Value": api['ApiId']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, api['ApiId']))

  for api in get_websocket_apis():
    #utilazation of routes per websocket api
    metric_count = float(len(get_routes(api['ApiId'])))
    metric_name = "RoutesPerWebSocketAPI"
    dimension = [{"Name": "ApiId", "Value": api['ApiId']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, api['ApiId']))

    #utilazation of stages per websocket api
    metric_count = float(len(get_stages(api['ApiId'])))
    metric_name = "StagesPerAPI"
    dimension = [{"Name": "ApiId", "Value": api['ApiId']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, api['ApiId']))

  for apikey in get_api_keys():
    #utilazation of usage plans per api key
    metric_count = float(len(get_usage_plans_per_api_key(apikey['id'])))
    metric_name = "StagesPerAPI"
    dimension = [{"Name": "ApiKey", "Value": apikey['id']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, apikey['id']))

  for link in get_vpc_links_v2():
    #utilazation of subnets per vpc link
    metric_count = float(len(get_subnets_per_vpc_link_v2(link['VpcLinkId'])))
    metric_name = "SubnetsPerVPCLink(V2)"
    dimension = [{"Name": "VPCLink(V2)", "Value": link['VpcLinkId']}]
    cw_data(CWNamespace, metric_name, metric_count, dimension)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/{3}.".format(metric_name, metric_count, CWNamespace, link['VpcLinkId']))
