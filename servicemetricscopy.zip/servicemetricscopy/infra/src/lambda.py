import boto3
import json
import logging
import os

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
ec2Client = boto3.client('ec2')
CWNamespace = 'CustomMetrics/Lambda'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# Returns an array of NetworkInterfaces intended for Lambda
def get_lambda_enis(ec2_client):
	lambda_enis = []
	vpc_id = ec2_client.describe_vpcs()['Vpcs'][0]['VpcId']
	paginator = ec2_client.get_paginator('describe_network_interfaces')
	page_iterator = paginator.paginate ( Filters=[ {'Name':'vpc-id','Values':[vpc_id]}] )
	for page in page_iterator:
		for eni in page['NetworkInterfaces']:
			if eni['InterfaceType'] == 'lambda':
				lambda_enis.append( eni )
	return lambda_enis

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom Lambda metrics in Cloudwatch ...")

    # Total number of Lambda ENIs in
    metric_count = float(len(get_lambda_enis(ec2Client)))
    metric_name = "LambdaEnisPerVpc"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))
