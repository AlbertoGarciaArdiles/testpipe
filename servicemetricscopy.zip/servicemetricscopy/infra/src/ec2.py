import boto3
import json
import logging
import os
from datetime import datetime
from datetime import timedelta

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
ec2Client = boto3.client('ec2')
CWNamespace = 'CustomMetrics/EC2'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# This function gets the number of existing elastic ips classic
def get_ec2_classic_elastic_ips(ec2_client):
    metric = 0
    response = ec2_client.describe_addresses( Filters=[{"Name":"domain","Values":["standard"]}] )
    for address in response['Addresses']:
        metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of existing elastic ips for vpc
def get_ec2_vpc_elastic_ips(ec2_client):
    metric = 0
    response = ec2_client.describe_addresses( Filters=[{"Name":"domain","Values":["vpc"]}] )
    for address in response['Addresses']:
        metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

def get_running_ondemand_standard_instances():
    metric = 0
    now = datetime.now()
    response = cloudwatch.get_metric_data(
        MetricDataQueries=[
            {
                "Id":"query",
                "Period":300,
                "Expression":"SELECT MAX(ResourceCount) FROM \"AWS/Usage\" WHERE Class = 'Standard/OnDemand' AND Resource = 'vCPU' AND Service = 'EC2' AND Type = 'Resource'"
            }],
        StartTime = now - timedelta(minutes=5),
        EndTime = now,
        MaxDatapoints=5
        )

    if len(response['MetricDataResults'][0]['Values']) > 0:
        metric = response['MetricDataResults'][0]['Values'][0]

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the value of reserved instances
def get_reserved_instances_per_actual_month(ec2_client):
    metric = 0
    actual_month = datetime.now().month

    response = ec2_client.describe_reserved_instances()
    actual_month_reserved_instances = []

    for reserved_instance in response['ReservedInstances']:
        if reserved_instance['Start'].month == actual_month:
            actual_month_reserved_instances.append(reserved_instance)

    metric = len(actual_month_reserved_instances)
    return metric

# This function gets the value of high memory on demand instances
def get_running_ondemand_highmemory_instances(ec2_client):
    metric = 0
    now = datetime.now()
    response = cloudwatch.get_metric_data(
        MetricDataQueries=[
            {
                "Id":"query",
                "Period":300,
                "Expression":"SELECT MAX(ResourceCount) FROM \"AWS/Usage\" WHERE Class = 'HighMem/OnDemand' AND Resource = 'vCPU' AND Service = 'EC2' AND Type = 'Resource'"
            }],
        StartTime = now - timedelta(minutes=5),
        EndTime = now,
        MaxDatapoints=5
        )

    if len(response['MetricDataResults'][0]['Values']) > 0:
        metric = response['MetricDataResults'][0]['Values'][0]

    LOGGER.info("Value {0}".format(metric))
    return metric

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom EC2 utilization metrics in Cloudwatch ...")

    metric_count = get_ec2_classic_elastic_ips(ec2Client)
    metric_name = "NumberOfEC2ClassicElasticIPs"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_ec2_vpc_elastic_ips(ec2Client)
    metric_name = "NumberOfEC2VPCElasticIPs"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_running_ondemand_standard_instances()
    metric_name = "NumberOfEC2OnDemandStandardInstances"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_reserved_instances_per_actual_month(ec2Client)
    metric_name = "ReservedInstancesPerActualMonth"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_running_ondemand_highmemory_instances(ec2Client)
    metric_name = "NumberOfEC2OnDemandHighMemoryInstances"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))