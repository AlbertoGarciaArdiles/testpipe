import boto3
import json
import logging
import os
from datetime import datetime
from datetime import timedelta

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
CWNamespace = 'CustomMetrics/SNS'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# This function gets the maximum of published messages by the minute summarized for all the SNS Topics in an account
def get_metric_data(cloudwatch, stat_period):
  now = datetime.now()

  #Search for all the values gotten by the minute
  search_expresion = "SEARCH(' {AWS/SNS,TopicName} MetricName=\"NumberOfMessagesPublished\" ', 'Sum', 60)"

  response = cloudwatch.get_metric_data(
    MetricDataQueries = [ { 'Id': 'name', 'Expression': search_expresion } ],
    StartTime = now - timedelta( minutes = stat_period ),
    EndTime = now,
    ScanBy = 'TimestampDescending')

  estimated_max_published_messages = 0
  for result in response['MetricDataResults']:
    if ( len(result['Values']) > 0 ):
      estimated_max_published_messages += max(result['Values'])

  return estimated_max_published_messages


# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom SNS utilization metrics in Cloudwatch ...")

    metric_count = get_metric_data(cloudwatch, 5)
    metric_name = "NumberOfMessagesPublishedPerMinute"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))
