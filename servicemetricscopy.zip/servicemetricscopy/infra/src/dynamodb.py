import boto3
import json
import logging
import os
from datetime import datetime
from datetime import timedelta

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
dynamoClient = boto3.client('dynamodb')
CWNamespace = 'CustomMetrics/DynamoDB'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# This function gets the value of the Account-Level read Throughput limit
def get_account_level_read_throughput_limit():
    metric = 0
    now = datetime.now()
    response = cloudwatch.get_metric_data(
        MetricDataQueries=[
            {
                "Id":"query",
                "Period":300,
                "Expression":"SELECT MAX(ResourceCount) FROM \"AWS/Usage\" WHERE Class = 'None' AND Resource = 'AccountProvisionedReadCapacityUnits' AND Service = 'DynamoDB' AND Type = 'Resource'"
            }],
        StartTime = now - timedelta(minutes=5),
        EndTime = now,
        MaxDatapoints=5
        )

    if len(response['MetricDataResults'][0]['Values']) > 0:
        metric = response['MetricDataResults'][0]['Values'][0]

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the value of the Account-Level read Throughput limit
def get_account_level_write_throughput_limit():
    metric = 0
    now = datetime.now()
    response = cloudwatch.get_metric_data(
        MetricDataQueries=[
            {
                "Id":"query",
                "Period":300,
                "Expression":"SELECT MAX(ResourceCount) FROM \"AWS/Usage\" WHERE Class = 'None' AND Resource = 'AccountProvisionedWriteCapacityUnits' AND Service = 'DynamoDB' AND Type = 'Resource'"
            }],
        StartTime = now - timedelta(minutes=5),
        EndTime = now,
        MaxDatapoints=5
        )

    if len(response['MetricDataResults'][0]['Values']) > 0:
        metric = response['MetricDataResults'][0]['Values'][0]

    LOGGER.info("Value {0}".format(metric))
    return metric

def get_table_level_read_throughput_limit():
    metric = 0
    response = dynamoClient.list_tables()

    for table in response['TableNames']:
    	response = dynamoClient.describe_table(TableName=table)
    	if response['Table']['ProvisionedThroughput']['ReadCapacityUnits'] > metric:
    		metric = response['Table']['ProvisionedThroughput']['ReadCapacityUnits']
    	if 'GlobalSecondaryIndexes' in response['Table']:
        	for globalsecondaryindex in response['Table']['GlobalSecondaryIndexes']:
        		if globalsecondaryindex['ProvisionedThroughput']['ReadCapacityUnits'] > metric:
        			metric = globalsecondaryindex['ProvisionedThroughput']['ReadCapacityUnits']

    return metric

def get_table_level_write_throughput_limit():
    metric = 0
    response = dynamoClient.list_tables()

    for table in response['TableNames']:
    	response = dynamoClient.describe_table(TableName=table)
    	if response['Table']['ProvisionedThroughput']['WriteCapacityUnits'] > metric:
    		metric = response['Table']['ProvisionedThroughput']['WriteCapacityUnits']
    	if 'GlobalSecondaryIndexes' in response['Table']:
        	for globalsecondaryindex in response['Table']['GlobalSecondaryIndexes']:
        		if globalsecondaryindex['ProvisionedThroughput']['WriteCapacityUnits'] > metric:
        			metric = globalsecondaryindex['ProvisionedThroughput']['WriteCapacityUnits']

    return metric

def get_number_of_tables():
    metric = 0

    paginator = dynamoClient.get_paginator('list_tables')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for table in page['TableNames']:
        	metric+=1

    return metric

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom DynamoDB utilization metrics in Cloudwatch ...")

    metric_count = get_account_level_read_throughput_limit()
    metric_name = "NumberAccountLevelReadThroughputLimit"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_account_level_write_throughput_limit()
    metric_name = "NumberAccountLevelWriteThroughputLimit"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_table_level_read_throughput_limit()
    metric_name = "NumberTableLevelReadThroughputLimit"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_table_level_write_throughput_limit()
    metric_name = "NumberTableLevelWriteThroughputLimit"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_number_of_tables()
    metric_name = "NumberOfTables"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))