import boto3
import json
import logging
import os

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
autoscaling = boto3.client('autoscaling')
CWNamespace = 'CustomMetrics/AutoScaling'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# Returns a list of the autoscaling groups
def get_auto_scaling_groups():
  response = autoscaling.describe_auto_scaling_groups()
  results = response["AutoScalingGroups"]
  while "NextToken" in response:
      response = autoscaling.describe_auto_scaling_groups(NextToken=response["NextToken"])
      results.extend(response["AutoScalingGroups"])
  return results

# Returns a list of the launch configurations
def get_launch_configurations():
  response = autoscaling.describe_launch_configurations()
  results = response["LaunchConfigurations"]
  while "NextToken" in response:
      response = autoscaling.describe_launch_configurations(NextToken=response["NextToken"])
      results.extend(response["LaunchConfigurations"])
  return results

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom autoscaling Service Quota utilization metrics in Cloudwatch ...")

    # Total number of autoscaling groups
    metric_count = float(len(get_auto_scaling_groups()))
    metric_name = "AutoscalingGroups"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    # Total number of launch configurations
    metric_count = float(len(get_launch_configurations()))
    metric_name = "LaunchConfigurations"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))
