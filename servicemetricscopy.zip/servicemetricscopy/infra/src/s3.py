import boto3
import json
import logging
import os

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
s3Client = boto3.client('s3')
s3controlClient = boto3.client('s3control')
CWNamespace = 'CustomMetrics/S3'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# This function gets the number of S3 Buckets
def get_s3_buckets(s3Client):
    metric = 0
    response = s3Client.list_buckets()
    for bucket in response['Buckets']:
        metric+=1

    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of S3 Access Points
def get_s3_access_points(s3controlClient):
    metric = 0
    accountid = boto3.client('sts').get_caller_identity().get('Account')
    my_session = boto3.session.Session()
    my_region = my_session.region_name

    response = s3Client.list_buckets()
    for bucket in response['Buckets']:
        try: 
            location = s3Client.get_bucket_location(Bucket=bucket['Name'])['LocationConstraint']
            #print ("location: {0}, region {1}".format(location, my_region))
            location = 'us-east-1' if location == None else location
            if location == my_region:
                response = s3controlClient.list_access_points(AccountId=accountid,Bucket=bucket['Name'])
                for ap in response['AccessPointList']:
                    metric+=1
        except:
            LOGGER.error("Error when trying getting access to a bucket info. Not enough permissions to: {0}".format(bucket['Name']))

    LOGGER.info("Value {0}".format(metric))
    return metric

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom S3 utilization metrics in Cloudwatch ...")

    metric_count = get_s3_buckets(s3Client)
    metric_name = "NumberOfS3Buckets"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_s3_access_points(s3controlClient)
    metric_name = "NumberOfS3AccessPointPerAccount"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))