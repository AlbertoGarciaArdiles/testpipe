import boto3
import json
import logging
import os
from datetime import datetime
from datetime import timedelta

# Intializing Logging
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv('LOGLEVEL', logging.INFO))

# Setting some global variables
cloudwatch = boto3.client('cloudwatch')
elasticacheClient = boto3.client('elasticache')
CWNamespace = 'CustomMetrics/elasticache'

# Puts the utilization data in cloudwatch metrics
def cw_data(nameSpace, metricName, value, dimensions=[], unit='None'):
    response = cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': metricName,
                'Dimensions': dimensions,
                'Unit': unit,
                'Value': value
            },
        ],
        Namespace=nameSpace
    )
    return response

# This function gets the number of cache security groups
def get_cache_security_groups(elasticacheClient):
    metric = 0
    paginator = elasticacheClient.get_paginator('describe_cache_security_groups')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for cachesg in page['CacheSecurityGroups']:
            metric+=1


    LOGGER.info("Value {0}".format(metric))
    return metric

# This function gets the number of cache security groups
def get_cache_subnet_groups(elasticacheClient):
    metric = 0
    paginator = elasticacheClient.get_paginator('describe_cache_subnet_groups')
    page_iterator = paginator.paginate()
    for page in page_iterator:
        for cachesg in page['CacheSubnetGroups']:
            metric+=1


    LOGGER.info("Value {0}".format(metric))
    return metric

# Entry point to the lambda
def lambda_handler(event, context):
    ## Creates Cloudwatch Metric data for:
    LOGGER.info("Creating custom Elasticache utilization metrics in Cloudwatch ...")

    ## metric_count = get_cache_security_groups(elasticacheClient)
    ## metric_name = "NumberOfCacheSecurityGroups"
    ## cw_data(CWNamespace, metric_name, metric_count)
    ## LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))

    metric_count = get_cache_subnet_groups(elasticacheClient)
    metric_name = "NumberOfCacheSubnetGroups"
    cw_data(CWNamespace, metric_name, metric_count)
    LOGGER.info("Putting {0} : {1} into Cloudwatch metrics {2}/[No Dimensions].".format(metric_name, metric_count, CWNamespace))
