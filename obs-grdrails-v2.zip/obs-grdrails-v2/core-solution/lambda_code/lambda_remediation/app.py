import json
import sys
from pathlib import Path  
file = Path(__file__). resolve()  
package_root_directory = file.parents [1]  
sys.path.append(str(package_root_directory))
import datetime
import boto3
import os
import collections
from lambda_common_lib import EC2_library as ec2lib
from lambda_common_lib import ALB_library as alblib
from lambda_common_lib import ASG_library as asglib
from lambda_common_lib import Common_library as comlib
from lambda_common_lib import ALB_Rem_library as albremlib
from lambda_common_lib import EC2_Rem_library as ec2remlib
from lambda_common_lib import Common_Rem_library as comremlib
# import requests

AUTOMATION_LAMBDA_ROLE_NAME = os.environ['AUTOMATION_LAMBDA_ROLE_NAME']
PARAMETER_PREFIX = os.environ['PARAMETER_PREFIX'] #Should end with "/"
#OBSERVABILITY_AUTOMATION_TAG_KEY = os.environ['OBSERVABILITY_AUTOMATION_TAG_KEY']
LIST_OF_TAGS_FOR_ALARMNAME = os.environ['LIST_OF_TAGS_FOR_ALARMNAME']
TAG_COMPONENT_SEPARATOR = os.environ['TAG_COMPONENT_SEPARATOR']

activate_alarms = False
export_only_ssm_metrics = False
## SAMPLE EVENT
# { "resourceId": "i-000XXXXXXX", "accountID":"123456789012", "activate_alarms": False, "export_only_ssm_metrics": False }
def lambda_handler(event, context):
  print(event)
  
  #get the credentials from the assumed Role
  executionRoleArn = 'arn:aws:iam::'+str(event['accountID'])+':role/' + AUTOMATION_LAMBDA_ROLE_NAME
  sts_client = boto3.client('sts')
  assumed_role_object=sts_client.assume_role(
      RoleArn=executionRoleArn,
      RoleSessionName="AssumeRoleSession1"
  )
  credentials=assumed_role_object['Credentials']

  #ssm client
  ssm = boto3.client(
    'ssm',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
  )
  
  #ec2 client
  ec2 = boto3.client(
    'ec2',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
  )
  
  #cloudwatch client
  cw = boto3.client(
    'cloudwatch',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
  )
  
  #config client
  config = boto3.client(
    'config',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
  )
  
  taggingapi = boto3.client(
    'resourcegroupstaggingapi',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
)

  #elbv2 client
  elbv2 = boto3.client(
    'elbv2',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
  )

  #asg client
  asg = boto3.client(
    'autoscaling',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
  )
  
  #logs client
  logs = boto3.client(
    'logs',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
  )
  
  resourceId_Raw = event['resourceId']

  global activate_alarms
  activate_alarms = json.loads(event['activate_alarms'].lower()) if ('activate_alarms' in event) else False
  export_only_ssm_metrics = json.loads(event['export_only_ssm_metrics'].lower()) if ('export_only_ssm_metrics' in event) else False
  
  resource_type = comlib.__getResourceType ( resourceId_Raw = resourceId_Raw , config = config )
  resourceId_refined = comlib.__getRefined_resourceId ( resourceId_Raw = resourceId_Raw, resource_type = resource_type )
  
  region = config.meta.region_name
  alarm_name_prefix = comlib.buildPrefixForAlarms (resourceId_Raw = resourceId_Raw, config = config, tags_list_to_build_alarmname = LIST_OF_TAGS_FOR_ALARMNAME.split(","), region = region )
  
  if export_only_ssm_metrics:
    return EC2_export_only_ssm_metrics ( ssm, ec2, resourceId_refined )
    #End of Execution
  
  if resource_type == "AWS::EC2::Instance":
    #tagValue = ec2remlib.getTagValueFromInstance ( ec2 , resourceId_Raw , OBSERVABILITY_AUTOMATION_TAG_KEY )
    resp = remediateEC2Resource_Obs_Alarms ( cw, ec2, ssm, resourceId_refined, resource_type, logs, asg, taggingapi, alarm_name_prefix, resourceId_Raw )
  
  elif resource_type == "AWS::ElasticLoadBalancingV2::LoadBalancer":
    #tagValue = albremlib.getTagValueFromALB ( elbv2 , resourceId_Raw , OBSERVABILITY_AUTOMATION_TAG_KEY )
    resp = remediateALBResource_Obs_Alarms ( elbv2, resourceId_Raw, resource_type, resourceId_refined, cw, taggingapi, alarm_name_prefix  )
  
  elif resource_type == "AWS::AutoScaling::AutoScalingGroup":
    resp = remediateASGResource_Obs_Alarms ( cw, ec2, asg, resourceId_refined, resource_type, taggingapi, alarm_name_prefix, resourceId_Raw  )
  
  return resp

def remediateASGResource_Obs_Alarms ( cw, ec2, asg, resourceId_refined, resource_type, taggingapi, alarm_name_prefix, resourceId_Raw ):
  
  platformName = asglib.__getPlatformFromASG( asg, ec2, resourceId_refined )
  disks = asglib.__infereDiskListFromExistingMetrics( cw, resourceId_refined, platformName )
  
  policyAlarms = asglib.__getASGPolicy(
    resourceId_refined = resourceId_refined,
    alarm_name_prefix = alarm_name_prefix,
    disks = disks,
    osType = platformName,
    activate_alarms = activate_alarms )
  
  comremlib.update_alarms_according_to_policy(
    resource_type = resource_type,
    resourceId_refined = resourceId_refined,
    policyAlarms = policyAlarms,
    cw = cw,
    taggingapi = taggingapi,
    activate_alarms = activate_alarms,
    resourceId_Raw = resourceId_Raw)
  
  return {
    "statusCode": 200
  }

def remediateALBResource_Obs_Alarms ( elbv2, resourceId_Raw, resource_type, resourceId_refined, cw, taggingapi, alarm_name_prefix ):
  
  AZs = albremlib.getAZsFromLoadBalancer ( resourceId_Raw = resourceId_Raw, elbv2 = elbv2 )
  TGs = alblib.getTargetGroupsFromLoadBalancer ( elbv2, resourceId_Raw )
  
  policyAlarms = alblib.__getALBPolicy( AZs = AZs, TGs = TGs, ALB_arn = resourceId_Raw, alarm_name_prefix = alarm_name_prefix, activate_alarms = activate_alarms )
  
  comremlib.update_alarms_according_to_policy(
    resource_type = resource_type,
    resourceId_refined = resourceId_refined,
    policyAlarms = policyAlarms,
    cw = cw,
    taggingapi = taggingapi,
    activate_alarms = activate_alarms,
    resourceId_Raw = resourceId_Raw)
  
  return {
    "statusCode": 200
  }

def EC2_export_only_ssm_metrics ( ssm, ec2, resourceId_refined ):
  
  instanceInformation = ec2lib.getInstanceInformation ( ssmclient = ssm, instanceId = resourceId_refined )
  platformType = instanceInformation[ 'PlatformType' ]
  
  ec2_tags = ec2remlib.getTagsFromInstance( ec2client = ec2, instanceId = resourceId_refined )
  InstanceName = [ x['Value'] for x in ec2_tags if x['Key'] == 'Name' ][0]
  parametersPrefix = '/' + '/'.join(InstanceName.split("-")[0:5])
  
  cwagent_config_policy = ec2remlib.getCWAgentPolicyTemplate( tagValue = parametersPrefix, osType = platformType )
  
  resp = ec2remlib.putParameters(
    ssmclient = ssm,
    parametersPrefix = parametersPrefix,
    parameterMetricValue = str(cwagent_config_policy),
    osType = platformType
    )
  
  resp['statusCode'] = 200
  return resp

def remediateEC2Resource_Obs_Alarms ( cw, ec2, ssm, resourceId_refined, resource_type, logs, asg, taggingapi, alarm_name_prefix, resourceId_Raw ):
  #get information about the instance
  
  ec2_instance_info = ec2remlib.getEC2_attributes ( ec2client = ec2, instanceId = resourceId_refined )
  ImageId = ec2_instance_info[ 'ImageId' ]
  InstanceType = ec2_instance_info[ 'InstanceType' ]
  
  #ImageId = ec2remlib.getAttributeEc2 ( ec2client = ec2, instanceId = resourceId_refined, attributeName = 'ImageId' )
  #InstanceType = ec2remlib.getAttributeEc2 ( ec2client = ec2, instanceId = resourceId_refined, attributeName = 'InstanceType' )
  #tagKey = OBSERVABILITY_AUTOMATION_TAG_KEY
  
  ec2_tags = ec2remlib.getTagsFromInstance( ec2client = ec2, instanceId = resourceId_refined )
  
  instanceInformation = ec2lib.getInstanceInformation ( ssmclient = ssm, instanceId = resourceId_refined )
  platformType = instanceInformation[ 'PlatformType' ]
  #tagValue = ec2remlib.getTagValueFromInstance ( ec2client = ec2, instanceId = resourceId_refined, tagKey = tagKey )
  
  #InstanceName = ec2remlib.getTagValueFromInstance ( ec2client = ec2 , instanceId = resourceId_refined , tagKey = 'Name' )
  InstanceName = [ x['Value'] for x in ec2_tags if x['Key'] == 'Name' ][0]
  parametersPrefix = '/' + '/'.join(InstanceName.split("-")[0:5])
  
  #get policytemplate, logicalDiskList and PolicyAlarms
  policy_template = ec2lib.getEC2PolicyTemplate ( tagValue = parametersPrefix , osType = platformType )
  logicalDiskList = ec2lib.getLogicalDiskList ( ssmClient = ssm, instanceId = resourceId_refined, OSType = platformType)
  
  computerName = instanceInformation[ 'ComputerName' ]
  #computerName = ec2lib.getComputerName ( ssmClient = ssm, instanceId = resourceId_refined ) #TODO: IMPROVE GET COMPUTER NAME FROM instanceInformation
  
  # autoscalingGroupName = asglib.getAutoScalingGroupName ( asg, resourceId_refined ) #TODO: IMPROVE GET AUTOSCALING NAME FROM tags
  tag_asg_name_array = [ x['Value'] for x in ec2_tags if x['Key'] == 'aws:autoscaling:groupName' ]
  autoscalingGroupName = tag_asg_name_array[0] if len( tag_asg_name_array ) > 0 else None
  
  if platformType == 'Linux':
    policyAlarms = ec2lib.getPolicyFromTemplateLinux(
      policyTemplate = policy_template, logicalDiskList = logicalDiskList, instanceId = resourceId_refined,
      imageId = ImageId, instanceType = InstanceType, computerName = computerName, autoscalingGroupName = autoscalingGroupName,
      alarm_name_prefix = alarm_name_prefix, activate_alarms = activate_alarms )
  elif platformType == 'Windows':
    policyAlarms = ec2lib.getPolicyFromTemplateWindows(
      policyTemplate = policy_template, logicalDiskList = logicalDiskList, instanceId = resourceId_refined,
      imageId = ImageId, instanceType = InstanceType, computerName = computerName, autoscalingGroupName = autoscalingGroupName,
      alarm_name_prefix = alarm_name_prefix, activate_alarms = activate_alarms )
  
  cwagent_config_policy = ec2remlib.getCWAgentPolicyTemplate( tagValue = parametersPrefix, osType = platformType )
  #cwagent_config_filename = ec2remlib.getCWAgentPolicyTemplate_fileName( tagValue = tagValue, osType = platformType )
  
  ############### METRIC FILTERS ##################
  #metricFilters = policyAlarms['MetricFilters']
  # comremlib.update_metric_filters_according_to_policy ( logs = logs, metricFilters = metricFilters, instanceId=resourceId_refined, computerName = computerName )
  
  comremlib.update_alarms_according_to_policy( resource_type = resource_type, resourceId_refined = resourceId_refined, policyAlarms = policyAlarms, cw = cw, taggingapi = taggingapi, activate_alarms = activate_alarms, resourceId_Raw = resourceId_Raw )
  
  #Create Parameter
  #cwagent_config_filename = cwagent_config_filename.split(".")[0]
  
  #parameterName = '/' + alarm_name_prefix.replace('-','/') + '/' + '/'.join(tagValue.split(TAG_COMPONENT_SEPARATOR)) + '/' + cwagent_config_filename
  
  resp = ec2remlib.putParameters(
    ssmclient = ssm,
    parametersPrefix = parametersPrefix,
    parameterMetricValue = str(cwagent_config_policy),
    osType = platformType
    )

  resp['statusCode'] = 200
  return resp

#Sample output
# {
#   'statusCode' = 200,
#   'parameterName_logs': parameterName_logs,
#   'parameterName_metrics': parameterName_metrics,
#   'parametersExistsAndareEqual': parametersExistsAndareEqual,
#   'parameter_logs_ExistsAndareEqual': parameter_logs_ExistsAndareEqual,
#   'parameter_metrics_ExistsAndareEqual': parameter_metrics_ExistsAndareEqual,
# }