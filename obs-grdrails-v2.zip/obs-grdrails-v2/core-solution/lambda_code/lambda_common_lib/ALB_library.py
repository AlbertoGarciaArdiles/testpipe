import logging
import boto3
import json
import os
import time
import datetime
import traceback
from . import Common_library as comlib
from jinja2 import Environment, DictLoader

LOG_LEVEL = os.environ['LOG_LEVEL']

logger = logging.getLogger()
logger.setLevel( LOG_LEVEL )

def getALBPolicyTemplate( tagValue:str, resource_type:str='AWS::ElasticLoadBalancingV2::LoadBalancer'):
  return comlib.__getPolicyTemplate ( tagValue = tagValue, resource_type = resource_type )


def getAZsFromLoadBalancer( ALBconfigurationItem ):
  logger.debug('## Start Executing: getAZsFromLoadBalancer')
  try:
    return ALBconfigurationItem['configuration']['availabilityZones']
  except Exception as e:
    logger.error("## Error on getAZsFromLoadBalancer Function: " + str(e))
    logger.error(traceback.format_exc())
    raise


def getTargetGroupsFromLoadBalancer( elbv2client, resourceId:str ):
  #resourceId is the ARN in the format
  logger.debug('## Start Executing: getTargetGroupsFromLoadBalancer')
  try:
    response = elbv2client.describe_target_groups( LoadBalancerArn=resourceId )
    return response['TargetGroups']
  except Exception as e:
    logger.error("## Error on getTargetGroupsFromLoadBalancer Function: " + str(e))
    logger.error(traceback.format_exc())
    raise


# def getALBFormattedName ( loadBalancerArn: str ):
#   parts = loadBalancerArn.split(':')
#   return str(parts[ -1 ]).replace('loadbalancer/', '', 1)


def getTargetGroupsForTemplate ( targetGroups:list ):
  tTGs = []
  tTG = { 'TargetGroupName': '', 'TargetGroupSmallName': '' }
  for tg in targetGroups:
    tTG['TargetGroupName'] = tg['TargetGroupArn'].split(':')[-1]
    tTG['TargetGroupSmallName'] = tg['TargetGroupName']
    tTGs.append (tTG.copy())
  
  return tTGs


# def getALBPolicy ( tagValue:str , AZs:list, TGs:list , ALBconfigurationItem, alarm_name_prefix):
#   return __getALBPolicy ( tagValue = tagValue , AZs = AZs, TGs = TGs , ALB_arn = ALBconfigurationItem.get( 'arn' ), ALB_resourceName = ALBconfigurationItem.get ( 'resourceName' ), alarm_name_prefix = alarm_name_prefix )


def __getALBPolicy ( AZs:list, TGs:list , ALB_arn:str, alarm_name_prefix:str, ALB_resourceName:str='', activate_alarms:bool=False ):
  try:
    #get Policy Template
    policy_template = getALBPolicyTemplate ( tagValue = alarm_name_prefix )
    templateTargetGroups = getTargetGroupsForTemplate ( TGs )
  
    j2_env = Environment(loader=DictLoader({'policy': policy_template}), trim_blocks=False)
    LBName_Dimension = comlib.__getRefined_resourceId ( ALB_arn , "AWS::ElasticLoadBalancingV2::LoadBalancer" )
    ITSMActive = 'SERVICENOW_ACTIVE' if activate_alarms else 'SERVICENOW_DEACTIVATED'
    
    output=j2_env.get_template('policy').render(
            targetGroups = templateTargetGroups,
            AZs = AZs,
            LBName_Dimension = LBName_Dimension,
            LBName = ALB_resourceName if ALB_resourceName != '' else LBName_Dimension.split('/')[1],
            ELBType = 'ALB',
            AlarmPrefix = alarm_name_prefix,
            ITSMActive = ITSMActive
        )
    return json.loads(output)
  
  except Exception as e:
    logger.error("## Error on getPolicyFromTemplateWindows Function: " + str(e))
    logger.error(traceback.format_exc())
    logger.error