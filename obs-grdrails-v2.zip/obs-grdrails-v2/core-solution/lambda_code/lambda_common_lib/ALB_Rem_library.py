import logging
import boto3
import json
import os
import time
import datetime
import traceback
from . import Common_library as comlib

LOG_LEVEL = os.environ['LOG_LEVEL']

logger = logging.getLogger()
logger.setLevel( LOG_LEVEL )

def getAZsFromLoadBalancer ( resourceId_Raw:str, elbv2 ):
  try:
    loadBalancers = elbv2.describe_load_balancers ( LoadBalancerArns = [ resourceId_Raw ] )
    return [ { "zoneName" : each['ZoneName'] } for each in loadBalancers['LoadBalancers'][0]['AvailabilityZones'] ]
  except Exception as e:
    logger.error("## Error on getAZsFromLoadBalancer Function: " + str(e))
    logger.error(traceback.format_exc())
    raise

def getTagValueFromALB ( elbv2, resourceId:str, tagKey:str):
    logger.debug('## Start Executing: getTagValueFromALB')
    logger.debug(resourceId)
    logger.debug(tagKey)
    try:
      response = elbv2.describe_tags( ResourceArns = [ resourceId ] )
      for tag in response['TagDescriptions'][0]['Tags']:
        if str(tag['Key']) == tagKey:
          return tag['Value']

      return 'default'
          
    except Exception as e:
      logger.error("## Error on getTagValueFromALB Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e
