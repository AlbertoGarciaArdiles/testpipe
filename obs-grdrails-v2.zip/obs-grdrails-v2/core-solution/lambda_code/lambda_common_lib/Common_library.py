import logging
import boto3
import json
import os
import time
import datetime
from boto3.dynamodb.types import TypeDeserializer
import traceback

LOG_LEVEL = os.environ['LOG_LEVEL']
CONFIG_BUCKET = os.environ['CONFIG_BUCKET']
DYNAMODB_CONFIG_TABLE = os.environ['DYNAMODB_CONFIG_TABLE']
TAG_COMPONENT_SEPARATOR = os.environ['TAG_COMPONENT_SEPARATOR']

logger = logging.getLogger()
logger.setLevel(LOG_LEVEL)

#local clients
s3 = boto3.client('s3')
dyn = boto3.client('dynamodb')

##############################################################################################################################################

def __getRefined_resourceId ( resourceId_Raw:str, resource_type:str ):
  
  if resource_type == "AWS::EC2::Instance":
    return resourceId_Raw
    
  elif resource_type == "AWS::ElasticLoadBalancingV2::LoadBalancer":
    parts = resourceId_Raw.split(':')
    return str(parts[ -1 ]).replace('loadbalancer/', '', 1)
    
  elif resource_type == "AWS::ElasticLoadBalancingV2::TargetGroup":
    return resourceId_Raw.split(':')[-1]

  elif resource_type == "AWS::AutoScaling::AutoScalingGroup":
    return resourceId_Raw.split(':')[-1].split('/')[-1]

def __getResourceType (  resourceId_Raw:str, config ):
  try:
    sql_expression = "SELECT resourceType WHERE resourceid = '{}'".format(resourceId_Raw)
    resp = config.select_resource_config( Expression = sql_expression )
    resp = json.loads(resp['Results'][0])
    
    return resp['resourceType']

  except Exception as e:
      logger.error("## Error on __getResourceType Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e

def __getTags_from_ResourceConfigurationItem (  resourceId_Raw:str, config, specific_tagKey:str=None ):
  try:
    sql_expression = "SELECT tags WHERE resourceid = '{}' ".format(resourceId_Raw)
    resp = config.select_resource_config( Expression = sql_expression )
    logger.info ( resp )
    if specific_tagKey == None:
      return json.loads(resp['Results'][0])['tags']
    else:
      return { 'tag': tag['tag'] for tag in json.loads(resp['Results'][0])['tags'] if tag['key'] == specific_tagKey }

  except Exception as e:
      logger.error("## Error on __getTags_from_ResourceConfigurationItem Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e

def buildPrefixForAlarms ( resourceId_Raw:str , config, tags_list_to_build_alarmname:list, region:str ):
  logger.debug("## Starting buildPrefixForAlarms")
  logger.debug(" resourceId_Raw : {} ".format(resourceId_Raw))
  logger.debug(" region : {} ".format(region))
  print (tags_list_to_build_alarmname)
  try:
    tags_to_build_alarm_name_init = __getTags_from_ResourceConfigurationItem( resourceId_Raw = resourceId_Raw, config = config )
    print ( '## tags_to_build_alarm_name_init' )
    print ( tags_to_build_alarm_name_init )
    tags_to_build_alarm_name = [ x for x in tags_to_build_alarm_name_init if x['key'] in tags_list_to_build_alarmname ]
    print ( '## tags_to_build_alarm_name' )
    print ( tags_to_build_alarm_name )
    regions_list = [
      {'region':'us-east-1', 'short_name':'use1'},
      {'region':'us-west-1', 'short_name':'usw1'},
      {'region':'us-west-2', 'short_name':'usw2'},
      {'region':'sa-east-1', 'short_name':'sae1'}]
    
    alarm_name_prefix = "{}-{}-{}-{}".format(
      [ x['value'] for x in tags_to_build_alarm_name if x['key'] == tags_list_to_build_alarmname[0] ][0],
      [ x['short_name'] for x in regions_list if x['region'] == region ][0],
      [ x['value'] for x in tags_to_build_alarm_name if x['key'] == tags_list_to_build_alarmname[1] ][0],
      [ x['value'] for x in tags_to_build_alarm_name if x['key'] == tags_list_to_build_alarmname[2] ][0]
      )
    
    return alarm_name_prefix.lower()
  except Exception as e:
    logger.error("## Error on buildPrefixForAlarms Function: " + str(e))
    logger.error(traceback.format_exc())
    return 'Incomplete_Tags'.lower()

  
  
  

# Returns the Policy Name and the Key from splitting the TagValue
def __getpolicyName_N_Key ( tagValue:str ):
  componentsList = tagValue.split(TAG_COMPONENT_SEPARATOR)
  policyName = componentsList[0] if componentsList[0] != '' else 'default'
  policyKey = componentsList[1] if len(componentsList) > 1 else 'default'
  return policyName, policyKey;


# Returns the Policy Template from TagValue, ResourceType and optionally Config_Type
def __getPolicyTemplateConfigsV2( tagValue:str, resource_type:str , config_type:str=None):
  logger.debug('## Start Executing: __getPolicyTemplateNamesV2')
  logger.debug('Tag Value: {}'.format(tagValue))
  logger.debug('Resource Type: {}'.format(resource_type))
  logger.debug('Config Type: {}'.format(config_type))
  
  #get the values of the policy and the specific component
  policyName, policyKey = __getpolicyName_N_Key( tagValue = tagValue )

  resource_type = resource_type.replace("::","").lower()
    
  try:
    resp = dyn.get_item(
        TableName=DYNAMODB_CONFIG_TABLE,
        Key = { 'policy_tagValue': { 'S': policyName } },
        AttributesToGet = [resource_type])
        
    logger.info ( 'DynamoDB Response #1 :')
    logger.info ( resp )

    if not 'Item' in resp:
      logger.info('## Policy for name --> {} not found in DynamoDB Table --> {}. Retreiving the default Policy'.format(policyName, DYNAMODB_CONFIG_TABLE))
      resp = dyn.get_item(
          TableName=DYNAMODB_CONFIG_TABLE,
          Key = { 'policy_tagValue': { 'S': 'default' } },
          AttributesToGet = [resource_type])
      logger.info ( 'DynamoDB Response #2 :')
      logger.info ( resp )

    deserializer = TypeDeserializer()
    policies = { k: deserializer.deserialize(v) for k, v in resp.get("Item").items() }
    logger.debug( policies.get( resource_type ) )
    
    if config_type is None:
      for each in policies.get( resource_type ):
        if each.get('key') == policyKey:
          print (each)
          return each
    
    else:
      for each in policies.get( resource_type ):
        if each.get('key') == policyKey and each.get('config_type') == config_type:
          print (each)
          return each
      
  except Exception as e:
      logger.error("## Error on __getPolicyTemplateNamesV2 Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e
  
  raise KeyError('Policy not found for policy_name: {}, policy_key: {}, config_type: {}'.format(policyName, policyKey, config_type))

# Returns the Path Value from the DynamoDB Table
def __getPath ( tagValue:str ):
  logger.debug('## Start Executing: __getPath')
  try:
    
    policyName = __getpolicyName_N_Key( tagValue = tagValue )[0]
    
    resp = dyn.get_item(
      TableName=DYNAMODB_CONFIG_TABLE,
      Key = { 'policy_tagValue': { 'S': policyName } },
      AttributesToGet = ['path'])
    
    if not 'Item' in resp:
      logger.info('## Policy for name --> {} not found in DynamoDB Table --> {}. Retreiving the default Policy'.format(policyName, DYNAMODB_CONFIG_TABLE))
      resp = dyn.get_item(
          TableName=DYNAMODB_CONFIG_TABLE,
          Key = { 'policy_tagValue': { 'S': 'default' } },
          AttributesToGet = ['path'])
      
    deserializer = TypeDeserializer()
    data = { k: deserializer.deserialize(v) for k, v in resp.get("Item").items() }
    
    return data.get('path')
    
  except Exception as e:
    logger.error("## Error on __getPath Function: " + str(e))
    logger.error(traceback.format_exc())
    raise

# Returns the policy template
def __getPolicyTemplate ( tagValue:str, resource_type:str , config_type:str=None ):
  
  policy = __getPolicyTemplateConfigsV2 ( tagValue = tagValue, resource_type = resource_type, config_type = config_type )
  
  try:
    config_file = s3.get_object(
      Bucket = CONFIG_BUCKET,
      Key = __getPath ( tagValue ) + str( policy.get( 'policy_filename' ) ) )
    
    config_file_body = config_file['Body'].read().decode('utf-8')
      
    return config_file_body
  
  except Exception as e:
    logger.error("## Error on __getPolicyTemplate Function: " + str(e))
    logger.error(traceback.format_exc())
    raise


def publishToS3OutputBucket ( bucket:str, mainkey:str, data:dict, aws_req_id:str, instanceId:str ):
  try:
    x = datetime.datetime.now()
    key = mainkey + '/' + x.strftime("%Y") + '/' + x.strftime("%m") + '/' + x.strftime("%d") + '/' + instanceId + '/' + aws_req_id
    s3.put_object(Body=json.dumps(data,indent=4, sort_keys=True), Bucket=bucket, Key=key)
    return key
  except Exception as e:
    logger.error("## Error on putPublishOutput Function: " + str(e))
    logger.error(traceback.format_exc())
    raise


def getTag ( configuration_item:dict, tagKey:str ):
  
  resource_type = configuration_item['resourceType']
  
  if resource_type == "AWS::EC2::Instance":
    TagArray = configuration_item['configuration']['tags']
  elif resource_type == "AWS::ElasticLoadBalancingV2::LoadBalancer":
    TagArray = configuration_item['supplementaryConfiguration']['Tags']

  for tag in TagArray:
      if tag['key'] == tagKey:
          return tag['value']
  
  return ''


def listAlarmsForMetrics ( cwclient, metricName:str, namespace:str, dimensions:list) -> dict:
  logger.debug('## Start Executing: listAlarmsForMetrics')
  
  try:
    response = cwclient.describe_alarms_for_metric(
      MetricName=metricName,
      Namespace=namespace,
      Dimensions=dimensions)
    return response['MetricAlarms']
  
  except Exception as e:
    logger.error("## Error on listAlarmsForMetrics Function: " + str(e))
    logger.error(traceback.format_exc())
    raise


def __compare_ExistingAlarms_with_PolicyAlarms ( existingAlarms:dict, policyAlarms:dict ):
  
  #TODO: make this configurable or get these from the policy
  list_of_fields_to_compare = [ ("S","Statistic") , ("S" , "Period") , ("S" , "EvaluationPeriods") , ("S" , "DatapointsToAlarm") , ("I" , "Threshold") , ("S" , "ComparisonOperator") ]
  
  evaluationResponse = []
  for fieldType, eachField in list_of_fields_to_compare:
    
    fieldEvaluation = { 'field' : eachField , 'status' : 'NON_COMPLIANT' , 'reason' : '' }
    
    if ( eachField in policyAlarms ) and ( eachField in existingAlarms ):
      
      if fieldType == "I":
        
        if int ( policyAlarms[ eachField ] ) == int ( existingAlarms[ eachField ] ):
          fieldEvaluation[ 'status' ] = 'COMPLIANT'
          
      elif str ( policyAlarms[ eachField ] ) == str ( existingAlarms[ eachField ]):
        fieldEvaluation[ 'status' ] = 'COMPLIANT'
      
      fieldEvaluation[ 'reason' ] = 'policyAlarm[' + eachField + '] = ' +  str(policyAlarms[eachField]) + ' and metricAlarm[' + eachField + '] = ' + str(existingAlarms[eachField])
    
    else:
      fieldEvaluation[ 'reason' ] = '{} : is missing and the field is required'.format( eachField )
    
    evaluationResponse.append(fieldEvaluation.copy())
  
  dictresponse = {
    'status' : 'NON_COMPLIANT',
    'summary' : '',
    'detailedFieldEvaluation' : evaluationResponse }

  is_compliant = True
  summary = ''
  for fe in evaluationResponse:
    is_compliant = ( is_compliant and ( fe['status'] == 'COMPLIANT' ) )
    summary += str( fe['reason'] ) + ' | '
  
  dictresponse[ 'status' ] = 'COMPLIANT' if is_compliant else 'NON_COMPLIANT'
  dictresponse[ 'summary' ] = summary
  
  return dictresponse


def validatePolicy ( cwclient, policyAlarms ):
  #For each alarm in the policy, check if already exists an alarm according to the policy
  validatedMetricsList = []
  for policyAlarmMetric in policyAlarms['MetricAlarmsTemplates']:
    
    __validatingMetricResp = {
        'MetricName':policyAlarmMetric['MetricName'],
        'Namespace':policyAlarmMetric['Namespace'],
        'Dimensions':policyAlarmMetric['Dimensions'],
        'FieldsComparisonStatus':{},
        'Status':{ 'State': 'NON_COMPLIANT', 'Reason' : ''}
    }
    
    existingAlarms = listAlarmsForMetrics( cwclient, policyAlarmMetric['MetricName'],
        policyAlarmMetric['Namespace'], policyAlarmMetric['Dimensions'])

    if len( existingAlarms ) < 1:
      __validatingMetricResp['Status']['Reason'] = 'Alarm doesnt exist for detailed MetricName, Namespace and Dimensions'
    else:
      #Compare for each of the existing alarms returned
      #if at least one alarm if compliance
      for m in existingAlarms:
        fieldsComparison = __compare_ExistingAlarms_with_PolicyAlarms ( m, policyAlarmMetric )
        #the resource for example EC2 can have more than one alarm for than one alarm so
        #it is enough that one alarm per metric is compliant
        __validatingMetricResp['FieldsComparisonStatus'] = fieldsComparison
        __validatingMetricResp['Status']['State'] = fieldsComparison['status']
        __validatingMetricResp['Status']['Reason'] = fieldsComparison['summary']
        if fieldsComparison['status'] == 'COMPLIANT':
          break
        elif m == existingAlarms[-1]:
          __validatingMetricResp['FieldsComparisonStatus'] = fieldsComparison
    validatedMetricsList.append( __validatingMetricResp )

  #Build the response summary in status_reason var
  status_state = True
  status_reason = []
  for validatedMetric in validatedMetricsList:
    status_state = (status_state and (validatedMetric['Status']['State'] == 'COMPLIANT'))
    status_reason.append(
        {
            "metricName" : validatedMetric['MetricName'],
            "namespace" : validatedMetric['Namespace'] ,
            "dimensions" : validatedMetric['Dimensions'] ,
            #"state" : str(validatedMetric['FieldsComparisonStatus']['status']) if "status" in validatedMetric['FieldsComparisonStatus'] else 'NON_COMPLIANT',
            "state" : validatedMetric['Status']['State'] if "Status" in validatedMetric else 'NON_COMPLIANT',
            "summary" : validatedMetric['Status']['Reason'] if "Reason" in validatedMetric['Status'] else ''
        } )
  
  if status_state == True: compliance_type = "COMPLIANT"
  else: compliance_type = 'NON_COMPLIANT'
  
  return compliance_type, status_reason