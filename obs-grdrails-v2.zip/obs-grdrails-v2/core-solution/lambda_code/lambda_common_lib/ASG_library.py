import logging
import boto3
import json
import os
import traceback
from . import Common_library as comlib
from jinja2 import Environment, DictLoader

LOG_LEVEL = os.environ['LOG_LEVEL']

logger = logging.getLogger()
logger.setLevel(LOG_LEVEL)

def getASGPolicyTemplate( tagValue:str, osType:str, resource_type:str='AWS::AutoScaling::AutoScalingGroup'):
  return comlib.__getPolicyTemplate ( tagValue = tagValue, resource_type = resource_type, config_type = osType )

def getAutoScalingGroupName ( asgClient, instanceId:str ):
  try:
    resp = asgClient.describe_auto_scaling_instances( InstanceIds = [ instanceId ] )
    if len ( resp['AutoScalingInstances'] ) < 1:
      return None
    else:
      return resp['AutoScalingInstances'][0]['AutoScalingGroupName']
  
  except Exception as e:
      logger.error("## Error on getAutoScalingGroupName Function: " + str(e))
      logger.error(traceback.format_exc())
      raise

def __getASGPolicy ( resourceId_refined:str, alarm_name_prefix:str, disks:list, osType:str, activate_alarms:bool=False ):
  logger.debug('## starting __getASGPolicy')
  try:
    #get Policy Template
    policy_template = getASGPolicyTemplate ( tagValue = alarm_name_prefix, osType = osType )
    logger.debug('## policy_template')
    logger.debug(policy_template)
  
    j2_env = Environment(loader=DictLoader({'policy': policy_template}), trim_blocks=False)
    
    ITSMActive = 'SERVICENOW_ACTIVE' if activate_alarms else 'SERVICENOW_DEACTIVATED'
    
    output=j2_env.get_template('policy').render(
            AutoScalingGroupName = resourceId_refined,
            disks = disks,
            AlarmPrefix = alarm_name_prefix,
            ITSMActive = ITSMActive
        )
    return json.loads(output)
  
  except Exception as e:
    logger.error("## Error on __getASGPolicy Function: " + str(e))
    logger.error(traceback.format_exc())
    raise

def __infereDiskListFromExistingMetrics ( cw, ASG_refined_id:str, platformName:str ):
  try:
    if platformName.capitalize() == 'Windows':
      resp = cw.list_metrics( Namespace = 'CWAgent', MetricName = 'LogicalDisk % Free Space', Dimensions = [ {'Name':'AutoScalingGroupName','Value': ASG_refined_id }, {'Name':'instance'} ] )
      disks = [ {'device':sorted(m['Dimensions'], key=lambda k: k['Name'])[1]['Value'] } for m in  resp['Metrics'] if len(m['Dimensions']) == 2 ]
      return disks
    elif platformName.capitalize() == 'Linux':
      resp = cw.list_metrics( Namespace = 'CWAgent', MetricName = 'disk_used_percent', Dimensions = [ {'Name':'AutoScalingGroupName'}, {'Name':'path'} ] )
      disks = [ {'path':sorted(m['Dimensions'], key=lambda k: k['Name'])[1]['Value'] } for m in  resp['Metrics'] if len(m['Dimensions']) == 2 ]
    
    return disks
  
  except Exception as e:
    logger.error("## Error on infereDiskListFromExistingMetrics Function: " + str(e))
    logger.error(traceback.format_exc())
    raise

def __getPlatformFromASG( asg, ec2, ASG_Refined_Id:str ):
  logger.debug("## Initiating __getPlatformFromASG Function: ")
  try:
    response = asg.describe_auto_scaling_groups(
      AutoScalingGroupNames=[ ASG_Refined_Id] )
    
    instanceIds = [ x['InstanceId'] for x in response['AutoScalingGroups'][0]['Instances'] if x['LifecycleState'] in ['InService','Pending','Pending:Proceed','Pending:Wait'] ]
    response = ec2.describe_instances(
      InstanceIds=instanceIds
      )
    logger.debug(response)
    instances = [ x['Instances'][0] for x in response['Reservations'] ]
    for i in instances:
      if 'Platform' in i:
        Platform = i['Platform']
      elif 'InstanceId' in i:
        Platform = 'Linux'
    logger.debug('Platform : {}'.format(Platform.capitalize()))
    return Platform.capitalize()
  except Exception as e:
    logger.error("## Error on __getPlatformFromASG Function: " + str(e))
    logger.error(traceback.format_exc())
    raise