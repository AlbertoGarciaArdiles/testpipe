import logging
import boto3
import json
import os
import time
import datetime
import traceback
from . import Common_library as comlib
from jinja2 import Environment, DictLoader

LOG_LEVEL = os.environ['LOG_LEVEL']
SSM_DOCUMENT_GET_DISKS = os.environ['SSM_DOCUMENT_GET_DISKS']

logger = logging.getLogger()
logger.setLevel(LOG_LEVEL)

#local S3 client
s3 = boto3.client('s3')

###############################################################################################################################
#################################################### PRIVATE METHODS ##########################################################

#This is used only for internal Calculations to get the Metric Filters
#This should be a private method.
def ____getMetricsFromWindowsTemplate( policyTemplate, instanceId, alarm_name_prefix  ):
  dummyTemplate = __getPolicyFromTemplateWindows ( policyTemplate, [{'device':''}], instanceId, "", "", [], "", None, alarm_name_prefix, False )
  
  for metricFilter in dummyTemplate['MetricFilters']:
    metricFilter['MetricName'] =  metricFilter['MetricTransformations'][0]['metricName']
    metricFilter['MetricNamespace'] =  metricFilter['MetricTransformations'][0]['metricNamespace']

  return dummyTemplate['MetricFilters'] # if 'MetricFilters' in dummyTemplate else []

#This is used only for internal Calculations to get the Metric Filters
#This should be a private method.
def ____getMetricsFromLinuxTemplate( policyTemplate, instanceId, alarm_name_prefix, imageId, instanceType ):
  dummyTemplate = __getPolicyFromTemplateLinux (
    policyTemplate = policyTemplate, logicalDiskList = [{'device':''}], instanceId = instanceId, imageId = "", instanceType = "", metricFilters = [], computerName = "", autoscalingGroupName = None, alarm_name_prefix = alarm_name_prefix, activate_alarms = False )

  for metricFilter in dummyTemplate['MetricFilters']:
    metricFilter['MetricName'] =  metricFilter['MetricTransformations'][0]['metricName']
    metricFilter['MetricNamespace'] =  metricFilter['MetricTransformations'][0]['metricNamespace']
  return dummyTemplate['MetricFilters'] # if 'MetricFilters' in dummyTemplate else []

###############################################################################################################################
##############################################################################################################################



def getPolicyFromTemplateLinux ( policyTemplate, logicalDiskList, instanceId, computerName, autoscalingGroupName, alarm_name_prefix, imageId, instanceType, activate_alarms=False ):
  metricFilters = ____getMetricsFromLinuxTemplate ( policyTemplate, instanceId, alarm_name_prefix, imageId, instanceType )
  return __getPolicyFromTemplateLinux ( policyTemplate, logicalDiskList, instanceId, metricFilters, computerName, autoscalingGroupName, alarm_name_prefix, imageId, instanceType, activate_alarms  )


def getPolicyFromTemplateWindows ( policyTemplate, logicalDiskList, instanceId, imageId, instanceType, computerName, autoscalingGroupName, alarm_name_prefix, activate_alarms=False ):
  metricFilters = ____getMetricsFromWindowsTemplate ( policyTemplate, instanceId, alarm_name_prefix )
  return __getPolicyFromTemplateWindows ( policyTemplate, logicalDiskList, instanceId, imageId, instanceType, metricFilters, computerName, autoscalingGroupName, alarm_name_prefix, activate_alarms  )
  

def __getPolicyFromTemplateLinux ( policyTemplate, logicalDiskList, instanceId, metricFilters, computerName, autoscalingGroupName, alarm_name_prefix, imageId, instanceType, activate_alarms ):
  try:
    j2_env = Environment(loader=DictLoader({'policy': policyTemplate}), trim_blocks=False)
    isPartOfAutoScaling = False if (autoscalingGroupName == None) else True
    ITSMActive = 'SERVICENOW_ACTIVE' if activate_alarms else 'SERVICENOW_DEACTIVATED'
    
    output=j2_env.get_template('policy').render(
            InstanceId = instanceId,
            disks = logicalDiskList,
            MetricFilters = metricFilters,
            ComputerName = computerName,
            IsPartOfAutoScaling = isPartOfAutoScaling,
            ImageId = imageId,
            InstanceType = instanceType,
            AutoScalingGroupName = autoscalingGroupName,
            AlarmPrefix = alarm_name_prefix,
            ITSMActive = ITSMActive
        )
    return json.loads(output)
  
  except Exception as e:
      logger.error("## Error on __getPolicyFromTemplateLinux Function: " + str(e))
      logger.error(traceback.format_exc())
      raise

def __getPolicyFromTemplateWindows ( policyTemplate, logicalDiskList, instanceId, imageId, instanceType, metricFilters, computerName, autoscalingGroupName, alarm_name_prefix, activate_alarms):
  try:
    j2_env = Environment(loader=DictLoader({'policy': policyTemplate}), trim_blocks=False)
    isPartOfAutoScaling = False if (autoscalingGroupName == None) else True
    ITSMActive = 'SERVICENOW_ACTIVE' if activate_alarms else 'SERVICENOW_DEACTIVATED'
    
    output=j2_env.get_template('policy').render(
            InstanceId = instanceId,
            ImageId = imageId,
            InstanceType = instanceType,
            disks = logicalDiskList,
            MetricFilters = metricFilters,
            ComputerName = computerName,
            IsPartOfAutoScaling = isPartOfAutoScaling,
            AutoScalingGroupName = autoscalingGroupName,
            AlarmPrefix = alarm_name_prefix,
            ITSMActive = ITSMActive
        )
    # print (output)
    return json.loads(output)
  
  except Exception as e:
      logger.error("## Error on getPolicyFromTemplateWindows Function: " + str(e))
      logger.error(traceback.format_exc())
      raise


def getInstanceInformation (ssmclient, instanceId: str):
    logger.debug('## Start Executing: getInstanceInformation')
    logger.debug(instanceId)
    try:
      print ('========')
      print (instanceId)
      my_region = ssmclient.meta.region_name
      print (my_region)
      filters = [{'Key':'InstanceIds','Values':[instanceId]}]
      response = ssmclient.describe_instance_information(Filters=filters)
      print (response)

      if len(response['InstanceInformationList']) > 0:
        return response['InstanceInformationList'][0]
      else:
        raise ValueError('response from describe_instance_information returned no result')
    
    except Exception as e:
      logger.error("## Error on getInstanceInformation Function: " + str(e))
      logger.error(traceback.format_exc())
      raise


def getLogicalDiskList (ssmClient, instanceId, OSType):
  logger.debug('## Start Executing: getLogicalDiskList')
  logger.debug(instanceId)
  logger.debug(OSType)
  
  pluginName='LinuxDiskInventory' if OSType == 'Linux' else 'WindowsDiskInventory'
  
  try:
    command_response = ssmClient.send_command(
            InstanceIds=list(instanceId.split(",")),
            DocumentName=SSM_DOCUMENT_GET_DISKS,
            TimeoutSeconds=60,
            Parameters={}
        )
    
    logger.debug("## send_command response: ")
    logger.debug(command_response)
    
    retries = 1
    while retries <= 60:
      time.sleep(1)
      response = ssmClient.list_commands(CommandId=command_response['Command']['CommandId'])
      logger.debug (response['Commands'][0]['Status'])
      if not response['Commands'][0]['Status'] in ('Pending','InProgress'):
        break
      
      retries +=1

    command_invocation_response = ssmClient.get_command_invocation(
      CommandId=command_response['Command']['CommandId'],
      InstanceId=instanceId,
      PluginName=pluginName
    )
    
    logger.debug("## get_command_invocation response: ")
    logger.debug(command_invocation_response)
  
    respdict = json.loads(command_invocation_response['StandardOutputContent'])
    
    if isinstance(respdict['Content'], (list)):
      disksArray = []
      for o in respdict['Content']:
        disk={}
        disk['path'] = o['VolumeName']
        disk['fstype'] = o['FSType']
        disk['device'] = o['DeviceId']
        disksArray.append(disk)
    elif isinstance(respdict['Content'], (dict)):
      disksArray = [ { "path": respdict['Content']['VolumeName'], "fstype": respdict['Content']['FSType'], "device": respdict['Content']['DeviceId']}]
    
    return disksArray
  
  except Exception as e:
      logger.error("## Error on getLogicalDiskList Function: " + str(e))
      logger.error(traceback.format_exc())
      raise


def getEC2PolicyTemplate ( tagValue:str, osType:str ):
    return comlib.__getPolicyTemplate( tagValue = tagValue, resource_type='AWS::EC2::Instance', config_type = osType  )


def getComputerName ( ssmClient, instanceId: str):
  try:
    resp = getInstanceInformation ( ssmClient, instanceId = instanceId )
    resp = str(resp['ComputerName'])
    return resp.split('.')[0] if resp.lower().endswith(".workgroup") else resp
  
  except Exception as e:
      logger.error("## Error on getComputerName Function: " + str(e))
      logger.error(traceback.format_exc())
      raise