import logging
import boto3
import json
import os


import traceback
from . import Common_library as comlib

LOG_LEVEL = os.environ['LOG_LEVEL']

logger = logging.getLogger()
logger.setLevel(LOG_LEVEL)


# def get_alarms_signature ( resource_type:str ):
  
#   if resource_type == 'AWS::EC2::Instance':
#     return "ITAU_EC2_"
#   elif resource_type == 'AWS::ElasticLoadBalancingV2::LoadBalancer':
#     return "ITAU_ALB_"
#   elif resource_type == 'AWS::Logs::MetricFilter':
#     return "ITAU_ApplicationErrors_"
#   # elif resource_type == 'AWS::Logs::LogGroup':
#   #   return "ITAU_ApplicationErrors_"
#   else:
#     raise ValueError('The resource_type {} doesnt have an alarm signature'.format(resource_type))

def update_alarms_according_to_policy ( resource_type:str, resourceId_refined:str, policyAlarms:list, cw, taggingapi, activate_alarms:bool, resourceId_Raw:str ):
  
  CW_Alarms_Activated_For_ServiceNow = 'Yes' if activate_alarms else 'No'
  
  AlarmTagsListQuery = [ { 'Key': 'created_by', 'Values': [ 'Observability-Automation' ] },{ 'Key': 'created_for', 'Values': [ resourceId_refined ] } ]
  AlarmTagsListPutAlarms = [ { 'Key': 'created_by', 'Value': 'Observability-Automation' },{ 'Key': 'created_for', 'Value':  resourceId_Raw }, { 'Key': 'CW_Alarms_Activated_For_ServiceNow', 'Value':  CW_Alarms_Activated_For_ServiceNow }]
  
  #alarms_signature = get_alarms_signature ( resource_type )
  #Find if any existing alarm should be deleted. Mark 
  listAlarmsAutoCreated = listAlarmsCreatedWithAutomationv2( taggingapi = taggingapi, cwclient = cw, resourceId = resourceId_refined, TagsList = AlarmTagsListQuery )
  logger.debug('## listAlarmsAutoCreated')
  logger.debug(listAlarmsAutoCreated)
  
  logger.debug('## policyAlarms')
  logger.debug(policyAlarms)
  
  for existingalarm in listAlarmsAutoCreated:
    for alarm in policyAlarms['MetricAlarmsTemplates']:

      alarmsUniqueKey = calculateUniqueKey(alarm)
      existingalarmsUniqueKey = calculateUniqueKey(existingalarm)
      
      if( alarmsUniqueKey == existingalarmsUniqueKey ):
        existingalarm['mark'] = True

  logger.debug('## listAlarmsAutoCreated 2')
  logger.debug(listAlarmsAutoCreated)
  
  #Then delete all alarms which doesn't have the mark
  for existingalarm in listAlarmsAutoCreated:
    if not("mark" in existingalarm):
      logger.debug ('# To Delete : {} | {}'.format (existingalarm['AlarmName'], existingalarm['Namespace']))
      logger.debug (existingalarm['Dimensions'])
      deleteAlarms (
        cwclient = cw,
        alarmNames = [ al['AlarmName'] for al in comlib.listAlarmsForMetrics(cwclient=cw, metricName=existingalarm['MetricName'], namespace=existingalarm['Namespace'], dimensions=existingalarm['Dimensions']) ]
        )
  
  #Put (Create/Update) alarms according to policy
  for alarm in policyAlarms['MetricAlarmsTemplates']:
    #Create Alarm (No action since actions will handled by events with eventbridge)
    putAlarm(alarm=alarm, AlarmActions=[], OKActions=[], cwclient=cw, TagsList = AlarmTagsListPutAlarms)


def listAlarmsCreatedWithAutomationv2 ( taggingapi, cwclient, resourceId:str, TagsList:list ) -> list:
  logger.debug('## Start Executing: listAlarmsCreatedWithAutomationv2')
  logger.debug('resourceId : {}'.format(resourceId))
  logger.debug(TagsList)
  
  try:
    resp = taggingapi.get_resources( TagFilters = TagsList )
    logger.debug('## get_resources')
    logger.debug(resp)
    
    AlarmNames = [ x['ResourceARN'].split(':')[-1] for x in resp['ResourceTagMappingList'] if x['ResourceARN'].split(':')[-2] == 'alarm' ]
    
    logger.debug('## AlarmNames')
    logger.debug(AlarmNames)
    
    if len (AlarmNames) > 0:
      response = cwclient.describe_alarms( AlarmNames = AlarmNames )
      return response['MetricAlarms']
    else: return []
  
  except Exception as e:
      logger.error("## Error on listAlarmsCreatedWithAutomationv2 Function: " + str(e))
      raise e

# def listAlarmsCreatedWithAutomation ( cwclient, alarms_signature:str, resourceId:str ) -> list:
#   logger.debug('## Start Executing: listAlarmsAutoCreated')
  
#   try:
#     response = cwclient.describe_alarms(
#       AlarmNamePrefix = alarms_signature + resourceId
#       )
#     return response['MetricAlarms']
  
#   except Exception as e:
#       logger.error("## Error on listAlarmsAutoCreated Function: " + str(e))
#       raise e


def calculateUniqueKey ( alarms:list ):
  sortedDimensions = sorted(alarms['Dimensions'],key=lambda k: k['Name'])
  uniqueKey = str(alarms['MetricName']) + '_'
  uniqueKey += str(alarms['Namespace']) + '_'
  for alarm in sortedDimensions:
    uniqueKey += str(alarm['Value']) + '_'
  
  return uniqueKey[:-1] # <- return everything except the last character


def deleteAlarms ( cwclient, alarmNames:list ):
  logger.debug('## Start Executing: deleteAlarms')
  
  try:
    response = cwclient.delete_alarms(AlarmNames=alarmNames)
    return response
  
  except Exception as e:
      logger.error("## Error on deleteAlarms Function: " + str(e))
      logger.error(traceback.format_exc())


def alarmExistsForMetric ( cwclient, metricName:str, namespace:str, dimensions:list ) -> bool:
  logger.debug('## Start Executing: alarmExistsForMetric')
  
  try:
    response = cwclient.describe_alarms_for_metric(
      MetricName=metricName,
      Namespace=namespace,
      Dimensions=dimensions)
    return (len(response['MetricAlarms']) > 0)
  
  except Exception as e:
      logger.error("## Error on alarmExistsForMetric Function: " + str(e))
      logger.error(traceback.format_exc())


def putAlarm ( cwclient, alarm:dict, OKActions:list, AlarmActions:list, TagsList:list ):
  #TagsFormat: Tags=[ { 'Key': 'string', 'Value': 'string' } ]
  logger.debug('## Start Executing: putAlarm')
  logger.debug(alarm)
  
  treatMissingData = 'missing' if not ('TreatMissingData' in alarm ) else alarm['TreatMissingData']
  
  try:
    response = cwclient.put_metric_alarm(
      AlarmName = alarm['AlarmName'],
      AlarmDescription = alarm['AlarmDescription'],
      ActionsEnabled = True,
      OKActions = OKActions,
      AlarmActions = AlarmActions,
      MetricName = alarm['MetricName'],
      Namespace = alarm['Namespace'],
      Statistic = alarm['Statistic'],
      #ExtendedStatistic = alarm['ExtendedStatistic'],
      Dimensions = alarm['Dimensions'],
      Period = int(alarm['Period']),
      #Unit = alarm['Unit'],
      EvaluationPeriods = int(alarm['EvaluationPeriods']),
      DatapointsToAlarm = int(alarm['DatapointsToAlarm']),
      Threshold = int(alarm['Threshold']),
      ComparisonOperator = alarm['ComparisonOperator'],
      Tags = TagsList,
      TreatMissingData = treatMissingData)
    
    logger.debug(response)
  
  except Exception as e:
      logger.error("## Error on putAlarm Function: " + str(e))
      logger.error("## Error Namespace: " + str(alarm['Namespace']))
      logger.error("## Error MetricName: " + str(alarm['MetricName']))
      logger.error(alarm['Dimensions'])
      logger.error(traceback.format_exc())
      raise e

# def update_metric_filters_according_to_policy ( logs, metricFilters:list, instanceId:str, computerName:str ):
  
#   try:
#     metric_filter_signature = get_alarms_signature ("AWS::Logs::MetricFilter")
    
#     logGroupNames = [ metric['LogGroupName'] for metric in metricFilters  ]
    
#     #Delete all Metric Filters in the same LogGroup Name
#     for logGroupName in logGroupNames:
#       existingMetricFilters = logs.describe_metric_filters(
#         logGroupName = logGroupName,
#         filterNamePrefix = metric_filter_signature + instanceId)
      
#       for each_metric_filter in existingMetricFilters['metricFilters']:
#         resp = logs.delete_metric_filter(
#           logGroupName = logGroupName,
#           filterName = each_metric_filter.get('filterName'))
    
#     #Create all metric Filters
#     for each_MetricFilter in metricFilters:
#       resp = logs.put_metric_filter(
#         logGroupName = each_MetricFilter.get('LogGroupName'),
#         filterName = each_MetricFilter.get('FilterName'),
#         filterPattern = each_MetricFilter.get('FilterPattern'),
#         metricTransformations = each_MetricFilter.get('MetricTransformations')
#         )
        
#   except Exception as e:
#     logger.error("## Error on update_metric_filters_according_to_policy Function: " + str(e))
#     logger.error(traceback.format_exc())
#     raise e