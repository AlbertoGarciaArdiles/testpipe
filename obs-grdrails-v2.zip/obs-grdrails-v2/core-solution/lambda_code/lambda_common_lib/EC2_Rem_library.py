import logging
import boto3
import json
import os
import traceback
import base64
import gzip
from botocore.exceptions import ClientError
from . import Common_library as comlib

LOG_LEVEL = os.environ['LOG_LEVEL']
CONFIG_BUCKET = os.environ['CONFIG_BUCKET']

logger = logging.getLogger()
logger.setLevel(LOG_LEVEL)

#local S3 client
s3 = boto3.client('s3')

def putParameters ( ssmclient, parametersPrefix:str, parameterMetricValue:str, osType:str ):
  logger.debug('## Start Executing: putParameter')
  logger.debug('parametersPrefix : {}'.format(parametersPrefix))
  logger.debug('osType : {}'.format(osType))
  logger.debug(parameterMetricValue)
  
  CWAgentConfigFileName = getCWAgentPolicyTemplate_fileName ( tagValue = parametersPrefix, osType = osType )
  CWAgentConfigFile_Path = comlib.__getPath ( tagValue = parametersPrefix )
  parameterDescription = """This parameter was automatically created by a remediation guardrail SSM Automation.
  The source of this parameter should be found in: s3://""" + CONFIG_BUCKET + "/" + CWAgentConfigFile_Path + CWAgentConfigFileName
  
  parameterName_initial = parametersPrefix + '/' + 'cw-config-ssm'
  parameterName_logs = parametersPrefix + '/' + 'cw-config-logs-ssm'
  parameterName_metrics = parametersPrefix + '/' + 'cw-config-metrics-ssm'
  
  logger.debug('parameterName_initial : {}'.format(parameterName_initial))
  logger.debug('parameterName_logs : {}'.format(parameterName_logs))
  logger.debug('parameterName_metrics : {}'.format(parameterName_metrics))
  
  parameterValue_initial = ssmclient.get_parameter( Name = parameterName_initial )['Parameter']['Value']
  parameterValue_initial = json.loads(gzip.decompress(base64.b64decode(parameterValue_initial)))
  parameterValue_logs = json.dumps( { 'logs': parameterValue_initial['logs'] })
  parameterValue_metrics = parameterMetricValue
  
  logger.debug('parameterName_initial : {}'.format(parameterName_initial))
  logger.debug('parameterName_logs : {}'.format(parameterName_logs))
  logger.debug('parameterName_metrics : {}'.format(parameterName_metrics))
  
  logger.debug( parameterValue_initial )
  logger.debug( parameterName_logs )
  logger.debug( parameterName_metrics )

  # Look for
  resp = ssmclient.describe_parameters( Filters = [ { 'Key' : 'Name', 'Values':[ parameterName_logs ] } ] )
  logger.debug ("describe_parameters")
  logger.debug (resp)

  resp = ssmclient.put_parameter(
    Name = parameterName_logs,
    Description = parameterDescription,
    Value = parameterValue_logs,
    Type = 'String',
    Overwrite = True )

  resp = ssmclient.put_parameter(
    Name = parameterName_metrics,
    Description = parameterDescription,
    Value = parameterValue_metrics,
    Type = 'String',
    Overwrite = True )
  
  parameter_logs_ExistsAndareEqual = False
  parameter_metrics_ExistsAndareEqual = False
  
  try:
    
    param_logs = ssmclient.get_parameter( Name = parameterName_logs )
    
    if param_logs['Parameter']['Value'] == parameterValue_logs:
      parameter_logs_ExistsAndareEqual = True
  
  except ClientError as e:
    if e.response['Error']['Code'] == 'ParameterNotFound':
      logger.debug('ParameterNotFound Error has been handled')
      logger.debug('Parameter does not exist : {}'.format (parameterName_logs))
      parameter_logs_ExistsAndareEqual = False
    else: raise e

  
  try:
    
    param_metrics = ssmclient.get_parameter( Name = parameterName_metrics )
    
    if param_metrics['Parameter']['Value'] == parameterValue_metrics:
      parameter_metrics_ExistsAndareEqual = True
  
  except ClientError as e:
    if e.response['Error']['Code'] == 'ParameterNotFound':
      logger.debug('ParameterNotFound Error has been handled')
      logger.debug('Parameter does not exist : {}'.format (parameterName_metrics))
      parameter_metrics_ExistsAndareEqual = False
    else: raise e
  
  parametersExistsAndareEqual = parameter_logs_ExistsAndareEqual and parameter_metrics_ExistsAndareEqual

      
  return {
      'parameterName_logs': parameterName_logs,
      'parameterName_metrics': parameterName_metrics,
      'parametersExistsAndareEqual': parametersExistsAndareEqual,
      'parameter_logs_ExistsAndareEqual': parameter_logs_ExistsAndareEqual,
      'parameter_metrics_ExistsAndareEqual': parameter_metrics_ExistsAndareEqual,
    }


# def createParameter ( ssmclient, parameterName:str, parameterValue:str, tagValue:str, osType:str):
#   logger.debug('## Start Executing: createParameter')
  
#   CWAgentConfigFileName = getCWAgentPolicyTemplate_fileName ( tagValue = tagValue, osType = osType )
#   CWAgentConfigFile_Path = comlib.__getPath ( tagValue = tagValue )
#   parameterDescription = """This parameter was automatically created by a remediation guardrail SSM Automation.
#   The source of this parameter should be found in: s3://""" + CONFIG_BUCKET + "/" + CWAgentConfigFile_Path + CWAgentConfigFileName
  
#   try:
#     response = ssmclient.put_parameter(
#       Name = parameterName,
#       Description = parameterDescription,
#       Value = parameterValue,
#       Type = 'String',
#       Overwrite = True )
#     return response
  
#   except Exception as e:
#       logger.error("## Error on createParameter Function: " + str(e))
#       logger.error(traceback.format_exc())


def getTagsFromInstance ( ec2client, instanceId:str):
    logger.debug('## Start Executing: getTagsFromInstance')
    logger.debug(instanceId)
    try:
      response = ec2client.describe_tags(Filters=[ { "Name": "resource-id", "Values": [instanceId] }],MaxResults=100)
      return response['Tags']
          
    except Exception as e:
      logger.error("## Error on getTagsFromInstance Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e

def getTagValueFromInstance ( ec2client, instanceId:str, tagKey:str):
    logger.debug('## Start Executing: getTagValueFromInstance')
    logger.debug(instanceId)
    logger.debug(tagKey)
    try:
      response = ec2client.describe_tags(Filters=[ { "Name": "resource-id", "Values": [instanceId] }],MaxResults=100)
      for tag in response['Tags']:
        if str(tag['Key']) == tagKey:
          return tag['Value']

      return 'default'
          
    except Exception as e:
      logger.error("## Error on getTagValueFromInstance Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e

def getEC2_attributes ( ec2client, instanceId:str ):
    logger.debug('## Start Executing: getEC2_attributes')
    logger.debug(instanceId)
    try:
      response = ec2client.describe_instances(InstanceIds=[ instanceId ])
      
      return response['Reservations'][0]['Instances'][0]
          
    except Exception as e:
      logger.error("## Error on getEC2_attributes Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e

def getAttributeEc2 ( ec2client, instanceId:str, attributeName:str):
    logger.debug('## Start Executing: getAttributeEc2')
    logger.debug(instanceId)
    try:
      response = ec2client.describe_instances(InstanceIds=[ instanceId ])
      
      return response['Reservations'][0]['Instances'][0][attributeName]
          
    except Exception as e:
      logger.error("## Error on getAttributeEc2 Function: " + str(e))
      logger.error(traceback.format_exc())
      raise e


def getCWAgentPolicyTemplate ( tagValue:str, osType:str ):
  policyConfig = comlib.__getPolicyTemplateConfigsV2( tagValue = tagValue, resource_type='AWS::EC2::Instance', config_type = osType  )
  try:
    config_file = s3.get_object(
      Bucket = CONFIG_BUCKET,
      Key = comlib.__getPath ( tagValue ) + str( policyConfig.get( 'cwagent_config_filename' ) ) )
    
    config_file_body = config_file['Body'].read().decode('utf-8')
      
    return config_file_body
  
  except Exception as e:
    logger.error("## Error on getCWAgentPolicyTemplate Function: " + str(e))
    logger.error(traceback.format_exc())
    raise  


def getCWAgentPolicyTemplate_fileName ( tagValue:str, osType:str ):
  try:
    policyConfig = comlib.__getPolicyTemplateConfigsV2( tagValue = tagValue, resource_type='AWS::EC2::Instance', config_type = osType  )
    return policyConfig.get( 'cwagent_config_filename' )

  except Exception as e:
    logger.error("## Error on getCWAgentPolicyTemplate_fileName Function: " + str(e))
    logger.error(traceback.format_exc())
    raise

