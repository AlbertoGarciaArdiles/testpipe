import boto3
import json
import os
import logging

AUTOMATION_LAMBDA_ROLE_NAME = os.environ['AUTOMATION_LAMBDA_ROLE_NAME']
  
def lambda_handler(event, context):
  print(event)
  
  #get the credentials from the assumed Role
  executionRoleArn = 'arn:aws:iam::'+str(event['accountID'])+':role/' + AUTOMATION_LAMBDA_ROLE_NAME
  sts_client = boto3.client('sts')
  assumed_role_object=sts_client.assume_role(
      RoleArn=executionRoleArn,
      RoleSessionName="AssumeRoleSession1"
  )
  credentials=assumed_role_object['Credentials']

  cw = boto3.client(
    'cloudwatch',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
  )

  config = boto3.client(
    'config',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
  )
  
  taggingapi = boto3.client(
    'resourcegroupstaggingapi',
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    # region_name='sa-east-1'
  )
  AlarmTagsListQuery = [ { 'Key': 'created_by', 'Values': [ 'Observability-Automation' ] } ]

  paginator = taggingapi.get_paginator('get_resources')
  page_iterator = paginator.paginate( TagFilters = AlarmTagsListQuery )

  alarm_names_list = []
  alarms_dictionary = []
  alarms_to_delete_dictionary = []
  for page in page_iterator:
    #alarm_names_list.extend( [ __getNameFromARN( x['ResourceARN'] )for x in page['ResourceTagMappingList'] ] )
    alarm_names_list = [ __getNameFromARN( x['ResourceARN'] )for x in page['ResourceTagMappingList'] ]
    alarms_dictionary.extend(
      {
        'alarmARN': x['ResourceARN'],
        'alarmName':__getNameFromARN(x['ResourceARN']),
        'resourceARN': list(filter(lambda tag: tag['Key'] == 'created_for', x['Tags']))[0]['Value']
      }
      for x in page['ResourceTagMappingList']
    )

    paginator = cw.get_paginator('describe_alarms')
    page_iterator = paginator.paginate(
      AlarmNames = alarm_names_list,
      StateValue = 'INSUFFICIENT_DATA'
    )
  
    alarms_list_insufficient_data = []
    for page in page_iterator:
      alarms_list_insufficient_data.extend( page['MetricAlarms'] )
  
    alarms_insufficient_data_dictionary = [ x for x in alarms_dictionary if x['alarmName'] in [ x['AlarmName'] for x in alarms_list_insufficient_data ] ]
    
    alarm_names_to_delete = []
    for alarm in alarms_insufficient_data_dictionary:
      resp = __checkResourceExists ( alarm['resourceARN'], config )
      if resp is None:
        alarms_to_delete_dictionary.append ( alarm )
        alarm_names_to_delete.append( alarm['alarmName'] )
        print ( 'Alarm Name: {} - Resource ARN: {}'.format(alarm['alarmName'], alarm['resourceARN']) )
    
    resp = cw.delete_alarms( AlarmNames = alarm_names_to_delete )
  
  response = {
    'statusCode': 200,
    'deleted_alarms': alarms_to_delete_dictionary
  }
  
  return response

def __checkResourceExists ( resourceId_Raw:str, config ):
  sql_expression = "SELECT resourceType WHERE resourceid = '{}'".format(resourceId_Raw)
  resp = config.select_resource_config( Expression = sql_expression )
  resp = json.loads(resp['Results'][0])['resourceType'] if (len( resp['Results'] ) >  0) else None
  return resp

def __getNameFromARN ( arn:str )->str:
  return ':'.join(arn.split(':')[6::])