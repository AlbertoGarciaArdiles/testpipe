import json
import boto3

### INPUT
#{
#   DocumentName='',
#   Parameters={ 'string': ['string'], },
#   TargetParameterName='resourceId',
#   Targets=[ { 'Key': 'ParameterValues', 'Values': [ 'i-XXXXXXXXXXXXXXXXXXX', ] },],
#   Accounts = ['975399109150'],
#   Regions = ['sa-east-1'],
#   ExecutionRoleName = 'cross-grdrails-obs-remediations-role-iam'
#}

def lambda_handler(event, context):
    # TODO implement
    print (event)
    
    ssm = boto3.client('ssm')
    
    documentName = event['DocumentName']
    parameters = event['Parameters']
    targetParameterName = event['TargetParameterName']
    targets = event['Targets']
    targetLocations = [ { 'Accounts': event['Accounts'], 'Regions' : event['Regions'], 'TargetLocationMaxConcurrency':'1', 'TargetLocationMaxErrors':'1', 'ExecutionRoleName': event['ExecutionRoleName'] } ]
    
    response = ssm.start_automation_execution(
        DocumentName = documentName,
        Parameters = parameters,
        TargetParameterName = targetParameterName,
        Targets = targets,
        TargetLocations = targetLocations)
    
    return response