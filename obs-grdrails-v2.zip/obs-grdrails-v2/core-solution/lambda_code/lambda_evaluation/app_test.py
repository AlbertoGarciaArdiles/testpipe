# Copyright 2017-2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You may
# not use this file except in compliance with the License. A copy of the License is located at
#
#        http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for
# the specific language governing permissions and limitations under the License.

import sys
import unittest
try:
    from unittest.mock import MagicMock
except ImportError:
    from mock import MagicMock
import botocore
import json
##############
# Parameters #
##############

# Define the default resource to report to Config Rules
DEFAULT_RESOURCE_TYPE = 'AWS::::Account'

#############
# Main Code #
#############

CONFIG_CLIENT_MOCK = MagicMock()
STS_CLIENT_MOCK = MagicMock()

# class Boto3Mock():
#     @staticmethod
#     def client(client_name, *args, **kwargs):
        # if client_name == 'config':
        #     return CONFIG_CLIENT_MOCK
        # if client_name == 'sts':
        #     return STS_CLIENT_MOCK
        # raise Exception("Attempting to create an unknown client")

# sys.modules['boto3'] = Boto3Mock()

RULE = __import__('app')

class MyContext:
    aws_request_id = ''

    def __init__(self, aws_request_id):
        self.aws_request_id = aws_request_id

class ComplianceTest(unittest.TestCase):

    #RULE PARAMETERS
    rule_parameters = '{"TAG_EVALUATED":"itau:ops:auto:ec2:obs:alarms"}'

    #invoking_event_ec2_instance_windows = '{"configurationItemDiff":null,"configurationItem":{"relatedEvents":[],"relationships":[{"resourceId":"eni-0b4fa59f6d17ad9c0","resourceName":null,"resourceType":"AWS::EC2::NetworkInterface","name":"Contains NetworkInterface"},{"resourceId":"sg-0d299397dc641bed0","resourceName":null,"resourceType":"AWS::EC2::SecurityGroup","name":"Is associated with SecurityGroup"},{"resourceId":"subnet-08253a9e512bebc44","resourceName":null,"resourceType":"AWS::EC2::Subnet","name":"Is contained in Subnet"},{"resourceId":"vol-000b94726840ff2f1","resourceName":null,"resourceType":"AWS::EC2::Volume","name":"Is attached to Volume"},{"resourceId":"vpc-01551a079869bb732","resourceName":null,"resourceType":"AWS::EC2::VPC","name":"Is contained in Vpc"}],"configuration":{"amiLaunchIndex":0,"imageId":"ami-02642c139a9dfb378","instanceId":"i-0d9fd5da74218e24c","instanceType":"t2.micro","kernelId":null,"keyName":null,"launchTime":"2021-02-24T16:33:18.000Z","monitoring":{"state":"enabled"},"placement":{"availabilityZone":"us-east-1c","affinity":null,"groupName":"","partitionNumber":null,"hostId":null,"tenancy":"default","spreadDomain":null,"hostResourceGroupArn":null},"platform":null,"privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247","productCodes":[],"publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIpAddress":"54.88.144.239","ramdiskId":null,"state":{"code":16,"name":"running"},"stateTransitionReason":"","subnetId":"subnet-08253a9e512bebc44","vpcId":"vpc-01551a079869bb732","architecture":"x86_64","blockDeviceMappings":[{"deviceName":"/dev/xvda","ebs":{"attachTime":"2021-02-08T22:27:21.000Z","deleteOnTermination":true,"status":"attached","volumeId":"vol-000b94726840ff2f1"}}],"clientToken":"aws-c-Insta-1XEE5ESXRMBCR","ebsOptimized":false,"enaSupport":true,"hypervisor":"xen","iamInstanceProfile":null,"instanceLifecycle":null,"elasticGpuAssociations":[],"elasticInferenceAcceleratorAssociations":[],"networkInterfaces":[{"association":{"carrierIp":null,"ipOwnerId":"amazon","publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIp":"54.88.144.239"},"attachment":{"attachTime":"2021-02-08T22:27:20.000Z","attachmentId":"eni-attach-0faf27ba9b0c7126e","deleteOnTermination":true,"deviceIndex":0,"status":"attached","networkCardIndex":0},"description":"","groups":[{"groupName":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc-InstanceSecurityGroup-1ORF32JZ3QM6U","groupId":"sg-0d299397dc641bed0"}],"ipv6Addresses":[],"macAddress":"0e:8a:ba:c2:77:dd","networkInterfaceId":"eni-0b4fa59f6d17ad9c0","ownerId":"367923919544","privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247","privateIpAddresses":[{"association":{"carrierIp":null,"ipOwnerId":"amazon","publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIp":"54.88.144.239"},"primary":true,"privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247"}],"sourceDestCheck":true,"status":"in-use","subnetId":"subnet-08253a9e512bebc44","vpcId":"vpc-01551a079869bb732","interfaceType":"interface"}],"outpostArn":null,"rootDeviceName":"/dev/xvda","rootDeviceType":"ebs","securityGroups":[{"groupName":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc-InstanceSecurityGroup-1ORF32JZ3QM6U","groupId":"sg-0d299397dc641bed0"}],"sourceDestCheck":true,"spotInstanceRequestId":null,"sriovNetSupport":null,"stateReason":null,"tags":[{"key":"aws:cloudformation:logical-id","value":"Instance"},{"key":"aws:cloudformation:stack-id","value":"arn:aws:cloudformation:us-east-1:367923919544:stack/aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc/c6572ef0-6a5c-11eb-b08e-0abfd97085ad"},{"key":"aws:cloud9:owner","value":"AROAVLKPZPK4LBZ5TVDIW:agarciaa@oncloudlz3.com"},{"key":"Name","value":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"},{"key":"aws:cloud9:environment","value":"177b83a67652455fa658fea1824da7dc"},{"key":"aws:cloudformation:stack-name","value":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"}],"virtualizationType":"hvm","cpuOptions":{"coreCount":1,"threadsPerCore":2},"capacityReservationId":null,"capacityReservationSpecification":{"capacityReservationPreference":"open","capacityReservationTarget":null},"hibernationOptions":{"configured":false},"licenses":[],"metadataOptions":{"state":"applied","httpTokens":"optional","httpPutResponseHopLimit":1,"httpEndpoint":"enabled"},"enclaveOptions":{"enabled":false}},"supplementaryConfiguration":{},"tags":{"aws:cloudformation:stack-name":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc","aws:cloudformation:stack-id":"arn:aws:cloudformation:us-east-1:367923919544:stack/aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc/c6572ef0-6a5c-11eb-b08e-0abfd97085ad","aws:cloud9:environment":"177b83a67652455fa658fea1824da7dc","aws:cloudformation:logical-id":"Instance","aws:cloud9:owner":"AROAVLKPZPK4LBZ5TVDIW:agarciaa@oncloudlz3.com","Name":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"},"configurationItemVersion":"1.3","configurationItemCaptureTime":"2021-02-24T16:35:24.750Z","configurationStateId":1614184524750,"awsAccountId":"367923919544","configurationItemStatus":"OK","resourceType":"AWS::EC2::Instance","resourceId":"i-0d9fd5da74218e24c","resourceName":null,"ARN":"arn:aws:ec2:us-east-1:367923919544:instance/i-09c9293a75698b482","awsRegion":"sa-east-1","availabilityZone":"us-east-1c","configurationStateMd5Hash":"","resourceCreationTime":"2021-02-24T16:33:18.000Z"},"notificationCreationTime":"2021-02-24T17:55:05.026Z","messageType":"ConfigurationItemChangeNotification","recordVersion":"1.3"}'
    invoking_event_ec2_instance_linux = '{"configurationItemDiff":null,"configurationItem":{"relatedEvents":[],"relationships":[{"resourceId":"eni-0b4fa59f6d17ad9c0","resourceName":null,"resourceType":"AWS::EC2::NetworkInterface","name":"Contains NetworkInterface"},{"resourceId":"sg-0d299397dc641bed0","resourceName":null,"resourceType":"AWS::EC2::SecurityGroup","name":"Is associated with SecurityGroup"},{"resourceId":"subnet-08253a9e512bebc44","resourceName":null,"resourceType":"AWS::EC2::Subnet","name":"Is contained in Subnet"},{"resourceId":"vol-000b94726840ff2f1","resourceName":null,"resourceType":"AWS::EC2::Volume","name":"Is attached to Volume"},{"resourceId":"vpc-01551a079869bb732","resourceName":null,"resourceType":"AWS::EC2::VPC","name":"Is contained in Vpc"}],"configuration":{"amiLaunchIndex":0,"imageId":"ami-02642c139a9dfb378","instanceId":"i-00d0012d4b9ba0eda","instanceType":"t2.micro","kernelId":null,"keyName":null,"launchTime":"2021-02-24T16:33:18.000Z","monitoring":{"state":"enabled"},"placement":{"availabilityZone":"us-east-1c","affinity":null,"groupName":"","partitionNumber":null,"hostId":null,"tenancy":"default","spreadDomain":null,"hostResourceGroupArn":null},"platform":null,"privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247","productCodes":[],"publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIpAddress":"54.88.144.239","ramdiskId":null,"state":{"code":16,"name":"running"},"stateTransitionReason":"","subnetId":"subnet-08253a9e512bebc44","vpcId":"vpc-01551a079869bb732","architecture":"x86_64","blockDeviceMappings":[{"deviceName":"/dev/xvda","ebs":{"attachTime":"2021-02-08T22:27:21.000Z","deleteOnTermination":true,"status":"attached","volumeId":"vol-000b94726840ff2f1"}}],"clientToken":"aws-c-Insta-1XEE5ESXRMBCR","ebsOptimized":false,"enaSupport":true,"hypervisor":"xen","iamInstanceProfile":null,"instanceLifecycle":null,"elasticGpuAssociations":[],"elasticInferenceAcceleratorAssociations":[],"networkInterfaces":[{"association":{"carrierIp":null,"ipOwnerId":"amazon","publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIp":"54.88.144.239"},"attachment":{"attachTime":"2021-02-08T22:27:20.000Z","attachmentId":"eni-attach-0faf27ba9b0c7126e","deleteOnTermination":true,"deviceIndex":0,"status":"attached","networkCardIndex":0},"description":"","groups":[{"groupName":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc-InstanceSecurityGroup-1ORF32JZ3QM6U","groupId":"sg-0d299397dc641bed0"}],"ipv6Addresses":[],"macAddress":"0e:8a:ba:c2:77:dd","networkInterfaceId":"eni-0b4fa59f6d17ad9c0","ownerId":"367923919544","privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247","privateIpAddresses":[{"association":{"carrierIp":null,"ipOwnerId":"amazon","publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIp":"54.88.144.239"},"primary":true,"privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247"}],"sourceDestCheck":true,"status":"in-use","subnetId":"subnet-08253a9e512bebc44","vpcId":"vpc-01551a079869bb732","interfaceType":"interface"}],"outpostArn":null,"rootDeviceName":"/dev/xvda","rootDeviceType":"ebs","securityGroups":[{"groupName":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc-InstanceSecurityGroup-1ORF32JZ3QM6U","groupId":"sg-0d299397dc641bed0"}],"sourceDestCheck":true,"spotInstanceRequestId":null,"sriovNetSupport":null,"stateReason":null,"tags":[{"key":"aws:cloudformation:logical-id","value":"Instance"},{"key":"aws:cloudformation:stack-id","value":"arn:aws:cloudformation:us-east-1:367923919544:stack/aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc/c6572ef0-6a5c-11eb-b08e-0abfd97085ad"},{"key":"aws:cloud9:owner","value":"AROAVLKPZPK4LBZ5TVDIW:agarciaa@oncloudlz3.com"},{"key":"Name","value":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"},{"key":"aws:cloud9:environment","value":"177b83a67652455fa658fea1824da7dc"},{"key":"aws:cloudformation:stack-name","value":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"}],"virtualizationType":"hvm","cpuOptions":{"coreCount":1,"threadsPerCore":2},"capacityReservationId":null,"capacityReservationSpecification":{"capacityReservationPreference":"open","capacityReservationTarget":null},"hibernationOptions":{"configured":false},"licenses":[],"metadataOptions":{"state":"applied","httpTokens":"optional","httpPutResponseHopLimit":1,"httpEndpoint":"enabled"},"enclaveOptions":{"enabled":false}},"supplementaryConfiguration":{},"tags":{"aws:cloudformation:stack-name":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc","aws:cloudformation:stack-id":"arn:aws:cloudformation:us-east-1:367923919544:stack/aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc/c6572ef0-6a5c-11eb-b08e-0abfd97085ad","aws:cloud9:environment":"177b83a67652455fa658fea1824da7dc","aws:cloudformation:logical-id":"Instance","aws:cloud9:owner":"AROAVLKPZPK4LBZ5TVDIW:agarciaa@oncloudlz3.com","Name":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"},"configurationItemVersion":"1.3","configurationItemCaptureTime":"2021-02-24T16:35:24.750Z","configurationStateId":1614184524750,"awsAccountId":"367923919544","configurationItemStatus":"OK","resourceType":"AWS::EC2::Instance","resourceId":"i-00d0012d4b9ba0eda","resourceName":null,"ARN":"arn:aws:ec2:sa-east-1:367923919544:instance/i-00d0012d4b9ba0eda","awsRegion":"sa-east-1","availabilityZone":"us-east-1c","configurationStateMd5Hash":"","resourceCreationTime":"2021-02-24T16:33:18.000Z"},"notificationCreationTime":"2021-02-24T17:55:05.026Z","messageType":"ConfigurationItemChangeNotification","recordVersion":"1.3"}'
    #invoking_event_ec2_instance_windows_wsus = '{"configurationItemDiff":null,"configurationItem":{"relatedEvents":[],"relationships":[{"resourceId":"eni-0b4fa59f6d17ad9c0","resourceName":null,"resourceType":"AWS::EC2::NetworkInterface","name":"Contains NetworkInterface"},{"resourceId":"sg-0d299397dc641bed0","resourceName":null,"resourceType":"AWS::EC2::SecurityGroup","name":"Is associated with SecurityGroup"},{"resourceId":"subnet-08253a9e512bebc44","resourceName":null,"resourceType":"AWS::EC2::Subnet","name":"Is contained in Subnet"},{"resourceId":"vol-000b94726840ff2f1","resourceName":null,"resourceType":"AWS::EC2::Volume","name":"Is attached to Volume"},{"resourceId":"vpc-01551a079869bb732","resourceName":null,"resourceType":"AWS::EC2::VPC","name":"Is contained in Vpc"}],"configuration":{"amiLaunchIndex":0,"imageId":"ami-02642c139a9dfb378","instanceId":"i-0bc99cf9453aa0e8c","instanceType":"t3a.medium","kernelId":null,"keyName":null,"launchTime":"2021-02-24T16:33:18.000Z","monitoring":{"state":"enabled"},"placement":{"availabilityZone":"us-east-1c","affinity":null,"groupName":"","partitionNumber":null,"hostId":null,"tenancy":"default","spreadDomain":null,"hostResourceGroupArn":null},"platform":null,"privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247","productCodes":[],"publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIpAddress":"54.88.144.239","ramdiskId":null,"state":{"code":16,"name":"running"},"stateTransitionReason":"","subnetId":"subnet-08253a9e512bebc44","vpcId":"vpc-01551a079869bb732","architecture":"x86_64","blockDeviceMappings":[{"deviceName":"/dev/xvda","ebs":{"attachTime":"2021-02-08T22:27:21.000Z","deleteOnTermination":true,"status":"attached","volumeId":"vol-000b94726840ff2f1"}}],"clientToken":"aws-c-Insta-1XEE5ESXRMBCR","ebsOptimized":false,"enaSupport":true,"hypervisor":"xen","iamInstanceProfile":null,"instanceLifecycle":null,"elasticGpuAssociations":[],"elasticInferenceAcceleratorAssociations":[],"networkInterfaces":[{"association":{"carrierIp":null,"ipOwnerId":"amazon","publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIp":"54.88.144.239"},"attachment":{"attachTime":"2021-02-08T22:27:20.000Z","attachmentId":"eni-attach-0faf27ba9b0c7126e","deleteOnTermination":true,"deviceIndex":0,"status":"attached","networkCardIndex":0},"description":"","groups":[{"groupName":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc-InstanceSecurityGroup-1ORF32JZ3QM6U","groupId":"sg-0d299397dc641bed0"}],"ipv6Addresses":[],"macAddress":"0e:8a:ba:c2:77:dd","networkInterfaceId":"eni-0b4fa59f6d17ad9c0","ownerId":"367923919544","privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247","privateIpAddresses":[{"association":{"carrierIp":null,"ipOwnerId":"amazon","publicDnsName":"ec2-54-88-144-239.compute-1.amazonaws.com","publicIp":"54.88.144.239"},"primary":true,"privateDnsName":"ip-10-26-52-247.ec2.internal","privateIpAddress":"10.26.52.247"}],"sourceDestCheck":true,"status":"in-use","subnetId":"subnet-08253a9e512bebc44","vpcId":"vpc-01551a079869bb732","interfaceType":"interface"}],"outpostArn":null,"rootDeviceName":"/dev/xvda","rootDeviceType":"ebs","securityGroups":[{"groupName":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc-InstanceSecurityGroup-1ORF32JZ3QM6U","groupId":"sg-0d299397dc641bed0"}],"sourceDestCheck":true,"spotInstanceRequestId":null,"sriovNetSupport":null,"stateReason":null,"tags":[{"key":"aws:cloudformation:logical-id","value":"Instance"},{"key":"aws:cloudformation:stack-id","value":"arn:aws:cloudformation:us-east-1:367923919544:stack/aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc/c6572ef0-6a5c-11eb-b08e-0abfd97085ad"},{"key":"aws:cloud9:owner","value":"AROAVLKPZPK4LBZ5TVDIW:agarciaa@oncloudlz3.com"},{"key":"Name","value":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"},{"key":"aws:cloud9:environment","value":"177b83a67652455fa658fea1824da7dc"},{"key":"aws:cloudformation:stack-name","value":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"}],"virtualizationType":"hvm","cpuOptions":{"coreCount":1,"threadsPerCore":2},"capacityReservationId":null,"capacityReservationSpecification":{"capacityReservationPreference":"open","capacityReservationTarget":null},"hibernationOptions":{"configured":false},"licenses":[],"metadataOptions":{"state":"applied","httpTokens":"optional","httpPutResponseHopLimit":1,"httpEndpoint":"enabled"},"enclaveOptions":{"enabled":false}},"supplementaryConfiguration":{},"tags":{"aws:cloudformation:stack-name":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc","aws:cloudformation:stack-id":"arn:aws:cloudformation:us-east-1:367923919544:stack/aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc/c6572ef0-6a5c-11eb-b08e-0abfd97085ad","aws:cloud9:environment":"177b83a67652455fa658fea1824da7dc","aws:cloudformation:logical-id":"Instance","aws:cloud9:owner":"AROAVLKPZPK4LBZ5TVDIW:agarciaa@oncloudlz3.com","Name":"aws-cloud9-GuardRails2-177b83a67652455fa658fea1824da7dc"},"configurationItemVersion":"1.3","configurationItemCaptureTime":"2021-02-24T16:35:24.750Z","configurationStateId":1614184524750,"awsAccountId":"367923919544","configurationItemStatus":"OK","resourceType":"AWS::EC2::Instance","resourceId":"i-0bc99cf9453aa0e8c","resourceName":null,"ARN":"arn:aws:ec2:us-east-1:367923919544:instance/i-09c9293a75698b482","awsRegion":"sa-east-1","availabilityZone":"us-east-1c","configurationStateMd5Hash":"","resourceCreationTime":"2021-02-24T16:33:18.000Z"},"notificationCreationTime":"2021-02-24T17:55:05.026Z","messageType":"ConfigurationItemChangeNotification","recordVersion":"1.3"}'
    #invoking_event_alb_instance_test = '{"configurationItemDiff":null,"configurationItem":{"version":"1.3","accountId":"367923919544","configurationItemCaptureTime":"2021-02-28T02:03:45.030Z","configurationItemStatus":"ResourceDiscovered","configurationStateId":"1614477825030","configurationItemMD5Hash":"","arn":"arn:aws:elasticloadbalancing:us-east-1:367923919544:loadbalancer/app/demo-dev-alb/e3522f3cf6943b2f","resourceType":"AWS::ElasticLoadBalancingV2::LoadBalancer","resourceId":"arn:aws:elasticloadbalancing:us-east-1:367923919544:loadbalancer/app/demo-dev-alb/e3522f3cf6943b2f","resourceName":"demo-dev-alb","awsRegion":"sa-east-1","availabilityZone":"Multiple Availability Zones","resourceCreationTime":"2021-02-28T02:01:37.860Z","tags":{"Environment":"dev","Application":"demo","Name":"demo-dev-alb"},"relatedEvents":[],"relationships":[{"resourceType":"AWS::EC2::SecurityGroup","resourceId":"sg-0f922d67a9a737abc","relationshipName":"Is associated with SecurityGroup"},{"resourceType":"AWS::EC2::Subnet","resourceId":"subnet-0df3b822a8ac83c44","relationshipName":"Is attached to Subnet"},{"resourceType":"AWS::EC2::Subnet","resourceId":"subnet-0ea767ea041c243f7","relationshipName":"Is attached to Subnet"},{"resourceType":"AWS::EC2::VPC","resourceId":"vpc-0de0c167e0658f17c","relationshipName":"Is contained in Vpc"},{"resourceType":"AWS::EC2::Subnet","resourceId":"subnet-097f80db1e30bf529","relationshipName":"Is attached to Subnet"}],"configuration":{"loadBalancerArn":"arn:aws:elasticloadbalancing:us-east-1:367923919544:loadbalancer/app/demo-dev-alb/e3522f3cf6943b2f","dNSName":"demo-dev-alb-634246643.us-east-1.elb.amazonaws.com","canonicalHostedZoneId":"Z35SXDOTRQ7X7K","createdTime":"2021-02-28T02:01:37.860Z","loadBalancerName":"demo-dev-alb","scheme":"internet-facing","vpcId":"vpc-0de0c167e0658f17c","state":{"code":"active"},"type":"application","availabilityZones":[{"zoneName":"us-east-1b","subnetId":"subnet-097f80db1e30bf529","loadBalancerAddresses":[]},{"zoneName":"us-east-1c","subnetId":"subnet-0df3b822a8ac83c44","loadBalancerAddresses":[]},{"zoneName":"us-east-1a","subnetId":"subnet-0ea767ea041c243f7","loadBalancerAddresses":[]}],"securityGroups":["sg-0f922d67a9a737abc"],"ipAddressType":"ipv4"},"supplementaryConfiguration":{"LoadBalancerAttributes":[{"key":"access_logs.s3.enabled","value":"false"},{"key":"access_logs.s3.bucket","value":""},{"key":"access_logs.s3.prefix","value":""},{"key":"idle_timeout.timeout_seconds","value":"60"},{"key":"deletion_protection.enabled","value":"false"},{"key":"routing.http2.enabled","value":"true"},{"key":"routing.http.drop_invalid_header_fields.enabled","value":"false"},{"key":"routing.http.desync_mitigation_mode","value":"defensive"},{"key":"waf.fail_open.enabled","value":"false"},{"key":"waf.enabled","value":"false"},{"key":"waf.web_acl_id","value":""}],"Tags":[{"key":"Environment","value":"dev"},{"key":"Application","value":"demo"},{"key":"Name","value":"demo-dev-alb"}]},"resourceTransitionStatus":"None"},"notificationCreationTime":"2021-02-24T17:55:05.026Z","messageType":"ConfigurationItemChangeNotification","recordVersion":"1.3"}'
    
    def setUp(self):
        pass

    # def test_sample(self):
    #     self.assertTrue(True)
    
    # def test_EC2_Windows(self):
    #     RULE.ASSUME_ROLE_MODE = True
    #     myContext = MyContext('TEST001')
    #     response = RULE.lambda_handler(build_lambda_configurationchange_event(self.invoking_event_ec2_instance_windows, self.rule_parameters), myContext)
    #     resp_expected = []
    #     resp_expected.append(build_expected_response(
    #         'NON_COMPLIANT',
    #         'i-0d9fd5da74218e24c',
    #         'AWS::EC2::Instance','See the logs in: s3://terra-itau-ls-guardrails-output/AlarmsConfigCheckFunctionTerra/2021/04/08/i-0d9fd5da74218e24c/TEST001'))
    #     assert_successful_evaluation(self, response, resp_expected)

    def test_EC2_Linux(self):
        RULE.ASSUME_ROLE_MODE = True
        myContext = MyContext('TEST002')
        response = RULE.lambda_handler(build_lambda_configurationchange_event(self.invoking_event_ec2_instance_linux, self.rule_parameters), myContext)
        resp_expected = []
        resp_expected.append(build_expected_response(
            'COMPLIANT',
            'i-00d0012d4b9ba0eda',
            'AWS::EC2::Instance',
            'See the logs in: s3://cross-sae1-grdrails-output-s3-test/AlarmsConfigCheckFunctionTerra/2021/05/10/i-00d0012d4b9ba0eda/TEST002'))
        assert_successful_evaluation(self, response, resp_expected)
        
    # def test_EC2_Windows_Wsus(self):
    #     RULE.ASSUME_ROLE_MODE = True
    #     myContext = MyContext('TEST003')
    #     response = RULE.lambda_handler(build_lambda_configurationchange_event(self.invoking_event_ec2_instance_windows_wsus, self.rule_parameters), myContext)
    #     resp_expected = []
    #     resp_expected.append(build_expected_response(
    #         'NON_COMPLIANT',
    #         'i-0bc99cf9453aa0e8c',
    #         'AWS::EC2::Instance','See the logs in: s3://terra-itau-ls-guardrails-output/AlarmsConfigCheckFunctionTerra/2021/04/08/i-0bc99cf9453aa0e8c/TEST003'))
    #     assert_successful_evaluation(self, response, resp_expected)

    # def test_ALB(self):
    #     RULE.ASSUME_ROLE_MODE = True
    #     myContext = MyContext('TEST004')
    #     response = RULE.lambda_handler(build_lambda_configurationchange_event(self.invoking_event_alb_instance_test, self.rule_parameters), myContext)
    #     resp_expected = []
    #     resp_expected.append(build_expected_response(
    #         'COMPLIANT',
    #         'arn:aws:elasticloadbalancing:us-east-1:367923919544:loadbalancer/app/demo-dev-alb/e3522f3cf6943b2f',
    #         'AWS::ElasticLoadBalancingV2::LoadBalancer',
    #         'See the logs in: s3://terra-itau-ls-guardrails-output/AlarmsConfigCheckFunctionTerra/2021/04/08/app__demo-dev-alb__e3522f3cf6943b2f/TEST004'))
    #     assert_successful_evaluation(self, response, resp_expected)
####################
# Helper Functions #
####################

def build_lambda_configurationchange_event(invoking_event, rule_parameters=None):
    event_to_return = {
        'configRuleName':'myruleLocalTest',
        'executionRoleArn':'arn:aws:iam::367923919544:role/AWS-Landing-Zone-ConfigRecorderRole',
        'eventLeftScope': False,
        'invokingEvent': invoking_event,
        'accountId': '367923919544',
        'configRuleArn': 'arn:aws:config:us-east-1:367923919544:config-rule/config-rule-8fngan',
        'resultToken':'TESTMODE'
    }
    if rule_parameters:
        event_to_return['ruleParameters'] = rule_parameters
    return event_to_return

def build_lambda_scheduled_event(rule_parameters=None):
    invoking_event = '{"messageType":"ScheduledNotification","notificationCreationTime":"2017-12-23T22:11:18.158Z"}'
    event_to_return = {
        'configRuleName':'myrule',
        'executionRoleArn':'arn:aws:iam::367923919544:role/AWS-Landing-Zone-ConfigRecorderRole',
        'eventLeftScope': False,
        'invokingEvent': invoking_event,
        'accountId': '123456789012',
        'configRuleArn': 'arn:aws:config:us-east-1:123456789012:config-rule/config-rule-8fngan',
        'resultToken':'TESTMODE'
    }
    if rule_parameters:
        event_to_return['ruleParameters'] = rule_parameters
    return event_to_return

def build_expected_response(compliance_type, compliance_resource_id, compliance_resource_type=DEFAULT_RESOURCE_TYPE, annotation=None):
    if not annotation:
        return {
            'ComplianceType': compliance_type,
            'ComplianceResourceId': compliance_resource_id,
            'ComplianceResourceType': compliance_resource_type
            }
    return {
        'ComplianceType': compliance_type,
        'ComplianceResourceId': compliance_resource_id,
        'ComplianceResourceType': compliance_resource_type,
        'Annotation': annotation
        }

def assert_successful_evaluation(test_class, response, resp_expected, evaluations_count=1):
    if isinstance(response, dict):
        test_class.assertEquals(resp_expected['ComplianceResourceType'], response['ComplianceResourceType'])
        test_class.assertEquals(resp_expected['ComplianceResourceId'], response['ComplianceResourceId'])
        test_class.assertEquals(resp_expected['ComplianceType'], response['ComplianceType'])
        test_class.assertTrue(response['OrderingTimestamp'])
        if 'Annotation' in resp_expected or 'Annotation' in response:
            test_class.assertEquals(resp_expected['Annotation'], response['Annotation'])
    elif isinstance(response, list):
        test_class.assertEquals(evaluations_count, len(response))
        for i, response_expected in enumerate(resp_expected):
            test_class.assertEquals(response_expected['ComplianceResourceType'], response[i]['ComplianceResourceType'])
            test_class.assertEquals(response_expected['ComplianceResourceId'], response[i]['ComplianceResourceId'])
            test_class.assertEquals(response_expected['ComplianceType'], response[i]['ComplianceType'])
            test_class.assertTrue(response[i]['OrderingTimestamp'])
            if 'Annotation' in response_expected or 'Annotation' in response[i]:
                test_class.assertEquals(response_expected['Annotation'], response[i]['Annotation'])

def assert_customer_error_response(test_class, response, customer_error_code=None, customer_error_message=None):
    if customer_error_code:
        test_class.assertEqual(customer_error_code, response['customerErrorCode'])
    if customer_error_message:
        test_class.assertEqual(customer_error_message, response['customerErrorMessage'])
    test_class.assertTrue(response['customerErrorCode'])
    test_class.assertTrue(response['customerErrorMessage'])
    if "internalErrorMessage" in response:
        test_class.assertTrue(response['internalErrorMessage'])
    if "internalErrorDetails" in response:
        test_class.assertTrue(response['internalErrorDetails'])

# def sts_mock():
#     assume_role_response = {
#         "Credentials": {
#             "AccessKeyId": "string",
#             "SecretAccessKey": "string",
#             "SessionToken": "string"}}
#     STS_CLIENT_MOCK.reset_mock(return_value=True)
#     STS_CLIENT_MOCK.assume_role = MagicMock(return_value=assume_role_response)

##################
# Common Testing #
##################

# class TestStsErrors(unittest.TestCase):

#     def test_sts_unknown_error(self):
#         RULE.ASSUME_ROLE_MODE = True
#         RULE.evaluate_parameters = MagicMock(return_value=True)
#         STS_CLIENT_MOCK.assume_role = MagicMock(side_effect=botocore.exceptions.ClientError(
#             {'Error': {'Code': 'unknown-code', 'Message': 'unknown-message'}}, 'operation'))
#         response = RULE.lambda_handler(build_lambda_configurationchange_event('{}'), {})
#         assert_customer_error_response(
#             self, response, 'InternalError', 'InternalError')

#     def test_sts_access_denied(self):
#         RULE.ASSUME_ROLE_MODE = True
#         RULE.evaluate_parameters = MagicMock(return_value=True)
#         STS_CLIENT_MOCK.assume_role = MagicMock(side_effect=botocore.exceptions.ClientError(
#             {'Error': {'Code': 'AccessDenied', 'Message': 'access-denied'}}, 'operation'))
#         response = RULE.lambda_handler(build_lambda_configurationchange_event('{}'), {})
#         assert_customer_error_response(
#             self, response, 'AccessDenied', 'AWS Config does not have permission to assume the IAM role.')
