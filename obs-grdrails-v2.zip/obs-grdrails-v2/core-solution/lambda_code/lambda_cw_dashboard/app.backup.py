import boto3
import json
import copy
import os
import logging
from datetime import datetime

AUTOMATION_LAMBDA_ROLE_NAME = os.environ['AUTOMATION_LAMBDA_ROLE_NAME']

# event expected:
#
# event2 = { "accountID":"123456789012",
#     "tags": [
#       ["hom","si2","crm"]
#       ]}

#LAMBDA HANDLER RETURN

# LOGGER
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.info('## ENVIRONMENT VARIABLES')
logger.info(os.environ)

ACCOUNT_ID = ''
REGION = ''

ec2 = None

def lambda_handler(event, context):
  #get the credentials from the assumed Role
  global ACCOUNT_ID, REGION
  global ec2
  ACCOUNT_ID = str(event['accountID'])
  REGION = 'sa-east-1'
  
  credentials = get_credentials( ACCOUNT_ID )
  
  #cloudwatch client
  cw = get_boto_client ( 'cloudwatch', credentials )
  
  ec2 = get_boto_client ( 'ec2', credentials )
  
  #resourcegroupstaggingapi client
  taggingapi = get_boto_client ( 'resourcegroupstaggingapi', credentials )
  
  # DASHBOARDS & WIDGET TEMPLATES
  widget_json = {
    "widgets": []
  }
  
  scafolding_json = {
    "type": "metric",
    "width": 6,
    "height": 6,
    "properties": {
        "view": "timeSeries",
        "stacked": False,
        "metrics": [],
        "region": REGION,
        "period": 60,
        "title": "",
        "annotations":{ },
        "yAxis": { "left": { "min": 0 } }
    }
  }
  
  unsorted_tagged_arn_list = []
  region_arn_list = []
  dimensions_dictionary = {}
  dashboards_response = []
  
  for tags in event['tags']:
    unsorted_tagged_arn_list = []
    region_arn_list = []
    dimensions_dictionary = {}
    tags_values = [ { "/Tags/ambiente": tags[0] }, { "/Tags/sigla": tags[1] }, { "/Tags/nomeProdutoShort": tags[2] } ]
    unsorted_tagged_arn_list.append( get_tagged_resources( taggingapi, tags_values ))
    region_arn_list.append ( unsorted_tagged_arn_list )
    sorted_tagged_arn_list = sort_list(region_arn_list)
    
    logger.info ('sorted_list')
    logger.info (sorted_tagged_arn_list)
    
    create_widgets( cw , sorted_tagged_arn_list , widget_json , scafolding_json , logger)
    dashboards_response.append( create_dashboard(cw, json.dumps(widget_json), tags_values) )
  
  return dashboards_response

def get_credentials( accountID ):
  executionRoleArn = 'arn:aws:iam::' + accountID +':role/' + AUTOMATION_LAMBDA_ROLE_NAME
  sts_client = boto3.client('sts')
  assumed_role_object=sts_client.assume_role(
    RoleArn=executionRoleArn,
    RoleSessionName="AssumeRoleSession1"
  )
  return assumed_role_object['Credentials']


def get_boto_client ( client_name:str , credentials ):
  return boto3.client(
    client_name,
    aws_access_key_id=credentials['AccessKeyId'],
    aws_secret_access_key=credentials['SecretAccessKey'],
    aws_session_token=credentials['SessionToken'],
    region_name = 'sa-east-1'
  )

def get_ec2_running_instances ( ec2 ):
  paginator = ec2.get_paginator ( 'describe-instances' )
  
  ec2_instances = []
  page_iterator = paginator.paginate( Filters=[ { 'Name': 'instance-state-name', 'Values': [ 'running' ] } ] ) 

  for page in page_iterator:
    ec2_instances.extend( page['Reservations'][0]['Instances'] )
  
  result = [ x['InstanceId'] for x in ec2_instances ]
  print ( result )
  return result

def get_tagged_resources(request, tags:list )->list:
  paginator = request.get_paginator('get_resources')
  page_iterator = paginator.paginate(TagFilters=[
    {
      'Key': list(tags[0].keys())[0],
      'Values': [
          list(tags[0].values())[0]
      ]
    },
    {
      'Key': list(tags[1].keys())[0],
      'Values': [
          list(tags[1].values())[0]
      ]
    },
    {
      'Key': list(tags[2].keys())[0],
      'Values': [
          list(tags[2].values())[0]
      ]
    }
  ])
  
  account_arn_list = []
  for page in page_iterator:
    for item in page['ResourceTagMappingList']:
        account_arn_list.append(item['ResourceARN'].split(':'))
  
  return account_arn_list


def __list_metrics( cw, namespace:str, metricName:str, dimensions:list, sorted_tagged_arn_list:list ):
    
    global ec2
    
    logger.info( 'namespace : ' + namespace )
    logger.info( 'metricName : ' + metricName )
    logger.info( dimensions )
    resp = cw.list_metrics( Namespace = namespace, MetricName = metricName, Dimensions = dimensions )
    logger.info( '__list_metrics resp 01' )  
    logger.info( resp )

    logger.info( 'sorted_tagged_arn_list' )  
    logger.info( sorted_tagged_arn_list )

    resp = [ { "Namespace": namespace, "MetricName": metric['MetricName'], "Dimensions": metric['Dimensions'] } for metric in resp['Metrics'] ]
    
    logger.info( '__list_metrics resp 02' )  
    logger.info( resp )
    
    
    instance_ids_running = get_ec2_running_instances ( ec2 )
    
    metrics = []
    for metric in resp:
      dimension = []
      exists_in_tagged_list = False
      dimension.append ( metric['Namespace'])
      dimension.append ( metric['MetricName'] )
      logger.info( metric['Namespace'] )
      for dim in metric['Dimensions']:
        dimension.append (dim['Name'])
        dimension.append (dim['Value'])
        
        if metric['Namespace'] in [ 'CWAgent', 'AWS/EC2' ]:
          if dim['Name'] == 'InstanceId':
            #if dim['Value'] in instance_ids_running:
              logger.info ( dim['Value'] )
              exists_in_tagged_list = True if ( len( [ x for x in sorted_tagged_arn_list if dim['Value'] == x[-1].split('/')[-1] ]) > 0 ) else False
                
        elif metric['Namespace'] in [ 'AWS/ApplicationELB', 'AWS/NetworkELB' ]:
          if dim['Name'] == 'LoadBalancer':
              logger.info ( dim['Value'] )
              exists_in_tagged_list = True if ( len( [ x for x in sorted_tagged_arn_list if dim['Value'] == '/'.join( x[-1].split('/')[ 1:4 ] ) ] ) > 0 ) else False
        
        elif metric['Namespace'] in [ 'AWS/RDS' ]:
          if dim['Name'] == 'DBInstanceIdentifier':
              logger.info ( dim['Value'] )
              exists_in_tagged_list = True if ( len( [ x for x in sorted_tagged_arn_list if dim['Value'] == x[-1]  ] ) > 0 ) else False

        elif metric['Namespace'] in [ 'AWS/Lambda' ]:
          if dim['Name'] == 'FunctionName':
              logger.info ( dim['Value'] )
              exists_in_tagged_list = True if ( len( [ x for x in sorted_tagged_arn_list if dim['Value'] == x[-1]  ] ) > 0 ) else False
                
        else: raise NotImplementedError
      
      #logger.info( 'exists_in_tagged_list: {}'.format ( str(exists_in_tagged_list)) )
      if exists_in_tagged_list:
        metrics.append(dimension.copy())
     
    logger.info( '__list_metrics results, namespace:{}, metricname:{}'.format(namespace, metricName) )  
    logger.info( metrics )
    return metrics


def nlb_get_existing_metrics_list (cw, sorted_tagged_arn_list):
    
    existing_metrics_list = []

    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/NetworkELB', metricName = 'UnHealthyHostCount', dimensions = [ {'Name':'LoadBalancer'}, {'Name':'TargetGroup'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/NetworkELB', metricName = 'TCP_Client_Reset_Count', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/NetworkELB', metricName = 'ProcessedBytes', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/NetworkELB", metricName = 'ActiveFlowCount', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/NetworkELB", metricName = 'ConsumedLCUs', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )

    logger.debug( existing_metrics_list )
    return existing_metrics_list
    
    
def alb_get_existing_metrics_list (cw, sorted_tagged_arn_list):
    
    existing_metrics_list = []

    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/ApplicationELB', metricName = 'UnHealthyHostCount', dimensions = [ {'Name':'LoadBalancer'}, {'Name':'TargetGroup'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/ApplicationELB', metricName = 'HTTPCode_Target_5XX_Count', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/ApplicationELB', metricName = 'RejectedConnectionCount', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/ApplicationELB", metricName = 'TargetResponseTime', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/ApplicationELB", metricName = 'ActiveConnectionCount', dimensions = [ {'Name':'LoadBalancer'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )

    logger.debug( existing_metrics_list )
    return existing_metrics_list


def rds_get_existing_metrics_list (cw, sorted_tagged_arn_list):
    
    existing_metrics_list = []

    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/RDS', metricName = 'CPUUtilization', dimensions = [ {'Name':'DBInstanceIdentifier'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/RDS', metricName = 'DatabaseConnections', dimensions = [ {'Name':'DBInstanceIdentifier'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/RDS', metricName = 'ReadLatency', dimensions = [ {'Name':'DBInstanceIdentifier'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/RDS", metricName = 'WriteLatency', dimensions = [ {'Name':'DBInstanceIdentifier'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/RDS", metricName = 'FreeStorageSpace', dimensions = [ {'Name':'DBInstanceIdentifier'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "AWS/RDS", metricName = 'DiskQueueDepth', dimensions = [ {'Name':'DBInstanceIdentifier'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )

    logger.debug( existing_metrics_list )
    return existing_metrics_list

def cw_get_existing_metrics_list (cw, sorted_tagged_arn_list):
    
    existing_metrics_list = []
    
    # existing_metrics_list += \
    #     __list_metrics( cw = cw, namespace = 'CWAgent', metricName = 'disk_used_percent', dimensions = [ {'Name':'InstanceId'}, {'Name':'InstanceType'}, {'Name':'ImageId'}, {'Name':'device'}, {'Name':'fstype'}, {'Name':'path'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    # existing_metrics_list += \
    #     __list_metrics( cw = cw, namespace = 'CWAgent', metricName = 'swap_used_percent', dimensions = [ {'Name':'InstanceId'}, {'Name':'InstanceType'}, {'Name':'ImageId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    # existing_metrics_list += \
    #     __list_metrics( cw = cw, namespace = 'CWAgent', metricName = 'mem_used_percent', dimensions = [ {'Name':'InstanceId'}, {'Name':'InstanceType'}, {'Name':'ImageId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'CWAgent', metricName = 'disk_used_percent', dimensions = [ {'Name':'InstanceId'}, {'Name':'device'}, {'Name':'fstype'}, {'Name':'path'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'CWAgent', metricName = 'swap_used_percent', dimensions = [ {'Name':'InstanceId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'CWAgent', metricName = 'mem_used_percent', dimensions = [ {'Name':'InstanceId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )

    # existing_metrics_list += \
    #     __list_metrics( cw = cw, namespace = "CWAgent", metricName = 'Memory % Committed Bytes In Use', dimensions = [ {'Name':'InstanceId'}, {'Name':'InstanceType'}, {'Name':'ImageId'}, {'Name':'objectname'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    # existing_metrics_list += \
    #     __list_metrics( cw = cw, namespace = "CWAgent", metricName = 'Paging File % Usage', dimensions = [ {'Name':'InstanceId'}, {'Name':'InstanceType'}, {'Name':'ImageId'}, {'Name':'objectname'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    # existing_metrics_list += \
    #     __list_metrics( cw = cw, namespace = "CWAgent", metricName = 'LogicalDisk % Free Space', dimensions = [ {'Name':'InstanceId'}, {'Name':'InstanceType'}, {'Name':'ImageId'}, {'Name':'objectname'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "CWAgent", metricName = 'Memory % Committed Bytes In Use', dimensions = [ {'Name':'InstanceId'}, {'Name':'objectname'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "CWAgent", metricName = 'Paging File % Usage', dimensions = [ {'Name':'InstanceId'}, {'Name':'objectname'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = "CWAgent", metricName = 'LogicalDisk % Free Space', dimensions = [ {'Name':'InstanceId'}, {'Name':'objectname'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )

    logger.info( existing_metrics_list )
    return existing_metrics_list


def create_dashboard(cw, dashboard_body, tag_values:list):
    #TODO: Finalize the name with Value of Tags
    response = cw.put_dashboard(
      #DashboardName='{}-sae1-{}-{}-automated-cloudWatch-dashboard'.format(event['tags'][0]['/Tags/ambiente'],event['tags'][1]['/Tags/sigla'],event['tags'][2]['/Tags/nomeProdutoShort']), DashboardBody=dashboard_body)
      DashboardName='{}-sae1-{}-{}-automated-cloudWatch-dashboard'.format( list(tag_values[0].values())[0], list(tag_values[1].values())[0], list(tag_values[2].values())[0] ), DashboardBody = dashboard_body)
    return response


def ec2_get_existing_metrics_list (cw, sorted_tagged_arn_list):
    
    existing_metrics_list = []

    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/EC2', metricName = 'CPUUtilization', dimensions = [ {'Name':'InstanceId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/EC2', metricName = 'NetworkIn', dimensions = [ {'Name':'InstanceId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/EC2', metricName = 'NetworkOut', dimensions = [ {'Name':'InstanceId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/EC2', metricName = 'StatusCheckFailed', dimensions = [ {'Name':'InstanceId'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )

    logger.debug( existing_metrics_list )
    return existing_metrics_list

def lambda_get_existing_metrics_list (cw, sorted_tagged_arn_list):
    
    existing_metrics_list = []

    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/Lambda', metricName = 'Throttles', dimensions = [ {'Name':'FunctionName'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/Lambda', metricName = 'Duration', dimensions = [ {'Name':'FunctionName'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/Lambda', metricName = 'Errors', dimensions = [ {'Name':'FunctionName'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/Lambda', metricName = 'Invocations', dimensions = [ {'Name':'FunctionName'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
    existing_metrics_list += \
        __list_metrics( cw = cw, namespace = 'AWS/Lambda', metricName = 'ConcurrentExecutions', dimensions = [ {'Name':'FunctionName'} ], sorted_tagged_arn_list = sorted_tagged_arn_list )
        
    logger.debug( existing_metrics_list )
    return existing_metrics_list


def create_widgets(cw,sorted_tagged_arn_list,widget_json,scafolding_json,logger):
    #ARN KEY MAPPING
    arn_keys = ['arn','segment','service','region','account','resource','item']
    
    # # Elasticache
    # elasticache_metric_dimensions = get_elasticache_metric_dimensions(arn_keys,sorted_tagged_arn_list)
    # if len(elasticache_metric_dimensions) >= 1:
    #     widget_json['widgets'].append(create_widget('ElasticCache CPU Utilization', scafolding_json, 'AWS/ElastiCache', 
    #                                                 'CPUUtilization', 'CacheClusterId', elasticache_metric_dimensions))
    #     widget_json['widgets'].append(create_widget('ElasticCache Evictions', scafolding_json, 'AWS/ElastiCache', 'Evictions', 
    #                                                 'CacheClusterId', elasticache_metric_dimensions))
    #     widget_json['widgets'].append(create_widget('ElasticCache CurrConnections', scafolding_json, 'AWS/ElastiCache', 
    #                                                 'CurrConnections', 'CacheClusterId', elasticache_metric_dimensions))
    
    # Classic Load Balancer
    #     clb_metric_dimensions = get_clb_metric_dimensions(arn_keys,sorted_tagged_arn_list)
    #     widget_json['widgets'].append(create_widget('CLB Request Count', scafolding_json, 'AWS/ELB', 
    #                                                 'RequestCount', 'LoadBalancerName', clb_metric_dimensions))
    #     widget_json['widgets'].append(create_widget('CLB Healthy Host Count', scafolding_json, 'AWS/ELB', 
    #                                                 'HealthyHostCount', 'LoadBalancerName', clb_metric_dimensions))
    #     widget_json['widgets'].append(create_widget('CLB Unhealthy Host Count', scafolding_json, 'AWS/ELB', 
    #                                                 'UnHealthyHostCount', 'LoadBalancerName', clb_metric_dimensions))
    #     widget_json['widgets'].append(create_widget('CLB 5XX Count', scafolding_json, 'AWS/ELB', 
    #                                                 'HTTPCode_ELB_5XX', 'LoadBalancerName', clb_metric_dimensions))

    # Application Load Balancer
    existing_alb_metric_dimensions = alb_get_existing_metrics_list ( cw, sorted_tagged_arn_list )
    logger.info ( 'existing_alb_metric_dimensions' )
    logger.info ( existing_alb_metric_dimensions )
    if len(existing_alb_metric_dimensions) >= 1:
        widget_json['widgets'].append(
            create_widgetv2('ALB Target Response Time per LB', scafolding_json, [ dim for dim in existing_alb_metric_dimensions if dim[1] == 'TargetResponseTime' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim ) ], { "label": "Target Response Time (Seconds) Alert Limit", "value": 3 } ))
        widget_json['widgets'].append(
            create_widgetv2('ALB Active Connection Count per LB', scafolding_json, [ dim for dim in existing_alb_metric_dimensions if dim[1] == 'ActiveConnectionCount' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('ALB 5XX Count per LB', scafolding_json, [ dim for dim in existing_alb_metric_dimensions if dim[1] == 'HTTPCode_Target_5XX_Count' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('ALB Unhealthy Host Count per TargetGroup', scafolding_json, [ dim for dim in existing_alb_metric_dimensions if dim[1] == 'UnHealthyHostCount' and not ( 'AvailabilityZone' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('ALB Rejected Connection Count per LB', scafolding_json, [ dim for dim in existing_alb_metric_dimensions if dim[1] == 'RejectedConnectionCount' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )]))

    # CW Agent
    #TODO: FILTER FOR WINDOWS IF EXISTS OR LINUX
    existing_cwagent_metric_dimensions = cw_get_existing_metrics_list( cw, sorted_tagged_arn_list )
    if len(existing_cwagent_metric_dimensions) >= 1:
        widget_json['widgets'].append(
            create_widgetv2('Windows Memory Commited %', scafolding_json, [ dim for dim in existing_cwagent_metric_dimensions if dim[1] == 'Memory % Committed Bytes In Use' and not ( 'ImageId' in dim ) and not ( 'InstanceType' in dim )],{"label": "Memory (%) Alert Limit", "value": 80}))
        widget_json['widgets'].append(
            create_widgetv2('Windows Logical Free Space %', scafolding_json, [ dim for dim in existing_cwagent_metric_dimensions if dim[1] == 'LogicalDisk % Free Space' and not ( 'ImageId' in dim ) and not ( 'InstanceType' in dim )],{"label": "Free disk space (%) Alert Limit", "value": 10}))
        widget_json['widgets'].append(
            create_widgetv2('Windows Paging File Usage %', scafolding_json, [ dim for dim in existing_cwagent_metric_dimensions if dim[1] == 'Paging File % Usage' and not ( 'ImageId' in dim ) and not ( 'InstanceType' in dim )],{"label": "Windows Paging File Usage (%) Alert Limit", "value": 80}))
        widget_json['widgets'].append(
            create_widgetv2('Linux Memory Usage %', scafolding_json, [ dim for dim in existing_cwagent_metric_dimensions if dim[1] == 'mem_used_percent' and not ( 'ImageId' in dim ) and not ( 'InstanceType' in dim )],{"label": "Linux Memory Usage (%) Alert Limit", "value": 80}))
        widget_json['widgets'].append(
            create_widgetv2('Linux Logical Disk Usage %', scafolding_json, [ dim for dim in existing_cwagent_metric_dimensions if dim[1] == 'disk_used_percent' and not ( 'ImageId' in dim ) and not ( 'InstanceType' in dim )],{"label": "Linux Disk Usage (%) Alert Limit", "value": 90}))
        widget_json['widgets'].append(
            create_widgetv2('Linux Swap Usage %', scafolding_json, [ dim for dim in existing_cwagent_metric_dimensions if dim[1] == 'swap_used_percent' and not ( 'ImageId' in dim ) and not ( 'InstanceType' in dim )],{"label": "Linux Swap Usage (%) Alert Limit", "value": 80}))

    # EC2
    existing_ec2_metric_dimensions = ec2_get_existing_metrics_list( cw, sorted_tagged_arn_list )
    if len(existing_ec2_metric_dimensions) >= 1:
        widget_json['widgets'].append(
            create_widgetv2('EC2 CPU Utilization per Instance', scafolding_json, [ dim for dim in existing_ec2_metric_dimensions if dim[1] == 'CPUUtilization'],{"label": "CPU Utilization (%) Alert Limit", "value": 90}))
        widget_json['widgets'].append(
            create_widgetv2('EC2 Network In per Instance', scafolding_json, [ dim for dim in existing_ec2_metric_dimensions if dim[1] == 'NetworkIn']))
        widget_json['widgets'].append(
            create_widgetv2('EC2 Network Out per Instance', scafolding_json, [ dim for dim in existing_ec2_metric_dimensions if dim[1] == 'NetworkOut']))
        widget_json['widgets'].append(
            create_widgetv2('EC2 Status Check per Instance', scafolding_json, [ dim for dim in existing_ec2_metric_dimensions if dim[1] == 'StatusCheckFailed'],{"label": "Status Check Failed Alert Limit", "value": 1}))

    # RDS
    existing_rds_metric_dimensions = rds_get_existing_metrics_list( cw, sorted_tagged_arn_list)
    if len(existing_rds_metric_dimensions) >= 1:
        widget_json['widgets'].append(
            create_widgetv2('RDS CPU Utilization per DB Instance', scafolding_json, [ dim for dim in existing_rds_metric_dimensions if dim[1] == 'CPUUtilization'],{"label": "CPU Utilization (%) Alert Limit", "value": 90}))
        widget_json['widgets'].append(
            create_widgetv2('RDS DB Connections per DB Instance', scafolding_json, [ dim for dim in existing_rds_metric_dimensions if dim[1] == 'DatabaseConnections']))
        widget_json['widgets'].append(
            create_widgetv2('RDS Read Latency per DB Instance', scafolding_json, [ dim for dim in existing_rds_metric_dimensions if dim[1] == 'ReadLatency'],{"label": "Read Latency (sec) Alert Limit", "value": 0.1}))
        widget_json['widgets'].append(
            create_widgetv2('RDS Write Latency per DB Instance', scafolding_json, [ dim for dim in existing_rds_metric_dimensions if dim[1] == 'WriteLatency'],{"label": "Write Latency (sec) Alert Limit", "value": 0.1}))
        widget_json['widgets'].append(
            create_widgetv2('RDS Free Storage Space per DB Instance', scafolding_json, [ dim for dim in existing_rds_metric_dimensions if dim[1] == 'FreeStorageSpace']))
        widget_json['widgets'].append(
            create_widgetv2('RDS Disk Queue Depth per DB Instance', scafolding_json, [ dim for dim in existing_rds_metric_dimensions if dim[1] == 'DiskQueueDepth'],{"label": "Disk Queue Alert Limit", "value": 3}))

    # Network Load Balancer
    existing_nlb_metric_dimensions = nlb_get_existing_metrics_list( cw, sorted_tagged_arn_list )
    if len( existing_nlb_metric_dimensions ) >= 1:
        widget_json['widgets'].append(
            create_widgetv2('NLB TCP Client Reset Count per LB', scafolding_json, [ dim for dim in existing_nlb_metric_dimensions if dim[1] == 'TCP_Client_Reset_Count' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )] ))
        widget_json['widgets'].append(
            create_widgetv2('NLB Processed Bytes per LB', scafolding_json, [ dim for dim in existing_nlb_metric_dimensions if dim[1] == 'ProcessedBytes' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('NLB Active Flow Count per LB', scafolding_json, [ dim for dim in existing_nlb_metric_dimensions if dim[1] == 'ActiveFlowCount' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('NLB Unhealthy Host Count per TargetGroup', scafolding_json, [ dim for dim in existing_nlb_metric_dimensions if dim[1] == 'UnHealthyHostCount' and not ( 'AvailabilityZone' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('NLB Consumed LCUs per LB', scafolding_json, [ dim for dim in existing_nlb_metric_dimensions if dim[1] == 'ConsumedLCUs' and not ( 'TargetGroup' in dim ) and not ( 'AvailabilityZone' in dim )]))

    # Lambda
    existing_lambda_metric_dimensions = lambda_get_existing_metrics_list( cw, sorted_tagged_arn_list)
    if len(existing_lambda_metric_dimensions) >= 1:
        widget_json['widgets'].append(
            create_widgetv2('Lambda Throttles per Function', scafolding_json, [ dim for dim in existing_lambda_metric_dimensions if dim[1] == 'Throttles' and not ( 'Resource' in dim )] ))
        widget_json['widgets'].append(
            create_widgetv2('Lambda Duration per Function', scafolding_json, [ dim for dim in existing_lambda_metric_dimensions if dim[1] == 'Duration' and not ( 'Resource' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('Lambda Errors per Function', scafolding_json, [ dim for dim in existing_lambda_metric_dimensions if dim[1] == 'Errors' and not ( 'Resource' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('Lambda Invocations per Function', scafolding_json, [ dim for dim in existing_lambda_metric_dimensions if dim[1] == 'Invocations' and not ( 'Resource' in dim )]))
        widget_json['widgets'].append(
            create_widgetv2('Lambda Concurrent Execs per Function', scafolding_json, [ dim for dim in existing_lambda_metric_dimensions if dim[1] == 'ConcurrentExecutions' and not ( 'Resource' in dim )]))

    return True
    
def create_widgetv2 (title, scaffolding_json, metric_dimensions, horizontal_annotation = None ):
    widget = copy.deepcopy(scaffolding_json)
    for metric_dimension in metric_dimensions:
        arr = []
        for s in metric_dimension:
            arr.append(s)
        arr.append( { "region": REGION, "accountId": ACCOUNT_ID } )
        widget['properties']['metrics'].append( arr.copy() )
    widget['properties']['title'] = title
    
    if horizontal_annotation != None:
        widget['properties']['annotations']['horizontal'] = [ horizontal_annotation ]
    return widget

# def create_widgetv2 (title, scaffolding_json, metric_dimensions, horizontal_annotation = None ):
#     widget = copy.deepcopy(scaffolding_json)
#     for metric_dimension in metric_dimensions:
#         arr = []
#         for s in metric_dimension:
#             arr.append(s)
#         # TODO:FIX Account ID and Region
#         arr.append( { "region": REGION, "accountId": ACCOUNT_ID } )
#         widget['properties']['metrics'].append( arr.copy() )
#     widget['properties']['title'] = title
    
#     if horizontal_annotation != None:
#         widget['properties']['annotations']['horizontal'] = [ horizontal_annotation ]
#     return widget

# def create_widget(title, scaffolding_json, namespace, metric, metric_dimension_name, metric_dimensions):
#     widget = copy.deepcopy(scaffolding_json)
#     for metric_dimension in metric_dimensions:
#         widget['properties']['metrics'].append([namespace, metric, 
#                                                 metric_dimension_name, metric_dimension['id'] ,
#                                                 { "region": metric_dimension['region'], "accountId": metric_dimension['account']}])
#     widget['properties']['title'] = title
#     return widget

# def get_rds_metric_dimensions(arn_keys,sorted_tagged_arn_list):
#     rds_metric_dimensions = []
#     for arn_item in sorted_tagged_arn_list:
#         arn_item_value = dict(zip(arn_keys, arn_item))
#         if arn_item_value['service'] == 'rds':
#             if arn_item_value['resource'] == 'db':
#                 resource = arn_item_value['item']
#                 rds_metric_dimensions.append(dict(
#                     id=resource,
#                     region=arn_item_value['region'],
#                     account=arn_item_value['account']
#                 ))
#     return rds_metric_dimensions
    
def get_lambda_metric_dimensions(arn_keys,sorted_tagged_arn_list):
    lambda_metric_dimensions = []
    for arn_item in sorted_tagged_arn_list:
        arn_item_value = dict(zip(arn_keys, arn_item))
        if arn_item_value['service'] == 'lambda':
            if arn_item_value['resource'] == 'function':
                resource = arn_item_value['item']
                lambda_metric_dimensions.append(dict(
                    id=resource,
                    region=arn_item_value['region'],
                    account=arn_item_value['account']
                ))
    return lambda_metric_dimensions

# def get_elasticache_metric_dimensions(arn_keys,sorted_tagged_arn_list):
#     elasticache_metric_dimensions = []
#     for arn_item in sorted_tagged_arn_list:
#         arn_item_value = dict(zip(arn_keys, arn_item))
#         if arn_item_value['service'] == 'elasticache':
#             if arn_item_value['resource'] == 'cluster':
#                 resource = arn_item_value['item']
#                 elasticache_metric_dimensions.append(dict(
#                     id=resource,
#                     region=arn_item_value['region'],
#                     account=arn_item_value['account']
#                 ))
#     return elasticache_metric_dimensions
    
    
def sort_list(unsorted_tagged_arn_list):
    temp_list = []
    for arn_item_per_region in unsorted_tagged_arn_list:
        for arn_item_per_account in arn_item_per_region:
            for arn_item in arn_item_per_account:
                if arn_item:
                    temp_list.append(arn_item)
    return temp_list