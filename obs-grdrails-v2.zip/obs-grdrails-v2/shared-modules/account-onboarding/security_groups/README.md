# Security Group Module

This module can be used as part of Account of Workload Onboarding.

## Parameters

1. **enable_sg_rds_sql_server** Bolean, (Optional): Boolean to generate RDS SqlServer SG during the onboarding
    - *Default*: false

---

- **sg_rds_sql_server_ports** Object (Optional): MSSQL ports, if not specified it consider the default
  - *Default*: {
    "from_port" = 1433,
    "to_port"   = 1433
  }

---

- **enable_sg_datagrid** Bolean, (Optional): Boolean to generate DataGrid SG during the onboarding
  - *Default*: false

---

- **sg_rds_sql_server_ports** Object (Optional): MSSQL ports, if not specified it consider the default

  - *Default*: {
    "hot_rod" = {
      "from_port" = 11222,
      "to_port"   = 11222
    },
    "multicast" = {
      "from_port" = 0,
      "to_port"   = 65535
    }
  }



## Usage

Here's a code snippet on how to use this module

```tf


module "core" {
  source         = "git@ssh.gitlab.aws.dev:itau-am3-lift-shift/core-ops.git"
  sigla          = "SI2"
  group_name     = "si2"
  sub_group_name = "boleto"
}

#Default ports usage
module "onboad_sg" {
  source                   = "git@ssh.gitlab.aws.dev:itau-am3-lift-shift/terraform-modules/account_onboarding.git//security_groups"
  core_ops                 = module.core.core_ops
  enable_sg_rds_sql_server = true  #Generate RDS SQL Server roles
  enable_sg_datagrid       = false #Do not generate the Datagrid roles
}

#Alter the Default Ports
module "onboad_sg_custom" {
  source                   = "git@ssh.gitlab.aws.dev:itau-am3-lift-shift/terraform-modules/account_onboarding.git//security_groups"
  core_ops                 = module.core.core_ops
  enable_sg_rds_sql_server = true   #Generate the RDS SQL Server roles
  sg_rds_sql_server_ports = {       #Alter Default ports
    "from_port" = 1488
    "to_port"   = 1433
  }
  enable_sg_datagrid = true         #Generate the Datagrid roles
  sg_datagrid_ports = {             #Alter Default ports
    "hot_rod" = {
      "from_port" = 11555
      "to_port"   = 11222
    }

    "multicast" = {
      "from_port" = 0
      "to_port"   = 65535
    }
  }
}
```
