import boto3
import botocore
import json
import logging

from os import environ

# Getting environment variables
APICONNECTOR_FILE_NAME                       = environ.get('APICONNECTOR_FILE_NAME')
APICONNECTOR_FILE_PATH                       = environ.get('APICONNECTOR_FILE_PATH')
DYNAMODB_TABLE_NAME                          = environ.get('DYNAMODB_TABLE_NAME')
SSM_API_CONNECTOR_CONFIG_INTERNET_PARAM_NAME = environ.get('SSM_API_CONNECTOR_CONFIG_INTERNET_PARAM_NAME')
SSM_API_CONNECTOR_CONFIG_MOBILE_PARAM_NAME   = environ.get('SSM_API_CONNECTOR_CONFIG_MOBILE_PARAM_NAME')

if "APICONNECTOR_FILE_NAME" not in environ:
    raise ValueError("Variável de ambiente APICONNECTOR_FILE_NAME deve ser informada a fim de especificar a palavra-chave para substituição e montagem do nome do parâmetro SSM que possui o JSON de configuração do canal.")
    
if "APICONNECTOR_FILE_PATH" not in environ:
    raise ValueError("Variável de ambiente APICONNECTOR_FILE_PATH deve ser informada a fim de especificar a palavra-chave para substituição e montagem do caminho de escrita do arquivo JSON de configuração do ApiConnector.")

if "DYNAMODB_TABLE_NAME" not in environ:
    raise ValueError("Variável de ambiente DYNAMODB_TABLE_NAME deve ser informada a fim de especificar o nome da tabela DynamoDB onde residem os conjuntos de terminais a serem alocados.")
    
if "SSM_API_CONNECTOR_CONFIG_INTERNET_PARAM_NAME" not in environ:
    raise ValueError("Variável de ambiente SSM_API_CONNECTOR_CONFIG_INTERNET_PARAM_NAME deve ser informada a fim de especificar o nome do parâmetro SSM que armazena o JSON de configuração do canal.")

if "SSM_API_CONNECTOR_CONFIG_MOBILE_PARAM_NAME" not in environ:
    raise ValueError("Variável de ambiente SSM_API_CONNECTOR_CONFIG_MOBILE_PARAM_NAME deve ser informada a fim de especificar o nome do parâmetro SSM que armazena o caminho do arquivo JSON a ser escrito.")


# Logging initialization function
logging.basicConfig(level=os.getenv('LOG_LEVEL', 'ERROR'))


def _obter_json_do_canal(canal):
  if canal.lower() == "internet":
    return _obter_ssm_parameter(SSM_API_CONNECTOR_CONFIG_INTERNET_PARAM_NAME)

  elif canal.lower() == "mobile":
    return _obter_ssm_parameter(SSM_API_CONNECTOR_CONFIG_MOBILE_PARAM_NAME)

  # If not found, raise an error
  raise ValueError("Não foi possível obter a estrutura JSON utilizada pelo ApiConnector, para o canal {}.".format(canal))


def _obter_output_config_file_path(file_path, file_name, hostname):
  new_file_name = ".".join([file_name.split(".")[0], hostname, file_name.split(".")[-1]])
  return "/".join([file_path, new_file_name])


def _obter_ssm_parameter(param_name):
  client = boto3.client('ssm')
  response = client.get_parameter(
    Name=param_name
  )
    
  if response and response.get('ResponseMetadata') and \
    response.get('ResponseMetadata').get('HTTPStatusCode', 0) == 200 and \
    response.get('Parameter') and response.get('Parameter').get('Value'):
    return response.get('Parameter').get('Value')
      
  return None


def _obter_conjunto_terminais_livres():
  resource = boto3.resource('dynamodb')
  table = resource.Table(DYNAMODB_TABLE_NAME)
  
  scan_kwargs = {
    'FilterExpression': 'attribute_not_exists(instanceId)',
    'ReturnConsumedCapacity': 'TOTAL'
  }

  items     = []
  done      = False
  start_key = None
  count     = 0
  while not done:
    # Dealing with pagination
    if start_key:
      scan_kwargs['ExclusiveStartKey'] = start_key

    response = table.scan(**scan_kwargs)
    items.extend(response.get('Items', []))
    
    # Dealing with pagination
    count     += response.get('Count', 0)
    start_key  = response.get('LastEvaluatedKey', None)
    done       = start_key is None or count > 0
      
  # Returning only one set of terminals to allocate
  if len(items) > 0:
    return items[0]
  
  return None
    

def _alocar_conjunto_terminais(auto_scaling_group_name, instance_id):
  resource  = boto3.resource('dynamodb')
  table     = resource.Table(DYNAMODB_TABLE_NAME)
  allocated = False

  conjunto_terminais_livres = _obter_conjunto_terminais_livres()
  
  while conjunto_terminais_livres and not allocated:
    try:
      response = table.update_item(
        Key={
          'idConjunto': conjunto_terminais_livres.get('idConjunto')
        },
        UpdateExpression='SET instanceId = :instanceId, autoScalingGroupName = :autoScalingGroupName',
        ConditionExpression='attribute_not_exists(instanceId)',
        ExpressionAttributeValues={
          ':instanceId': instance_id,
          ':autoScalingGroupName': auto_scaling_group_name
        }
      )
      
      if response.get('ResponseMetadata').get('HTTPStatusCode', 0) == 200:
        allocated = True
        return conjunto_terminais_livres

    except botocore.exceptions.ClientError as e:
      # Ignore the ConditionalCheckFailedException - Race Condition
      if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
        logging.info("Race condition - idConjunto {} allocated to another instance." \
                    .format(conjunto_terminais_livres.get('idConjunto')), exc_info=True)
        
        # Getting a new set of entries to allocate
        conjunto_terminais_livres = _obter_conjunto_terminais_livres()
      else:
        raise

  return None


def _montar_json_resposta(canal_json, hostname, conjunto_terminais_alocados):
  if conjunto_terminais_alocados is not None and 'terminais' not in conjunto_terminais_alocados:
    return

  config_json = json.loads(canal_json)

  if conjunto_terminais_alocados is not None:
    fconn_json = {
      'Terminais': {
        hostname: conjunto_terminais_alocados['terminais']
      }
    }
    config_json['FCONN'] = fconn_json

  return config_json


def lambda_handler(event, context):
  logging.debug(event)
  
  conj_terminais_alocados = None

  try:
    allocate_grbe_terminals = event.get('allocateGRBETerminals')
    auto_scaling_group_name = event.get('autoScalingGroupName')
    hostname                = event.get('hostname')
    instance_id             = event.get('instanceId')

    canal_json        = _obter_json_do_canal(event.get('canal'))
    config_file_path  = _obter_output_config_file_path(APICONNECTOR_FILE_PATH, 
                                                        APICONNECTOR_FILE_NAME, 
                                                        hostname)
      
    if allocate_grbe_terminals:
      conj_terminais_alocados = _alocar_conjunto_terminais(auto_scaling_group_name, instance_id)
    
    config_json = _montar_json_resposta(canal_json, hostname, conj_terminais_alocados)

    if config_json:
      logging.info("Conjunto {} alocado à instância {} (asg = {}).".format(conj_terminais_alocados['idConjunto'], instance_id, auto_scaling_group_name))
      logging.debug("JSON content for ApiConnector file: {}".format(config_json))
        
      return {
        'statusCode': 200,
        'allocateGRBETerminals': allocate_grbe_terminals,
        'autoScalingGroupName': auto_scaling_group_name,
        'instanceId': instance_id,
        'hostname': hostname,
        'idConjuntoAlocado': conj_terminais_alocados['idConjunto'],
        'configFilePath': config_file_path,
        'configJson': config_json
      }
          
    else:
      logging.error("Nenhum conjunto de terminais foi alocado à instância devido a falta de  {} alocado à instância {}.".format(conj_terminais_alocados['idConjunto'], instance_id))
      return {
        'statusCode': 204,
        'message': 'Nenhum conjunto de terminais foi alocado à instância.'
      }

  except:
    logging.error('Ocorreu um erro na alocação de terminais.', exc_info=True)
    
    return {
      'statusCode': 500,
      'message': 'Ocorreu um erro na alocação de terminais.'
    }