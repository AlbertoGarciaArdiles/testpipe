import os
import logging
import lgi

LOG_FORMAT='%(asctime)-15s - %(levelname)-8s - @%(module)-s:%(lineno)-s - %(message)s'
logging.basicConfig(format=LOG_FORMAT, level=os.getenv('LOG_LEVEL', 'ERROR'))

def lambda_handler(event, context):
  pass