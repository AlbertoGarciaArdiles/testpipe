import boto3
import logging

from boto3.dynamodb.conditions import Attr
from os import environ

# Getting environment variables
DYNAMODB_TABLE_NAME = environ.get('DYNAMODB_TABLE_NAME')

if "DYNAMODB_TABLE_NAME" not in environ:
  raise ValueError("Variável de ambiente DYNAMODB_TABLE_NAME deve ser informada a fim de especificar o nome da tabela DynamoDB onde residem os conjuntos de terminais a serem alocados.")


# Logging initialization function
logging.basicConfig(level=os.getenv('LOG_LEVEL', 'ERROR'))


def _obter_terminais_alocados(instance_id):
  resource = boto3.resource('dynamodb')
  table = resource.Table(DYNAMODB_TABLE_NAME)
  
  scan_kwargs = {
    'FilterExpression': Attr("instanceId").eq(instance_id)
  }

  items = []
  done = False
  start_key = None
  while not done:
    # Dealing with pagination
    if start_key:
      scan_kwargs['ExclusiveStartKey'] = start_key
      # Runs another scan with a smaller limit based on previous return quantity

    response = table.scan(**scan_kwargs)
    items.extend(response.get('Items', []))
    
    # Dealing with pagination
    start_key = response.get('LastEvaluatedKey', None)
    done = start_key is None
  
  # Limits the return of the array to the total limit desired
  return items


def _desalocar_terminais(items):
  resource      = boto3.resource('dynamodb')
  table         = resource.Table(DYNAMODB_TABLE_NAME)
  updated_items = [] 
  
  for item in items:
    response = table.update_item(
      Key={
        'idConjunto': item.get('idConjunto')
      },
      UpdateExpression='REMOVE instanceId'
    )
    
    if response.get('ResponseMetadata').get('HTTPStatusCode') == 200:
      updated_items.append(item)

  return updated_items


def lambda_handler(event, context):
  logging.debug(event)

  try:
    instance_id = event['instanceId']
    conjuntos_terminais_livres = _desalocar_terminais(_obter_terminais_alocados(instance_id))

    if len(conjuntos_terminais_livres) > 0:
      return {
        'statusCode': 200,
        'message': 'Terminais liberados previamente alocados para instância.',
        'body': conjuntos_terminais_livres
      }
        
    else:
      return {
        'statusCode': 204,
        'message': 'Não foram encontrados terminais alocados para a instância informada.',
        'instanceId': instance_id
      }

  except:
    logging.error('Ocorreu um erro na desalocação de terminais.', exc_info=True)
    
    return {
      'statusCode': 500,
      'message': 'Ocorreu um erro na desalocação de terminais.'
    }