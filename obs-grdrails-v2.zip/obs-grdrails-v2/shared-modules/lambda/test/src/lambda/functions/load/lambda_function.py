import awswrangler as wr
import boto3
import botocore
import json
import logging
import math
import numpy as np

from os import environ

# Getting environment variables
DYNAMODB_BATCH_GET_ITEM_LIMIT = int(environ.get('DYNAMODB_BATCH_GET_ITEM_LIMIT', 100))
DYNAMODB_TABLE_NAME           = environ.get('DYNAMODB_TABLE_NAME')

if "DYNAMODB_TABLE_NAME" not in environ:
  raise ValueError("Variável de ambiente DYNAMODB_TABLE_NAME deve ser informada a fim de especificar o nome da tabela DynamoDB onde residem os conjuntos de terminais a serem alocados.")


# Logging initialization function
logging.basicConfig(level=os.getenv('LOG_LEVEL', 'ERROR'))


# For global notification of error occur
ERROR_OCCURRED = False


def _get_file_path(event):
  """From the received S3 upload event, identifies the s3 file path.
  
  Arguments:
    event {event} -- the S3 Put Object event

  Returns:
    {string} -- s3 object path within the format s3://bucket_name/file_key
  """
  records       = [x for x in event.get('Records', [])]
  sorted_events = sorted(records, key=lambda e: e.get('eventTime'))
  latest_event  = sorted_events[-1] if sorted_events else {}
  info          = latest_event.get('s3', {})
  file_key      = info.get('object', {}).get('key')
  bucket_name   = info.get('bucket', {}).get('name')

  s3_file_path = f"s3://{bucket_name}/{file_key}"

  logging.info("Executando carga do arquivo {} na tabela de controle de terminais mainframe alocados.", s3_file_path)

  return s3_file_path
   
   
def _split_valid_invalid_terminal_sets(df):
  """From a dataframe, splits it into a dict with two entries, one for a
  dataframe with valid terminals' sets called validSets, and one for a
  dataframe with invalid terminals' sets called invalidSets.
  
  What defines a terminals' sets as valid or not is the quantity of 
  operations for the set. Each set should come with one operation only.
  If a set CONJ01 (example id) comes with two operations, ADD and DEL,
  for example, it is considered an invalid set.

  Arguments:
    df {dataframe} -- dataframe to be split into two (valids and invalids) 

  Returns:
    {dict} -- Dictionary with valid and invalid terminals' sets
  """

  # A set of terminals can only have one operation in the upcoming file
  df_new         = df.groupby('idConjunto')['operacao'].nunique()
  valid_sets_ids = df_new[df_new == 1].reset_index()['idConjunto'].tolist()

  result = {}
  result['validSets']   = df.loc[df['idConjunto'].isin(valid_sets_ids)]
  result['invalidSets'] = df.loc[~df['idConjunto'].isin(valid_sets_ids)]
  
  return result


def _treat_invalid_mfm_terminal_sets(df):
  """From a dataframe with invalid terminals' sets, run over it,
  grabbing the operations per terminals' set, and putting that
  to the log.
  
  A global variable ERROR_OCCURRED is also marked as True in order
  to have an unique notification process at the end of the process.

  Arguments:
    df {dataframe} -- dataframe with invalid terminals' set
  """
  global ERROR_OCCURRED
    
  for conjunto in df['idConjunto'].unique():
    operacoes = df.loc[df['idConjunto'] == conjunto]['operacao'].unique()
    logging.error("O grupo de terminais cujo idConjunto é {} possui mais de uma operação ({}). Consequentemente, este conjunto foi excluído do processo de carga." \
                .format(conjunto, ",".join(operacoes)))
    ERROR_OCCURRED = True


def _get_columns_to_be_returned(df, columns_to_be_removed = []):
  """From a dataframe, get a list of its column names, removing
  the ones that are passed into the columns_to_be_removed parameter.
  
  Arguments:
    df {dataframe} -- dataframe to be have its column names extracted
    columns_to_be_removed {list} -- list of column names (string) that 
      have to be removed when grabbing column names from dataframe

  Returns:
    {list} -- List with columns names from df parameter, removing the ones
      informed on columns_to_be_removed parameter
  """
  return [column_to_be_returned for column_to_be_returned in df.columns.tolist() 
      if column_to_be_returned not in columns_to_be_removed]


def _generate_terminals_set_json(terminals_set_id, data, columns_to_be_returned = []):
  """Constructs a json for terminals' set.

  Arguments:
    terminals_set_id {string} -- unique identifier of the set
    data {dataframe} -- dataframe for a specific terminals' set
    columns_to_be_returned {array} -- array with the columns/keys that
      have to be returned in the json of each terminal entry

  Returns:
    {dict} -- Dictionary with terminals' set id, and list of terminals from dataframe
  """
  terminals_set_json = {}
  terminals_set_json['idConjunto'] = terminals_set_id
  
  if columns_to_be_returned:
    terminals_set_json['terminais'] = json.loads(data[columns_to_be_returned].to_json(orient='records'))
  else:
    terminals_set_json['terminais'] = json.loads(data.to_json(orient='records'))
      
  return terminals_set_json
    
    
def _query_terminals_sets_ids_that_exist_by_ids(dynamodb, table, ids):
  """From a list of terminals' sets ids, query the DynamoDB table
  identifying the ones that exist, and return the ids of this search.
  
  Arguments:
    dynamodb {resource} -- a resource representing dynamodb from boto3
    table {Table} -- a resource representing Table from dynamodb
    ids {list} -- list of ids that are going to be searched over DynamoDB table

  Returns:
    {list} -- List of terminals' sets ids that exist on DynamoDB table and
      were informed in ids parameter
  """
  list_existing_ids = []
  
  # Splitting array of ids to the limit that batch_get_item supports
  # If you request more than 100 items, BatchGetItem returns a ValidationException 
  # with the message "Too many items requested for the BatchGetItem call."
  ids_split_by_limit = np.array_split(np.array(ids), math.ceil(len(ids)/DYNAMODB_BATCH_GET_ITEM_LIMIT))
  
  for ids_split in ids_split_by_limit:
    keys             = ids_split.copy()
    done             = False
    unprocessed_keys = None
    while not done:
      # Dealing with unprocessed keys
      if unprocessed_keys:
        keys = [ x['idConjunto'] for x in unprocessed_keys.get(table.name).get('Keys') ]

      request_items = {
        table.name: {
          'Keys': [{'idConjunto': id} for id in keys],
          'ProjectionExpression': 'idConjunto'
        }
      }

      response = dynamodb.batch_get_item(RequestItems=request_items)

      if response.get('Responses') and response.get('Responses').get(table.name):
        list_existing_ids.extend([x['idConjunto'] for x in response.get('Responses').get(table.name)])

      # Dealing with pagination
      unprocessed_keys = response.get('UnprocessedKeys', None)
      done             = unprocessed_keys is None or len(unprocessed_keys.keys()) == 0

  return list_existing_ids
    

def _terminals_set_add_operation(dynamodb, table, terminals_sets):
  """From a list of json terminals' sets, create an entry in the 
  DynamoDB table.
  
  A global variable ERROR_OCCURRED is also marked as True when
  a terminals set is requested to be added, but already exists
  in the DynamoDB table, and in order to have an unique 
  notification process at the end of the process.

  Arguments:
      dynamodb {resource} -- a resource representing dynamodb from boto3
      table {Table} -- a resource representing Table from dynamodb
      terminals_sets {list} -- list of json terminals' sets to be loaded 
          into DynamoDB table
  """
  global ERROR_OCCURRED
  
  if not terminals_sets:
    return
    
  # Getting the list of idConjunto that came from file
  list_terminals_set_ids_from_file = [x['idConjunto'] for x in terminals_sets]
  # Getting the list of idConjunto that exist on the DynamoDB, base on idConjunto list from file
  list_existing_terminals_set_ids  = _query_terminals_sets_ids_that_exist_by_ids(dynamodb, table, list_terminals_set_ids_from_file)
  
  list_terminals_sets_added   = []
  list_terminals_sets_ignored = []
  with table.batch_writer() as writer:
    for item in terminals_sets:
      # Only adds if it does not already exist
      if item['idConjunto'] in list_existing_terminals_set_ids:
        list_terminals_sets_ignored.append(item['idConjunto'])
      else:
        writer.put_item(Item=item)
        list_terminals_sets_added.append(item['idConjunto'])

  if list_terminals_sets_added:
    logging.info("Os seguintes conjuntos foram adicionados à tabela de controle de terminais: {}".format(",".join(list_terminals_sets_added)))
      
  if list_terminals_sets_ignored:
    ERROR_OCCURRED = True
    logging.error("Os seguintes conjuntos já existiam na tabela de controle de terminais, e suas atualizações ignoradas: {}".format(",".join(list_terminals_sets_ignored)))


def _terminals_set_delete_operation(table, terminals_sets):
  """From a list of json terminals' set ids, delete the entry 
  from the DynamoDB table.
  
  A global variable ERROR_OCCURRED is also marked as True when
  a terminals set is requested to be deleted, but it is allocated
  for an instance (key instanceId exists on entry) in the DynamoDB 
  table, and in order to have an unique notification process at the 
  end of the process.

  Arguments:
      table {Table} -- a resource representing Table from dynamodb
      terminals_sets {list} -- list of json terminals' set ids to be deleted
          into DynamoDB table
  """
  global ERROR_OCCURRED
  
  list_terminals_sets_removed = []
  list_terminals_sets_ignored = []

  for terminals_set_id in terminals_sets:
    try:
      table.delete_item(Key={
        'idConjunto': terminals_set_id
        },
        ConditionExpression = 'attribute_not_exists(instanceId)'
      )
      list_terminals_sets_removed.append(terminals_set_id)
        
    except botocore.exceptions.ClientError as e:
      # Ignore the ConditionalCheckFailedException
      # Trying to remove a set that is allocated to an instance
      if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
        list_terminals_sets_ignored.append(terminals_set_id)
      else:
        raise

  if list_terminals_sets_removed:
    logging.info("Os seguintes conjuntos foram removidos da tabela de controle de terminais: {}".format(",".join(list_terminals_sets_removed)))
      
  if list_terminals_sets_ignored:
    ERROR_OCCURRED = True
    logging.error("Os seguintes conjuntos estão alocados a instâncias e não podem ser excluídos: {}".format(",".join(list_terminals_sets_ignored)))


def _treat_valid_mfm_terminal_sets(df):
  """From a dataframe with valid terminals' sets, run over it,
  grabbing the operations per terminals' set, checking if it is
  valid or not (raising an error), and calling the ADD/DEL
  oprations to manipulade DynamoDB table.
  
  A global variable ERROR_OCCURRED is also marked as True when
  an invalid operation is identified for an terminals' set, in 
  order to have an unique notification process at the end of the 
  process.

  Arguments:
    df {dataframe} -- dataframe with valid terminals' set
  """
  global ERROR_OCCURRED
  
  columns_to_be_on_returned = _get_columns_to_be_returned(df, ['idConjunto', 'operacao'])

  terminals_sets_to_be_added   = []
  terminals_sets_to_be_deleted = []

  for terminals_set_id, data in df.groupby('idConjunto'):
    # Should always be one unique value only, since more than one
    # is considered as an invalid set
    operation = data['operacao'].unique()[-1]

    if operation == 'ADD':
      terminals_sets_to_be_added.append(_generate_terminals_set_json(terminals_set_id, data, columns_to_be_on_returned))
    elif operation == 'DEL':
      terminals_sets_to_be_deleted.append(terminals_set_id)
    else:
      logging.error("O grupo de terminais cujo idConjunto é {} possui uma operação inválida ({}). As únicas operações válidas são ADD e DEL.".format(terminals_set_id, operation))
      ERROR_OCCURRED = True
            
    dynamodb = boto3.resource('dynamodb')
    table    = dynamodb.Table(DYNAMODB_TABLE_NAME)

    # Adding Terminals' Sets
    _terminals_set_add_operation(dynamodb, table, terminals_sets_to_be_added)
    
    # Deleting Terminals' Sets
    _terminals_set_delete_operation(table, terminals_sets_to_be_deleted)


def lambda_handler(event, context):
  logging.debug(event)

  try:
    s3_file_path = _get_file_path(event)
    df = wr.s3.read_csv([s3_file_path])
    
    # Splitting the df into a dict with to df (validSets and invalidSets)
    valid_invalid_sets = _split_valid_invalid_terminal_sets(df)
    
    # Treating list of mainframe terminal sets that are invalid
    _treat_invalid_mfm_terminal_sets(valid_invalid_sets['invalidSets'])
    
    # Treating list of mainframe terminal sets that are valid
    _treat_valid_mfm_terminal_sets(valid_invalid_sets['validSets'])

    if ERROR_OCCURRED:
      return {
        'statusCode': 207,
        'message': 'Arquivo {} carregado na tabela {}, entretanto, alguns problemas ocorreram. Consulte o log para maiores informações.'.format(s3_file_path, DYNAMODB_TABLE_NAME)
      }
    else:
      return {
        'statusCode': 200,
        'message': 'Arquivo {} carregado com sucesso na tabela {}.'.format(s3_file_path, DYNAMODB_TABLE_NAME)
      }

  except:
    logging.error('Ocorreu um erro no carregamento do arquivo CSV de terminais.', exc_info=True)
    
    return {
      'statusCode': 500,
      'message': 'Ocorreu um erro no carregamento do arquivo CSV de terminais.'
    }