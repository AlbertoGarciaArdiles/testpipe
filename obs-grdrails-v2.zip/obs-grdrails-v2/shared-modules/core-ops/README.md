Itau CORE MODULE for Infra as Code

The core module is a container for multiple resources that are used together with other modules. Modules can be used to create lightweight abstractions, so that you can describe your infrastructure in terms of its architecture. 

The .tf files in your working directory when you run terraform plan or terraform apply together form the root module. 
The core module may called from other modules and connect them together by passing output values from one to input values of another.

The Itau Core module returns in output the resource_name_prefix, 
Mandatory ITAU tags - `required_tags_map` in MAP format which can be applied to EC2 Launch templates Mandatory ITAU tags with `propagate_at_launch` - launch_tags set to true which can be applied on ASG & EC2 instances with the dynamic  format with launch 

resource_name_prefix - The resource name prefix by concatenation of 4 variables environment--shortened_region--groupname--sub_groupname

for instance - dev-se1-si2-boletos

sync repo
