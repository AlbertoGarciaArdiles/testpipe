../terraform fmt -recursive
git add .
git commit -m "$1"
git push
