import boto3
import json
import math
import logging
import copy
import time
logger = logging.getLogger()
logger.setLevel(logging.INFO)

cloudwatch = boto3.client('cloudwatch')
ecs = boto3.client('ecs')
eks = boto3.client('eks')
client = boto3.client('config')
rds = boto3.client('rds')
dynamodb = boto3.client('dynamodb')
lmbda = boto3.client('lambda')
elbv2 = boto3.client('elbv2')
ecs = boto3.client('ecs')
kafka = boto3.client('kafka')
apigateway = boto3.client('apigateway')
apigatewayv2 = boto3.client('apigatewayv2')

#supported_services = ['ECS']
supported_services = ['ApiGateway','DynamoDB','EC2','ECS','EKS','Elasticache','ElasticLoadBalancingV2','Lambda','MSK','RDS','S3','SNS']
#supported_services = ['ApiGateway','AutoScaling','DynamoDB','EC2','ECS','EKS','Elasticache','ElasticLoadBalancingV2','Lambda','RDS','S3','SNS']

''' Return list of services running in the account '''
def list_services ():
    paginator = client.get_paginator('select_resource_config')
    response = paginator.paginate(
        Expression='select resourceType group by resourceType')
    
    tmp = []
    for page in response:
        tmp += page['Results']
    
    #Create list of Services running
    result = []
    for res in tmp:
        result.append(json.loads(res)['resourceType'].split("::")[1])
        result = list(set(result))

    ecsresp = ecs.list_clusters()
    if len ( ecsresp['clusterArns']) > 0:
        result.append('ECS')

    kafkaresp = kafka.list_clusters()
    if len(kafkaresp['ClusterInfoList']) > 0:
        result.append('MSK')

    eksresp = eks.list_clusters()
    if len(eksresp['clusters']) > 0:
        result.append('EKS')
    
    # Get unique values and sort
    myset = set(result)
    result = list(myset)
    result.sort()
    return result

def create_alarm ( alarm_config ):
    # MaxQuotaValue, is this a nominal value? Or is this just the hard limit to know.
    # ServiceQuotaName, maybe this is the same as an indicator.
    
    logger.info ('CREATING ALARM...')
    logger.info ( alarm_config )
    
    threshold = alarm_config['alarm_threshold_percent'] if ( 'unit' in alarm_config and alarm_config['unit'] == 'Percent' ) else math.ceil( ( alarm_config['current_quota_value'] * alarm_config['alarm_threshold_percent'] ) / 100 )
    
    args = {
        'AlarmName' : 'QUOTA_MANAGER-' + alarm_config['alarm_name'],
        'ComparisonOperator' : alarm_config['comparison_operator'],
        'EvaluationPeriods' : alarm_config['evaluation_periods'],
        'MetricName' : alarm_config['metric_name'],
        'Namespace' : alarm_config['namespace'],
        'Period' : alarm_config['period'],
        'Statistic' : alarm_config['statistic'],
        'Threshold' : threshold,
        'ActionsEnabled' : True,
        'AlarmDescription' : alarm_config['alarm_description'],
        'AlarmActions' : [ alarm_config['alarm_actions'] ],
        'Dimensions' : alarm_config['dimensions'] if 'dimensions' in alarm_config else []
    }
    if 'unit' in alarm_config:
        args['Unit'] = alarm_config['unit']
    
    # Create alarm
    resp = cloudwatch.put_metric_alarm(**args)
    time.sleep(0.1)
    return resp

############################ ELBv2 ###############################
#'typeoflb': 'application'|'network'
def describe_load_balancers( typeoflb ):
    paginator = elbv2.get_paginator('describe_load_balancers')
    response = paginator.paginate()
    loadbalancers = []
    for page in response:
        loadbalancers += page['LoadBalancers']
    
    loadbalancers_result = []
    for lb in loadbalancers:
        if lb['Type'] == typeoflb:
            loadbalancers_result.append(lb)
    return loadbalancers_result

def create_alarm_for_elbv2 ( alarm_config ):
    
    logger.info ('ALARM NAME')
    logger.info (alarm_config['alarm_name'])
    
    if alarm_config['alarm_name'] in [ 'ALB-TargetGroupsPerApplicationLoadBalancer-Quota-' ] :
        loadbalancers = describe_load_balancers( 'application' )
        logger.info ('LIST OF APP LOAD BALANCERS')
        logger.info (loadbalancers)

        for lb in loadbalancers:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + lb['LoadBalancerName']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", lb['LoadBalancerName'])
            alarm_config_buf['dimensions'][0]['Value'] = lb['LoadBalancerName']
            create_alarm( alarm_config_buf )

    elif alarm_config['alarm_name'] in [ 'NLB-TargetGroupsPerNetworkLoadBalancer-Quota-' ] :
        loadbalancers = describe_load_balancers( 'network' )
        logger.info ('LIST OF NW LOAD BALANCERS')
        logger.info (loadbalancers)

        for lb in loadbalancers:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + lb['LoadBalancerName']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", lb['LoadBalancerName'])
            alarm_config_buf['dimensions'][0]['Value'] = lb['LoadBalancerName']
            create_alarm( alarm_config_buf )

    else:
        create_alarm( alarm_config )

#################################################################

############################ ECS ###############################

def describe_cluster( cluster_arn ):
    response = ecs.describe_clusters( clusters = [ cluster_arn ] )
    return response['clusters'][0]

def list_ecs_clusters():
    paginator = ecs.get_paginator('list_clusters')
    response = paginator.paginate()
    clusters = []
    for page in response:
        clusters += page['clusterArns']
    return clusters

def list_ecs_services( cluster_arn ):
    paginator = ecs.get_paginator('list_services')
    response = paginator.paginate( cluster = cluster_arn )
    servicesarns = []
    for page in response:
        servicesarns += page['serviceArns']
    return servicesarns

def describe_services( clusterarn, servicearn ):
    response = ecs.describe_services( cluster = clusterarn, services = [ servicearn ] )
    return response['services'][0]
    
    # pag_services = ecs.get_paginator('list_services')
    # resp_services = pag_services.paginate( cluster = clusterarn )
    # serv_arns = []
    # for page in resp_services:
    #     serv_arns += page['serviceArns']

    # services = []  
    # for serv in serv_arns:
    #     response = ecs.describe_services( services = serv )
    #     services += response['services']
    # return services

def create_alarm_for_ecs ( alarm_config ):
    
    logger.info ('ALARM NAME')
    logger.info (alarm_config['alarm_name'])
    
    if alarm_config['alarm_name'] in [ 'ECS-ContainerInstancesPerCluster-Quota-', 'ECS-ServicesPerCluster-Quota-' ] :
        clusterarns = list_ecs_clusters()
        logger.info ('LIST OF CLUSTERS')
        logger.info (clusterarns)
        for clusterarn in clusterarns:
            cluster = describe_cluster ( clusterarn )
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + cluster['clusterName']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", cluster['clusterName'])
            alarm_config_buf['dimensions'][0]['Value'] = cluster['clusterName']
            create_alarm( alarm_config_buf )
            
    elif alarm_config['alarm_name'] in [ 'ECS-TasksPerService-Quota-'] :
        clusterarns = list_ecs_clusters()
        logger.info ('LIST OF CLUSTERS')
        logger.info (clusterarns)
        for clusterarn in clusterarns:
            cluster = describe_cluster ( clusterarn )
            servicearns = list_ecs_services( cluster['clusterArn'] )
            logger.info ('SERVICES ARNs')
            logger.info (servicearns)
            for servicearn in servicearns:
                service = describe_services ( clusterarn, servicearn )
                alarm_config_buf = copy.copy(alarm_config)
                alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + cluster['clusterName']
                alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", cluster['clusterName'])
                alarm_config_buf['dimensions'][0]['Value'] = cluster['clusterName']
                alarm_config_buf['dimensions'][1]['Value'] = service['serviceName']
                create_alarm( alarm_config_buf )
    else:
        create_alarm( alarm_config )

#################################################################

############################ DynamoDB ###############################

def list_tables():
    paginator = dynamodb.get_paginator('list_tables')
    response = paginator.paginate()
    tables = []
    for page in response:
        tables += page['TableNames']
    return tables

def create_alarm_for_dynamodb ( alarm_config ):
    
    logger.info ('ALARM NAME')
    logger.info (alarm_config['alarm_name'])
    
    if alarm_config['alarm_name'] in [ 'Dynamodb-ConsumedReadCapacityUnits-Quota-', 'Dynamodb-ConsumedWriteCapacityUnits-Quota-' ] :
        tables = list_tables()
        logger.info ('LIST OF TABLES')
        logger.info (tables)
        i = 1
        for table in tables:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + table
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", table)
            alarm_config_buf['dimensions'][0]['Value'] = table
            create_alarm( alarm_config_buf )
            i+=1

    else:
        create_alarm( alarm_config )

#################################################################

############################ Lambda ###############################

def list_functions():
    paginator = lmbda.get_paginator('list_functions')
    response = paginator.paginate()
    functions = []
    for page in response:
        functions += page['Functions']
    return functions

def create_alarm_for_lambda ( alarm_config ):
    
    logger.info ('ALARM NAME')
    logger.info (alarm_config['alarm_name'])
    
    if alarm_config['alarm_name'] in [ 'Lambda-Duration-Quota-' ] :
        functions = list_functions()
        logger.info ('LIST OF FUNCTIONS')
        logger.info (functions)
        i = 1
        for function in functions:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + function['FunctionName']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", function['FunctionName'])
            alarm_config_buf['dimensions'][0]['Value'] = function['FunctionName']
            create_alarm( alarm_config_buf )
            i+=1
    
    else:
        create_alarm( alarm_config )

#################################################################

############################ ApiGateway ###############################

def get_http_apis():
    paginator = apigatewayv2.get_paginator('get_apis')
    response = paginator.paginate()
    apis = []
    for page in response:
        for item in page['Items']:
            if item['ProtocolType'] == 'HTTP':
                apis.append( item )
                #apis += page['Items']
    return apis

def get_websocket_apis():
    paginator = apigatewayv2.get_paginator('get_apis')
    response = paginator.paginate()
    apis = []
    for page in response:
        for item in page['Items']:
            if item['ProtocolType'] == 'WEBSOCKET':
                apis.append( item )
                #apis += page['Items']
    return apis

def get_rest_apis():
    paginator = apigateway.get_paginator('get_rest_apis')
    response = paginator.paginate()
    restapis = []
    for page in response:
        restapis += page['items']
    return restapis

def get_api_keys():
    paginator = apigateway.get_paginator('get_api_keys')
    response = paginator.paginate()
    apikeys = []
    for page in response:
        apikeys += page['items']
    return apikeys

def create_alarm_for_apigateway ( alarm_config ):
    
    logger.info ('ALARM NAME')
    logger.info (alarm_config['alarm_name'])
    
    if alarm_config['alarm_name'] in [ 'Apigateway-RoutesPerHTTPAPI-Quota-','Apigateway-StagesPerAPIHTTP-Quota-' ] :
        httpapis = get_http_apis()
        logger.info ('LIST OF HTTP APIs')
        logger.info (httpapis)

        for httpapi in httpapis:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + httpapi['ApiId']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", httpapi['ApiId'])
            alarm_config_buf['dimensions'][0]['Value'] = httpapi['ApiId']
            create_alarm( alarm_config_buf )

    elif alarm_config['alarm_name'] in [ 'Apigateway-StagesPerAPIREST-Quota-', 'Apigateway-ResourcesPerRESTAPI-Quota-' ] :
        restapis = get_rest_apis()
        logger.info ('LIST OF REST APIs')
        logger.info ( restapis )

        for restapi in restapis:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + restapi['id']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", restapi['id'])
            alarm_config_buf['dimensions'][0]['Value'] = restapi['id']
            create_alarm( alarm_config_buf )

    elif alarm_config['alarm_name'] in [ 'Apigateway-StagesPerAPIWebSocket-Quota-', 'Apigateway-RoutesPerWebSocketAPI-Quota-' ] :
        websocketapis = get_websocket_apis()
        logger.info ('LIST OF WEBSOCKET APIs')
        logger.info ( websocketapis )

        for websocketapi in websocketapis:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + websocketapi['ApiId']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", websocketapi['ApiId'])
            alarm_config_buf['dimensions'][0]['Value'] = websocketapi['ApiId']
            create_alarm( alarm_config_buf )

    elif alarm_config['alarm_name'] in [ 'Apigateway-StagesPerAPI-Quota-' ] :
        apikeys = get_api_keys()
        logger.info ('LIST OF API KEYs')
        logger.info ( apikeys )

        for apikey in apikeys:
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + apikey['id']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", apikey['id'])
            alarm_config_buf['dimensions'][0]['Value'] = apikey['id']
            create_alarm( alarm_config_buf )
    
    else:
        create_alarm( alarm_config )

#################################################################
    
############################ RDS ###############################

def list_clusters():
    paginator = rds.get_paginator('describe_db_clusters')
    response = paginator.paginate()
    clusters = []
    for page in response:
        clusters += page['DBClusters']
    return clusters

def list_dbinstances():
    paginator = rds.get_paginator('describe_db_instances')
    response = paginator.paginate()
    instances = []
    for page in response:
        instances += page['DBInstances']
    return instances

def create_alarm_for_rds ( alarm_config ):
    
    if alarm_config['alarm_name'] in [ 'RDS-IAMRolesPerDBInstance-Quota-', 'RDS-ManualDBInstanceSnapshots-Quota-'] :
        dbinstances = list_dbinstances()
        logger.info ('LIST OF INSTANCES')
        logger.info (dbinstances)
        i = 1
        for dbinstance in dbinstances:
            logger.info ('CREATING PER DB INSTANCE')
            logger.info (dbinstance)
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + dbinstance['DBName']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", dbinstance['DBName'])
            alarm_config_buf['dimensions'][0]['Value'] = dbinstance['DBName']
            create_alarm( alarm_config_buf )
            i+=1

    elif alarm_config['alarm_name'] in [ 'RDS-IAMRolesPerDBCluster-Quota-' ]:
        clusters = list_clusters()
        logger.info ('LIST OF CLUSTERS')
        logger.info (clusters)
        i = 1
        for cluster in clusters:
            logger.info ('CREATING PER CLUSTER')
            logger.info (cluster)
            alarm_config_buf = copy.copy(alarm_config)
            alarm_config_buf['alarm_name'] = alarm_config['alarm_name'] + cluster['DatabaseName']
            alarm_config_buf['alarm_description'] = alarm_config['alarm_description'].replace( "{{ resource }}", clusters['DatabaseName'])
            alarm_config_buf['dimensions'][0]['Value'] = cluster['DatabaseName']
            create_alarm( alarm_config_buf )
            i+=1
    
    else:
        logger.info ('USING DEFAULT')
        create_alarm( alarm_config )

#################################################################


''' List of services supported by AWS Config
    https://docs.aws.amazon.com/config/latest/developerguide/resource-config-reference.html '''
def lambda_handler(event, context):
    
    services = list_services()
    logger.info ('::List of services identified in account::')
    logger.info (services)

    alarmsforaccount = []
    for service in services:
        if service in supported_services:
            f = open('alarm_config/' + service + '.json')
            alarmdictionary = json.load(f)
            for alarm in alarmdictionary['Alarms']:
                alarmsforaccount.append(alarm)
            f.close()
            
    logger.info ('::List of alarms to be created::')
    logger.info (alarmsforaccount)
            
    #Create alarms
    for alarm in alarmsforaccount:
        logger.info ( 'Creating Alarm ' + alarm['Id'] + ' alarm service: ' + alarm['Service'] )
        if alarm['Service'] == 'RDS':
            create_alarm_for_rds ( alarm['AlarmConfig'] )
        elif alarm['Service']  == 'DynamoDB':
            create_alarm_for_dynamodb ( alarm['AlarmConfig'] )
        elif alarm['Service'] == 'Lambda':
            create_alarm_for_lambda ( alarm['AlarmConfig'] )
        elif alarm['Service'] == 'ElasticLoadBalancingV2':
            create_alarm_for_elbv2 ( alarm['AlarmConfig'] )
        elif alarm['Service'] == 'ECS':
            create_alarm_for_ecs ( alarm['AlarmConfig'] )
        elif alarm['Service'] == 'ApiGateway':
            create_alarm_for_apigateway ( alarm['AlarmConfig'] )
        else:
            create_alarm ( alarm['AlarmConfig'] )

    return {
        'statusCode': 200,
        'ServicesIdentified': services,
        'AlarmsToBeCreated': alarmsforaccount
    }
